#!/bin/bash
# @author: yuandan
# @date: 2011-11-30 11:24
# @author: viticm
# @modify time:2013-1-8 15:32:52
# 本程序根据后台的日志需求将gamesvr_event中的相关日志分门别类
# 并传输给PHP后台使用
#

#rsync的同步变量
rsync_pwd_file=/etc/rsync.pass
rsync_remote_path=game_logs/91s1/wait
rsync_remote_usr=root
rsync_remote_host=127.0.0.1

log_file=/home/server/convertlog/91s1/gamesvr_event.log
last_line_path=/home/server/debug_log/91s1/lastline_evt.dat
new_file_path=/home/server/debug_log/91s1/php_log

type_ary=(logout create_page register first_view mission complaint first_mission target upgrade pay online login gold silver spirit crystal experience item access)
type_header_ary=(roleId,roleName,accountName,loginTime,logoutTime,roleLevel,lastLoginIp,logoutReason,logoutMapId,logoutX,logoutY accountname,ip,mtime roleid,rolename,accountname,rolesex,rolejob,ip,mtime
roleId,roleName,accountName,ip,useTime,mTime roleId,roleName,accountName,groupId,groupName,missionId,missionName,missionType,status,minLevel,maxLevel,loopTime,roleLevel,mTime sn,accountName,roleId,roleName,level,mTime,mType,title,content roleId,roleName,accountName,missionId,mTime
roleId,roleName,accountName,roleLevel,targetId,mTime roleId,roleName,accountName,currentLevel,mTime accountName,orderId,payMoney,payGold,mTime online,mTime roleId,roleName,accountName,loginTime,roleLevel,loginIp,mTime roleId,roleName,accountName,roleLevel,gold,bindGold,mType,itemId,color,quality,amount,mTime
roleId,roleName,accountName,roleLevel,silver,bindSilver,mType,itemId,color,quality,amount,mTime roleId,roleName,accountName,roleLevel,spirit,bindSpirit,mType,itemId,color,quality,amount,mTime
roleId,roleName,accountName,roleLevel,crystal,bindCrystal,mType,itemId,color,quality,amount,mTime roleId,roleName,accountName,roleLevel,experience,bindExperience,mType,itemId,color,quality,amount,mTime
roleId,roleName,accountName,roleLevel,mType,itemId,color,quality,amount,mTime roleId,roleName,accountName,roleLevel,ip,mTime)
#type_ary=(complaint)
#type_header_ary=(sn,accountName,roleId,roleName,level,mTime,mType,title,content)

curusr=`whoami`
if [[ $curusr != 'root' ]]
then
    echo "please use root to run this script !!!"
    exit
fi

last_line=0
if [[ -e ${last_line_path} ]]
then
    read last_line<${last_line_path}
fi


idx=0
while [ ${idx} -lt ${#type_ary[@]} ]
do
    cur_type=${type_ary[${idx}]}
    #echo "cur_type:"${cur_type}
    
    #生成新文件名
    if ! [[ -e ${new_file_path} ]]
    then
        mkdir -p ${new_file_path}
        chown server:server ${new_file_path} -R
    fi

    #得到文件名
    dt=`date +%Y%m%d`
    hour=`date +%k`
    hour=`expr ${hour} + 0`
    if [ ${hour} -lt 10 ]
    then
        hour='0'${hour}
    fi
    minute=`date +%M`
    minute=`expr ${minute} + 0`
    minute=$(( $minute - $minute % 5 ))
    if [ ${minute} -lt 10 ]
    then
        minute='0'${minute}
    fi
    dt=${dt}${hour}${minute}
    
    new_file_name=${new_file_path}/${dt}_${cur_type}.log
    total_line_count=0
    if [[ -e ${log_file} ]]
    then
        total_line_count=`wc -l ${log_file} | awk '{print $1}'`
    fi
    echo ${log_file}
    now_line_count=$(( ${total_line_count} - ${last_line} ))
    if [[ ${now_line_count} -gt 0 ]]
    then
        #往新日志文件中写入抬头
        echo ${type_header_ary[${idx}]} > ${new_file_name}
        #echo "now line count:"${now_line_count}
        tail -n ${now_line_count} ${log_file} | awk -F ' ' '{ if($3=="'${cur_type}'") { result=""; for(i=4;i<=NF;i++){ result=""result""$i;} print result; } }' >> ${new_file_name}
        chown server:server ${new_file_name}

        if [[ -e ${new_file_name} ]] 
        then
                result_linect=`wc -l ${new_file_name} | awk '{print $1}'`
                if [[ ${result_linect} -gt 1 ]]
                then
                    rsync -vrc --password-file=${rsync_pwd_file} ${new_file_name} ${rsync_remote_usr}@${rsync_remote_host}::${rsync_remote_path}
                else
                if [[ -e ${new_file_name} ]] 
                then
                        echo ${new_file_name}
                        rm -rf ${new_file_name}
                fi
                fi 
        fi
    fi

    echo ${total_line_count} > ${last_line_path}
    chown server:server ${last_line_path}
    new_file_name=''

    idx=`expr $idx + 1`
done
