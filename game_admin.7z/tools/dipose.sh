#!/bin/bash

if [[ $1 == '' ]] 
then
    echo "请输入压缩包"
    exit
fi
echo "解压包:"$1
target_dir=/data/web/fstx
tar -xvf $1 -C ${target_dir}
chown www:www /data/web/fstx -R
