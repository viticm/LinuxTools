<?
/*************************************************************************
* �������ܣ�truncate ĳ�����ݿ����еı�
***************************************************************************/


/*Ĭ�ϵ�ǰ׺*/
$default_prefix = '';
if( $_SERVER['argc'] > 1 )
{
    $default_prefix = $_SERVER['argv'][1];
}else
{
    echo "DB prefix is recommend !\n";
    exit;
}
print("DB prefix is :".$default_prefix."\n");

/** ��Ҫ���������ݿ���Ϣ **/
$DB_NAME_ARY = array($default_prefix."_character",$default_prefix."_namespace");
$DB_IP = "127.0.0.1";
$DB_USER = "root";
$DB_PWD = "";

function truncate_db( $db_name )
{
    global $DB_NAME_ARY ;
    global $DB_IP ;
    global $DB_USER ;
    global $DB_PWD ;

    $conn = mysql_connect($DB_IP, $DB_USER, $DB_PWD ) or die("cannot connect db");
    mysql_select_db($db_name, $conn );
    $res = mysql_query("show tables;", $conn);
    print("use ".$db_name.";\n");
    while( $ary = mysql_fetch_array($res) )
    {
        $cur_sql = "TRUNCATE ".$ary[0].";";
        print("execute sql: ".$cur_sql.";\t\t");
        $ret = mysql_query( $cur_sql, $conn );
        if( !$ret )
        {
            echo mysql_error();
            mysql_close( $conn );
            die("failed\n");
        }else
        {
            $affect_num = mysql_affected_rows( $conn );
            echo "OK, affect num: ".$affect_num."\n";
        }
    }
    mysql_close( $conn );

}

foreach( $DB_NAME_ARY as $dbname )
{
    truncate_db( $dbname );
} 
    
?>