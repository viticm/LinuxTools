#!/bin/bash

dbname=yjxy_admin_4399s1
out_dir=/tmp/dumpcsv

pwd=`cat /data/save/infobright_root`

dump_db_table () {
    db_name=$1
    tbl_name=$2
    /usr/local/infobright/bin/mysql -uroot -p`cat /data/save/infobright_root` -h127.0.0.1 -P5029 -D ${db_name} -e "select * from ${tbl_name} into outfile '${out_dir}/${tbl_name}.csv' FIELDS TERMINATED BY ',' ENCLOSED BY '\"' ESCAPED BY '\\\' LINES TERMINATED BY '\n';"
}

#获取表名数组
table_ary=(`echo "show tables;"|/usr/local/infobright/bin/mysql -uroot -p${pwd} -h127.0.0.1 -P5029 -D ${dbname}| sed '/Tables_in/d'`)

#遍历表名数组
for tb_name in ${table_ary[@]}
do
    echo "dump table: "$tb_name
    dump_db_table $dbname $tb_name
done
