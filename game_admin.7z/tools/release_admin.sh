#!/bin/sh

admin_upload=admin
rsync_module=web_rsync
server_list="183.61.83.33"
dipose_file=dipose.sh
date_str=`date +%Y%m%d_%H%M%S`
tar_name=${admin_upload}_${date_str}.tar.gz

rm -rf admin
rm -rf game3w
rm -rf gm
rm -rf tools
rm -rf *.tar.gz
mkdir ${admin_upload}
svn export --username dc --password 199041 https://192.168.1.105/svn/FSProject/trunk/program/php/viticm/code/game_admin_new ./ --force

#rm -rf ./admin/index.php
#mv ./admin/gateway ./ 

#删除所有config目录
skip_names="config docs test server.conf load.sh run_everyday.sh sync_data_central.sh alarm.sh"
for names in $skip_names
do
    find ./ -name ${names} | xargs -i rm -rf {}
done

#测试查找
echo "开始验证."
for names in $skip_names
do
    find ./ -name ${names}
done
echo "验证完毕."

#exit

#打包
tar -zcvf ${tar_name} admin gateway gm
ls -lhrt ${tar_name}

#rsync 到外服 现在不同步，改为自己上传上去
echo you can upload ./${dipose_file} and ./${tar_name} to "${serverlist}"
#for ip in ${server_list}
#do
#    echo "同步到服务器${ip}"
#    rsync -vrc --password-file=/etc/rsync.pass ./${dipose_file} root@${ip}::${rsync_module}
#    rsync -vrc --password-file=/etc/rsync.pass ./${tar_name} root@${ip}::${rsync_module}
#done
