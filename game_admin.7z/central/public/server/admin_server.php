<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Oct 31 09:17:30 GMT 2011
 * @desc 游戏管理后台服务器管理
 */
require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');

$action = $_GET['action'];
$action = $action ? $action : 'list';

if ('add' == $action) {
	if (isPost()) {
		$server = checkParams( $_POST['server'], $msg);
		$sql = " select * from t_game_server where `agentName`='{$server['agentName']}' and `serverId`='{$server['serverId']}' ";
		$rs = fetchRowOne($sql);
		if (!empty($rs)) {
			$msg[] = "{$server['agentName']}s{$server['serverId']} 已经存在，添加服务器失败";
		}
		if (empty($msg)) {
			$sql = makeInsertSql('t_game_server', $server);
			$rs = dbQuery($sql);
			if (!$rs) {
				$msg[] = '添加服务器配置失败！';
			}
		}
		if (empty($msg)) {
			header('Location:?action=list');
		}
	}
	
	$server['serverOnlineDate'] = $server['serverOnlineDate'] ? date('Y-m-d',$server['serverOnlineDate']) : ''; 
	$server['serverCombineDate'] = $server['serverCombineDate'] ? date('Y-m-d',$server['serverCombineDate']) : ''; 
	$data = array(
		'action'=>$action,
		'server'=>&$server,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('server/admin_server_edit.tpl',$data);
	
}elseif ('saveAs' == $action) {
	
	if (!isPost()) {
		$serverName = SS($_GET['serverName']);
		$sql = " select * from t_game_server where `serverName`='{$serverName}' ";
		$server = fetchRowOne($sql);
		$server['syncData'] = 0; //默认为不开启同步
	}else{
		$server = checkParams( $_POST['server'], $msg);
		$sql = " select * from t_game_server where `agentName`='{$server['agentName']}' and `serverId`='{$server['serverId']}' ";
		$rs = fetchRowOne($sql);
		if (!empty($rs)) {
			$msg[] = "{$server['agentName']}s{$server['serverId']} 已经存在，添加服务器失败";
		}
		if (empty($msg)) {
			$sql = makeInsertSql('t_game_server', $server);
			$rs = dbQuery($sql);
			if (!$rs) {
				$msg[] = '添加服务器配置失败！';
			}
		}
		if (empty($msg)) {
			header('Location:?action=list');
		}
	}
	
	$server['serverOnlineDate'] = $server['serverOnlineDate'] ? date('Y-m-d',$server['serverOnlineDate']) : ''; 
	$server['serverCombineDate'] = $server['serverCombineDate'] ? date('Y-m-d',$server['serverCombineDate']) : ''; 
	$data = array(
		'action'=>$action,
		'agents'=>&$agents,
		'server'=>&$server,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('server/admin_server_edit.tpl',$data);
	
}elseif ('update' == $action){
	if (!isPost()) {
		$serverName = SS($_GET['serverName']);
		$sql = " select * from t_game_server where `serverName`='{$serverName}' ";
		$server = fetchRowOne($sql);
	}else {
		$server = checkParams( $_POST['server'], $msg);
		$sql = " select * from t_game_server where `agentName`='{$server['agentName']}' and `serverId`='{$server['serverId']}' ";
		$rs = fetchRowOne($sql);
		if (empty($rs)) {
			$msg[] = "{$server['agentName']}s{$server['serverId']} 不存在，更新服务器失败！";
		}
		if (empty($msg)) {
			$sql = makeUpdatetSql('t_game_server', 'serverName', $server);
			$rs = dbQuery($sql);
			if (!$rs) {
				$msg[] = '更新服务器配置失败！';
			}
		}
		
		if (empty($msg)) {
			header('Location:?action=list');
		}
	}
	$server['serverOnlineDate'] = $server['serverOnlineDate'] ? date('Y-m-d',$server['serverOnlineDate']) : ''; 
	$server['serverCombineDate'] = $server['serverCombineDate'] ? date('Y-m-d',$server['serverCombineDate']) : ''; 
	$data = array(
		'action'=>$action,
		'server'=>&$server,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('server/admin_server_edit.tpl',$data);
	
}elseif ('view' == $action){
	$serverName = SS($_GET['serverName']);
	$sql = " select * from t_game_server where `serverName`='{$serverName}' ";
	$server = fetchRowOne($sql);
	
	$server['serverOnlineDate'] = $server['serverOnlineDate'] ? date('Y-m-d',$server['serverOnlineDate']) : ''; 
	$server['serverCombineDate'] = $server['serverCombineDate'] ? date('Y-m-d',$server['serverCombineDate']) : ''; 
	$data = array(
		'action'=>$action,
		'server'=>&$server,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('server/admin_server_view.tpl',$data);
	
}elseif ('list'==$action){
	
	$sql = "select * from t_game_server order by serverName";
	$server = fetchRowSet($sql);
	$data = array(
		'server'=>&$server,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	
	render('server/admin_server_list.tpl',$data);
	
}elseif ('delete'==$action){
	$serverName = trim($_GET['serverName']);
	$sql = " delete from t_game_server where `serverName`='{$serverName}' ";
	dbQuery($sql);
	header('Location:?action=list');
	exit();
}

//============

function checkParams($server, &$msg)
{
	if (is_array($server)) {
		foreach ($server as &$p) {
			$p = SS($p);
		}
	}
	$server['agentId'] = intval($server['agentId']);
	if ($server['agentId'] < 0 ) {
		$msg[] = '代理商ID必须填写正整数';
	}
	if ( !$server['agentName'] ) {
		$msg[] = '代理商代号必须填写';
	}
	$server['serverId'] = intval($server['serverId']);
	if ($server['serverId'] < 0 ) {
		$msg[] = '服务器索引号必须填写正整数';
	}
	if ( !$server['serverName'] ) {
		$msg[] = '服务器编号必须填写';
	}
	if (!$server['gameAdminUrl']) {
		$msg[] = '游戏管理后台URL基地址必须填写';
	}
	$server['serverOnlineDate'] = strtotime($server['serverOnlineDate']);
	if ( !$server['serverOnlineDate'] ) {
		$msg[] = '开服日期必须填写';
	}
	$server['serverCombineDate'] = strtotime($server['serverCombineDate']);
	$server['syncData'] = intval($server['syncData']);
	$server['syncData'] == 1 ? 1 : 0;
	return $server;
}
