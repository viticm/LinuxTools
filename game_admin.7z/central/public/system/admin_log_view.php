<?php
/**
 * @author linruirong@4399.com
 * @Created  Thu Dec 01 05:09:35 GMT 2011
 * @desc 管理后台日志查看
 */
require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';

$username = SS($_POST['username']);
$mType = intval($_POST['mType']);
$grep = intval($_POST['grep']); //过滤掉登录日志
if (!isPost()) {
	$grep = 1;
}
$dateStart = $_POST['dateStart'] ?  $_POST['dateStart'] : date('Y-m-d', strtotime('-6day')) ;
$dateEnd = $_POST['dateEnd'] ?  $_POST['dateEnd'] : date('Y-m-d') ;
$dateStartStamp = strtotime($dateStart);
$dateEndStamp   = strtotime($dateEnd) + 86399;

$where = " where true ";
if ($dateStartStamp && $dateEndStamp) {
	$where .= " and mTime BETWEEN {$dateStartStamp} and {$dateEndStamp} ";
}
if ($username) {
	$where.=" and `username`='{$username}' ";
}
if ($mType) {
	$where.=" and `mType`={$mType} ";
}
if ($grep) {
	$where.=" and `mType`!= " .AdminLog::LOG_TYPE_LOGIN ;
}

$sqlCnt = " select count(`id`) as cnt from t_log_admin {$where} ";
$rsCnt = fetchRowOne($sqlCnt);
$rowCount = intval($rsCnt['cnt']);

$rowPerPage = intval($_POST['rowPerPage']);
$rowPerPage = ( $rowPerPage >=10 && $rowPerPage <=100 ) ? $rowPerPage : LIST_PER_PAGE_RECORDS;
$page = intval($_POST['page']);
$page = $page>0 ? $page : 1;
$pageCount = ceil($rowCount/$rowPerPage);
$offset =  $rowPerPage *($page-1);
$pageList = getPages($page,$rowCount,$rowPerPage);

$sqlLog = " SELECT * FROM t_log_admin {$where} limit {$offset} , {$rowPerPage} ";
$rsLog = fetchRowSet($sqlLog);

foreach ($rsLog as &$row) {
	$row['mTime'] = date('Y-m-d H:i:s' , $row['mTime']);
	$row['mTypeText'] = AdminLog::$arrLogType[$row['mType']];
}

$data = array(
	'logs' => &$rsLog,
	'username' => $username,
	'mType' => $mType,
	'grep' => $grep,
	'dateStart' => $dateStart,
	'dateEnd' => $dateEnd,
	'rowPerPage' => $rowPerPage,
	'rowCount' => $rowCount,
	'pageCount' => $pageCount,
	'page' => $page,
	'dateEnd' => $dateEnd,
	'arrLogType'=>&AdminLog::$arrLogType,
	'pageList'=>&$pageList,
);
render('system/admin_log_view.tpl',$data);
