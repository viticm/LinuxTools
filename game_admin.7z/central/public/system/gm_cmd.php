<?php
/**
 * @author shuiyuandan@4399.com
 * @desc 批量执行GM指令
 */

require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');
require_once ('../../protected/class/socket_api.php');


if( $_POST )
{
    $msg = array();
    $batchSwitch = $_POST['batchSwitch'];
    if( count($batchSwitch) == 0 ) {
        $msg[] = "请至少选中一个游戏服务器";
    }
    
    $checkValAry = array();
    foreach( $batchSwitch as &$belem ) {
       $checkValAry[$belem] = true; 
    }
    $GmParam = $_POST['GmParam'];

    $retAry = array();

    //取服务器的后台IP和端口
    foreach( $batchSwitch as $sName ) {
        $sql = "select * from t_game_server where serverName='$sName' limit 1";
        $rs = fetchRowOne( $sql );

        $ip = $rs['serverIp'];
        $port = $rs['serverPort'];

        //处理每条GM指令
        $GmAry = split("\r\n", $GmParam);
        $idx = 0;
        foreach( $GmAry as $gmStr ) {
            $gmStr = trim( $gmStr );
            if( strlen( $gmStr ) == 0 ) {
                continue;
            }
            $GmAryData[$idx] = $gmStr;

            $sock = new ServerApi();
            $curRet = $sock->sendGmCmd( $ip, $port, $gmStr );
            $curRet['gmStr'] = $gmStr;
            $curRet['serverName'] = $sName;
            $retAry[$idx][] = $curRet;
            $idx++;
        }
    }
}

/******************************************
* 从Db获取服务器组信息
*******************************************/
$sql = "select * from t_game_server";
$server = fetchRowSet($sql);

//取平台列表
$sql = "select distinct(agentName) from t_game_server order by agentName";
$distinctAgent = fetchRowSet( $sql );
$agentAry = array();
foreach( $distinctAgent as $elemAgent ) {
    $agentAry[] = $elemAgent['agentName'];
}

$serverNameAry = array();
foreach( $agentAry as $agent ){
    $sql = "select serverName from t_game_server where agentName='$agent'";
    $serverNameRs = fetchRowSet( $sql );

    $tmpAry = array();
    foreach( $serverNameRs as $serverName ) {
        $tmpAry[] = $serverName['serverName'];
    }
    $tmpAry['agentName'] = $agent;
    $serverNameAry[] = $tmpAry;
}

$strMsg = empty($msg) ? '' : implode('<br />', $msg);

$data = array(
    'serverNameAry' => $serverNameAry,
    'strMsg'=>$strMsg,
    'GmParam'=>$GmParam,
    'batchSwitch'=>$batchSwitch,
    'checkValAry'=>$checkValAry,
    'retAry'=>$retAry,
    'SERVER_NAME'=>SERVER_NAME,
);

render('system/gm_cmd.tpl',&$data);

