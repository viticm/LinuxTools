<?php
/**
 * @author shuiyuandan@4399.com
 * @desc 服务器概况统计
 */

require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');

$interval = $_POST['interval'];
$times = $_POST['times'];
$content = $_POST['content'];

$startDatetime = strtotime( date('Y-m-d') );
if( $_POST )
{
    $msg = array();
	$startDatetime = strtotime($_POST['date']);
}

/******************************************
* 从Db获取服务器组信息
*******************************************/
$sql = "select * from t_game_server";
$server = fetchRowSet($sql);

//取平台列表
$sql = "select distinct(agentName) from t_game_server";
$distinctAgent = fetchRowSet( $sql );
$agentAry = array();
foreach( $distinctAgent as $elemAgent ) {
	$agentAry[] = $elemAgent['agentName'];
}

//取每个平台的服务器数目
$agentServerCount = array();
foreach( $agentAry as $agent ) {
	$agentServerCount[$agent] = 0;
	foreach( $server as $elem ) {
		if( $elem['agentName'] == $agent ){
			$agentServerCount[$agent]++;
		}
	}
}

//所有平台概况
$TotalInfo = array();
$TotalInfo['agentNum'] = count( $agentAry );
$TotalInfo['serverNum'] = count( $server );
$TotalInfo['totalAccount'] = 0;
$TotalInfo['totalRole'] = 0;
$TotalInfo['MaxOnlineNum'] = 0;
$TotalInfo['maxOnlineNumServerName'] = "default";
$TotalInfo['AvgOnlineNum'] = 0;
$TotalInfo['PayAccNum'] = 0;
$TotalInfo['MaxRoleLevel'] = 0;
$TotalInfo['maxRoleLevelServerName'] = "default";
$TotalInfo['avgArpu'] = 0;
$TotalInfo['lostRate'] = 0;
$TotalInfo['maxDayPay'] = 0;
$TotalInfo['maxDayPayServerName'] = "default";
$TotalInfo['totalPay'] = 0;


$serversInfo = array();
$lastAgent = "";
foreach( $server as $elem ){
	if( $elem['agentName'] != $lastAgent ){
		if( !empty($lastAgent) && $agentServerCount[$lastAgent] ){
			
			//计算平均数值
			$platSummary = &$serversInfo[ $lastAgent ]['platSummary'];
			$platSummary['newerLostRate'] = $platSummary['newerLostRate'] / $agentServerCount[$lastAgent];
			$platSummary['Arpu'] = $platSummary['Arpu'] / $agentServerCount[$lastAgent];
			$platSummary['AvgOnline'] = $platSummary['AvgOnline'] / $agentServerCount[$lastAgent];
			
			//计算全平台总共数据
			$TotalInfo['totalAccount'] +=  $platSummary['AccountNum'];
			$TotalInfo['totalRole'] +=  $platSummary['RoleNum'];
			$TotalInfo['AvgOnlineNum'] += $platSummary['AvgOnline'];//avg
			$TotalInfo['PayAccNum'] += $platSummary['PayAccNum'];
			$TotalInfo['avgArpu'] += $platSummary['Arpu'];//avg
			$TotalInfo['lostRate'] += $platSummary['newerLostRate'];//avg
			$TotalInfo['totalPay'] += $platSummary['TotalPay'];
			
			if( intval($TotalInfo['MaxOnlineNum']) < intval($platSummary['MaxOnline'])  ) {
				
				$TotalInfo['MaxOnlineNum'] = $platSummary['MaxOnline'];
				$TotalInfo['maxOnlineNumServerName'] = $platSummary['MaxOnlineServerName'];
			}
			if( intval($TotalInfo['MaxRoleLevel']) < intval($platSummary['RoleMaxLv'])  ) {
				$TotalInfo['MaxRoleLevel'] = $platSummary['RoleMaxLv'];
				$TotalInfo['maxRoleLevelServerName'] = $platSummary['RoleMaxLvServerName'];
			}
			if( intval($TotalInfo['maxDayPay']) < intval($platSummary['maxDayPay'])  ) {
				$TotalInfo['maxDayPay'] = $platSummary['maxDayPay'];
				$TotalInfo['maxDayPayServerName'] = $platSummary['maxDayPayServerName'];
			}
		}
	
		$lastAgent = $elem['agentName'];
		$lastServerCount = 0;
	}
	if( empty( $serversInfo[ $elem['agentName'] ]['platSummary'] )) {
		$serversInfo[ $elem['agentName'] ]['platSummary'] = array();
		$platSummary = &$serversInfo[ $elem['agentName'] ]['platSummary'];
		$platSummary['platName'] = $elem['agentName'];
		$platSummary['AccountNum'] = 0;
		$platSummary['RoleNum'] = 0;
		$platSummary['RoleMaxLv'] = 0;
		$platSummary['newerLostRate'] = 0;
		$platSummary['TotalPay'] = 0;
		$platSummary['PayAccNum'] = 0;
		$platSummary['Arpu'] = 0;
		$platSummary['maxDayPay'] = 0;
		$platSummary['AvgOnline'] = 0;
		$platSummary['MaxOnline'] = 0;
		$platSummary['RoleMaxLvServerName'] = "";
		$platSummary['maxDayPayServerName'] = "";
		$platSummary['MaxOnlineServerName'] = "";
		$platSummary['ServerNum'] = 0;
		
	}
	$platSummary = &$serversInfo[ $elem['agentName'] ]['platSummary'];
	// 取中央后台数据库中缓存的服务器概况信息
	$serverName = $elem['serverName'];
	$sql = "select * from t_servers_summary where serverName ='$serverName' and updateTime='$startDatetime' limit 1";
	$summaryInfo = fetchRowOne( $sql );
	$summary = json_decode( $summaryInfo['summaryJson'], true );
	if( count($summaryInfo) ) {
		$elem['summary'] = $summary;
		$platSummary = $serversInfo[ $elem['agentName'] ]['platSummary'];
		$platSummary['AccountNum'] += $summary['summary']['totalAccount'];
		$platSummary['RoleNum'] += $summary['summary']['totalRole'];

		$platSummary['newerLostRate'] += $summary['summary']['totalLost'];//avg
		$platSummary['TotalPay'] += $summary['summary']['totalPay'];
		$platSummary['PayAccNum'] += $summary['summary']['totalPayRole'];
		$platSummary['Arpu'] += $summary['summary']['totalAvgArpu'];//avg
		$platSummary['AvgOnline'] += $summary['summary']['totalAvgOnline'];//avg
		if( intval($summary['summary']['maxRoleLevel']) > intval($platSummary['RoleMaxLv']) ){
			$platSummary['RoleMaxLv'] = $summary['summary']['maxRoleLevel'];
			$platSummary['RoleMaxLvServerName'] = $elem['serverName'];
		}
		if( intval($summary['summary']['maxTotalPay']) > intval($platSummary['maxDayPay']) ) {
			$platSummary['maxDayPay'] = $summary['summary']['maxTotalPay'];
			$platSummary['maxDayPayServerName'] = $elem['serverName'];
		}
		
		if( intval($summary['summary']['totalMaxOnline']) > intval($platSummary['MaxOnline']) ) {
			$platSummary['MaxOnline'] = $summary['summary']['totalMaxOnline'];
			$platSummary['MaxOnlineServerName'] = $elem['serverName'];
		}

		$lastServerCount++;
	}
	
	$platSummary['ServerNum']++;
	$serversInfo[ $elem['agentName'] ][] = $elem;
}

if( false && !empty($lastAgent) && $agentServerCount[$lastAgent] ){
		
	//计算平均数值
	$platSummary = &$serversInfo[ $lastAgent ]['platSummary'];
	$platSummary['newerLostRate'] = $platSummary['newerLostRate'] / $agentServerCount[$lastAgent];
	$platSummary['Arpu'] = $platSummary['Arpu'] / $agentServerCount[$lastAgent];
	$platSummary['AvgOnline'] = $platSummary['AvgOnline'] / $agentServerCount[$lastAgent];
	
	//计算全平台总共数据
	$TotalInfo['totalAccount'] +=  $platSummary['AccountNum'];
	$TotalInfo['totalRole'] +=  $platSummary['RoleNum'];
	$TotalInfo['AvgOnlineNum'] += $platSummary['AvgOnline'];//avg
	$TotalInfo['PayAccNum'] += $platSummary['PayAccNum'];
	$TotalInfo['avgArpu'] += $platSummary['Arpu'];//avg
	$TotalInfo['lostRate'] += $platSummary['newerLostRate'];//avg
	$TotalInfo['totalPay'] += $platSummary['TotalPay'];
	
	if( intval($TotalInfo['MaxOnlineNum']) < intval($platSummary['MaxOnline'])  ) {
		
		$TotalInfo['MaxOnlineNum'] = $platSummary['MaxOnline'];
		$TotalInfo['maxOnlineNumServerName'] = $platSummary['MaxOnlineServerName'];
	}
	if( intval($TotalInfo['MaxRoleLevel']) < intval($platSummary['RoleMaxLv'])  ) {
		$TotalInfo['MaxRoleLevel'] = $platSummary['RoleMaxLv'];
		$TotalInfo['maxRoleLevelServerName'] = $platSummary['RoleMaxLvServerName'];
	}
	if( intval($TotalInfo['maxDayPay']) < intval($platSummary['maxDayPay'])  ) {
		$TotalInfo['maxDayPay'] = $platSummary['maxDayPay'];
		$TotalInfo['maxDayPayServerName'] = $platSummary['maxDayPayServerName'];
	}
}

$TotalInfo['AvgOnlineNum'] = $TotalInfo['serverNum'] <= 0? 0: $TotalInfo['AvgOnlineNum']/$TotalInfo['serverNum'];//avg
$TotalInfo['avgArpu'] = $TotalInfo['serverNum'] <= 0? 0: $TotalInfo['avgArpu']/$TotalInfo['serverNum'];//avg
$TotalInfo['lostRate'] = $TotalInfo['serverNum'] <= 0? 0: $TotalInfo['lostRate']/$TotalInfo['serverNum'];//avg
	
$strMsg = empty($msg) ? '' : implode('<br />', $msg);

$data = array(
	'serversInfo' => $serversInfo,
	'agentAry' => $agentAry,
    'strMsg'=>$strMsg,
    'date'=>$startDatetime,
    'totalInfo'=>$TotalInfo,
    'SERVER_NAME'=>SERVER_NAME,
);

//print_r($data);

render('analysis/server_summary.tpl',&$data);
