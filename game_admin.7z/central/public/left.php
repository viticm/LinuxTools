<?php
include_once '../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE."/global.php";
include_once SYSDIR_ADMIN_CLASS."/menu.php";

$objMenu = new Menu();
$menu = $objMenu->getMyMenu();
$data = array(
	'menu' => $menu
);
render('left.tpl', $data);