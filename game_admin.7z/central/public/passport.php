<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Oct 31 02:48:29 GMT 2011
 * @desc 此用于与登录授权系统对接
 */
include_once '../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE."/global.php";

$time =  $_POST['time'];
$userInfo = $_POST['userInfo'];
$ticket = $_POST['ticket'];
$key = md5(GATEWAY_SYSTEM_AUTH_KEY.$time.$userInfo);

// 登录授权结果 1=成功, 2=超时, 3=参数不全 , 4=ticket错误 
if ( abs(time()-$time) > 60) { //登录超时
	$result = 2;
}elseif (!$ticket||!$time||!$userInfo){
	$result = 3;
}elseif($ticket != $key) {
	$result = 4;
}else {
	$result = 1;
	$userInfo = base64_decode(base64_decode($_POST['userInfo']));
	$userInfo = json_decode($userInfo, true);
	setSession('user',$userInfo);
}

$action = 'changeToCentralAdmin';
$ticket = md5(GATEWAY_SYSTEM_AUTH_KEY.$action.$time.$result);
$url = GATEWAY_SYSTEM_URL."passport.php?action={$action}&time={$time}&result={$result}&ticket={$ticket}";
header("Location:{$url}");
die();