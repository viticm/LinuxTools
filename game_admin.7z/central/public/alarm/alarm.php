<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Oct 31 09:17:30 GMT 2011
 * @desc 游戏管理后台服务器管理
 */
require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');
require_once ('../../protected/dict/goods.php');
require_once ('../../protected/dict/item_type.php');
require_once ('../../protected/include/alarm_define.php');

$action = $_GET['action'];
$action = $action ? $action : 'list';

$nowItemType[0] = "【所有产出】";
foreach( $dictItemType as $k => $value ){
	$nowItemType[$k] = $value;
}

if( isPost() ){
	if( !empty( $_POST['batchAction'] ) ){
		$action = $_POST['batchAction'];
	}
	$batchIdAry = $_POST['batchSwitch'];
	if( empty($batchIdAry) ){
		$batchIdAry = array();
	}
	$uidList = "(". implode( ",", $batchIdAry ) . ")";
}
if( 'batchClose' == $action ){
	if( !empty($batchIdAry) ){
		$sql = "update t_alarm set switch=0 where uid in $uidList";
		dbQuery( $sql );
	}
	header('Location:?action=list');
	exit();
}else if( 'batchOpen' == $action ) {
	if( !empty($batchIdAry) ){
		$sql = "update t_alarm set switch=1 where uid in $uidList";
		dbQuery( $sql );
	}
	header('Location:?action=list');
	exit();
}else if( 'batchDel' == $action ) {
	if( !empty($batchIdAry) ){
		$sql = "delete from t_alarm where uid in $uidList";
		dbQuery( $sql );
	}
	header('Location:?action=list');
	exit();	
}
else if ('add' == $action) {
	
	if (isPost()) {
		$server = checkParams( $_POST['server'], $msg);
		if (empty($msg)) {
			$sql = makeInsertSql('t_alarm', $server);
			$rs = dbQuery($sql);
			if (!$rs) {
				$msg[] = '添加服务器配置失败！';
			}
		}
		if (empty($msg)) {
			header('Location:?action=list');
		}
	}
	
	$arrItems = &$dictGoods;
	$sql = "select serverName from t_game_server";
	$serverList = fetchRowSet($sql);
	
	$sql = "select distinct(agentName) from t_game_server";
	$agentList = fetchRowSet($sql);
	
	$data = array(
		'action'=>$action,
		'server'=>&$server,
		'serverList'=>$serverList,
		'agentList'=>$agentList,
		'arrItems'=>$arrItems,
		'arrMtype'=>$nowItemType,
		'alarmModeDic'=>$alarmModeDic,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('alarm/alarm_edit.tpl',$data);
	
}elseif ('saveAs' == $action) {
	
	if (!isPost()) {
		$uid = SS($_GET['uid']);
		$sql = " select * from t_alarm where `uid`='{$uid}' ";
		$server = fetchRowOne($sql);
		$server['switch'] = 0; //默认为不开启同步
		$server['uid'] = null;
		$itemId = $server['itemId'];
		$server['itemName'] = $dictGoods[ $itemId ]['name'];
		
	}else{
		$server = checkParams( $_POST['server'], $msg);
		if (empty($msg)) {
			$sql = makeInsertSql('t_alarm', $server);
			$rs = dbQuery($sql);
			if (!$rs) {
				$msg[] = '添加服务器配置失败！';
			}
		}
		if (empty($msg)) {
			header('Location:?action=list');
		}
	}

	$sql = "select serverName from t_game_server";
	$serverList = fetchRowSet($sql);	
	$sql = "select distinct(agentName) from t_game_server";
	$agentList = fetchRowSet($sql);

	$data = array(
		'action'=>$action,
		'agentList'=>$agentList,
		'server'=>&$server,
		'serverList'=>&$serverList,
		'arrMtype'=>$nowItemType,
		'alarmModeDic'=>$alarmModeDic,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('alarm/alarm_edit.tpl',$data);
	
}elseif ('update' == $action){
	if (!isPost()) {
		$uid = SS($_GET['uid']);
		$sql = " select * from t_alarm where `uid`='{$uid}' ";
		$server = fetchRowOne($sql);
		$itemId = $server['itemId'];
		$server['itemName'] = $dictGoods[ $itemId ]['name'];			
	}else {
		$server = checkParams( $_POST['server'], $msg);
		$uid = $server['uid'];
		$sql = "select * from t_alarm where `uid`='{$uid}'";
		$rs = fetchRowOne($sql);
		if (empty($rs)) {
			$msg[] = "{$server['agentName']}s{$server['serverId']} 不存在，更新服务器失败！";
		}

		if (empty($msg)) {
			$sql = makeUpdatetSql('t_alarm', 'uid', $server);
			$rs = dbQuery($sql);
			if (!$rs) {
				$msg[] = '更新服务器配置失败！';
			}
		}
		
		if (empty($msg)) {
			header('Location:?action=list');
		}
	}
	
	$arrItems = &$dictGoods;
	$sql = "select serverName from t_game_server";
	$serverList = fetchRowSet($sql);
	$sql = "select distinct(agentName) from t_game_server";
	$agentList = fetchRowSet($sql);
	
	$server['serverOnlineDate'] = $server['serverOnlineDate'] ? date('Y-m-d',$server['serverOnlineDate']) : ''; 
	$data = array(
		'action'=>$action,
		'server'=>&$server,
		'serverList'=>$serverList,
		'agentList'=>$agentList,
		'arrItems'=>$arrItems,
		'arrMtype'=>$nowItemType,
		'alarmModeDic'=>$alarmModeDic,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	
	
	render('alarm/alarm_edit.tpl',$data);
	
}elseif ('view' == $action){
	$uid = SS($_GET['uid']);
	$sql = " select * from t_alarm where `uid`='{$uid}' ";
	$server = fetchRowOne($sql);
	$itemId = $server['itemId'];
	$server['itemName'] = $dictGoods[ $itemId ]['name'];
	$data = array(
		'action'=>$action,
		'server'=>&$server,
		'alarmModeDic'=>$alarmModeDic,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('alarm/alarm_view.tpl',$data);
	
}elseif ('list'==$action){

	$sql = "select * from t_alarm";
	$server = fetchRowSet($sql);
	foreach( $server as &$elem ){
		$itemId = $elem['itemId'];
		$elem['itemName'] = $dictGoods[ $itemId ]['name'];
		$mType = $elem['mType'];
		$elem['mName'] = $nowItemType[ $mType ];
		$elem['lastUpdate'] = intval( $elem['lastUpdate'] );
		$elem['mode'] = $alarmModeDic[ intval( $elem['mode'] ) ];
	}
	
	$data = array(
		'server'=>&$server,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	
	render('alarm/alarm_list.tpl',$data);
	
}elseif ('delete'==$action){
	$uid = trim($_GET['uid']);
	$sql = " delete from t_alarm where `uid`='{$uid}' ";
	dbQuery($sql);
	header('Location:?action=list');
	exit();
}

//============

function checkParams($server, &$msg)
{
	if (is_array($server)) {
		foreach ($server as &$p) {
			$p = SS($p);
		}
	}
	
	global $dictGoods;
	
	//物品ID验证
	if ( !$server['itemId'] || !intval( $server['itemId'] ) || !$dictGoods[ $server['itemId'] ]) {
		$msg[] = '物品id非法:';
	}
	
	if( !$server['amount'] ) {
		$msg[] = '阈值设置非法';
	}
	
	if( !$server['interval'] ) {
		$msg[] = '间隔设置非法';
	}
	
	if( $server['plat'] == "" ) {
		$msg[] = "平台或服务器选择失败";
	}
	
	global $BY_SERVER;
	global $BY_ALL ;
	global $BY_AGENT;
	if( intval($server['plat']) == $BY_AGENT ){
		$server['serverName'] = "";
	}elseif( intval($server['plat']) == $BY_SERVER){
		$server['agentName'] = "";
	}else{
		$server['agentName'] = "";
		$server['serverName'] = "";
	}
	
	unset( $server['plat'] );
	
	$server['switch'] = intval($server['switch']);
	$server['switch'] == 1 ? 1 : 0;

	return $server;
}