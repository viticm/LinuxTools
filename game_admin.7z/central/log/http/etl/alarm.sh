#!/bin/bash

export LANG="en_US.UTF-8"
curDir=`dirname ${0}`
cd ${curDir}
phpPath='/usr/local/php/bin/php'


${phpPath} alarm_item.php >> "${curDir}/crontab.log" 2>&1 &
