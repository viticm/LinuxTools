#!/bin/bash
# Ϊ�����̨��ȡ����
export LANG="en_US.UTF-8"
curDir=`dirname ${0}`
cd ${curDir}
phpPath='/usr/local/php/bin/php'

scripts=([0]="sync_servers_summary.php")
      
for program in ${scripts[*]}
do
	${phpPath} ${program}  >> "${curDir}/crontab.log" 2>&1 &
done      