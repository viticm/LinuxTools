<?php
/**
 * @author shuiyuandan@4399.com
 * @desc 用于同步服务器概况到中央后台。
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');
include_once(SYSDIR_ADMIN_CLASS.'/agent_server.php');
include_once('../log_template.php');

$gameAdminUrl = 'api/central/sync_servers_summary.php'; //管理后台对应接口的相对地址

$objLogTemplate = new LogTemplate();
$servers = $objLogTemplate->getGameAdminUrl($gameAdminUrl);

//取当前天的时间
$now = strtotime( date('Y-m-d', time()) );

foreach ($servers as $server) {
	$startTick = time();
	$result = $objLogTemplate->getGameAdminData($server['gameAdminApiUrl'], 10);
	$useTime = time() - $startTick;
	if( $result['result'] && $result['result'] == 1 && $result['data'] ) {
		$data = $result['data'];
		$jsonResult = SS(json_encode($data));
		$serverName = $data['summary']['SERVER_NAME'];
		//将获取到的统计数据，存放到中央后台的数据库中
		$sql = "insert into t_servers_summary (serverName, summaryJson, updateTime) values ( '$serverName', '$jsonResult', $now )";
		dbQuery($sql);
		echo "[".date("Y-m-d H:i:s", time())."][". $useTime . "][".$serverName."]: ".$sql."\n";
	}else
	{
		//出错
		echo "[".date("Y-m-d H:i:s", time())."]";
		echo "[ERROR] sync_servers_summary.php start ============================= ";
		echo "result: ";
		print_r( $result );
		echo "server: ";
		print_r( $server );
		echo "[ERROR] sync_servers_summary.php end ============================= ";
	}

}