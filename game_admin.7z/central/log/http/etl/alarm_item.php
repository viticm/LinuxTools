<?

include_once('../../../protected/config/config.php');
include_once('../../../protected/dict/goods.php');
include_once('../../../protected/dict/item_type.php');
require_once ('../../../protected/include/alarm_define.php');
include_once('../log_global.php');

//从t_alarm中查询出相关结果
$sql = "select * from t_alarm where `switch`=1";
$rs = fetchRowSet($sql);

$logAry = array();
$alarmAry = array();

function add_log( $serverName,  $logStr ){
    global $logAry;
    $dateStr = date("[Y-m-d H:i:s]", time() );
    $logAry[] = $dateStr." 【".$serverName."】 ".$logStr."\n";
}

function add_alarm( $serverName, $logStr ){
    global $alarmAry;
    $dateStr = date("[Y-m-d H:i:s]", time() );
    $alarmAry[] = $dateStr." 【".$serverName."】 ".$logStr."\n";
}

$produceStr = getProduceStr();

$now = time();
//分别取数据库
foreach( $rs as &$elem ){
    $uid = $elem['uid'];
    //add_log( "" ,  "start uid: ".$uid  );

    $serverNameList = array();
    //筛选服务器列表
    if( !empty( $elem['serverName'] ) ){
        $serverNameList[] = $elem['serverName'];
    }elseif( !empty( $elem['agentName'] ) ) {
        $sql = "select distinct(serverName) from t_game_server where agentName='".$elem['agentName']."'";
        $serverListRs = fetchRowSet( $sql );
        foreach( $serverListRs as $elemServer  ){
            $serverNameList[] = $elemServer['serverName'];
        }
    }else{
        $sql = "select distinct(serverName) from t_game_server ";
        $serverListRs = fetchRowSet( $sql );
        foreach( $serverListRs as $elemServer  ){
            $serverNameList[] = $elemServer['serverName'];
        }
    }
        
    $needUpdateTime = false;
        
    //遍历所有服务器
    foreach( $serverNameList as $serverName ) {
        //add_log( $elem['serverName'],  "start uid: ".$uid  );
        $sql = "select * from t_game_server where `serverName`='$serverName'";
        $tmpRs = fetchRowOne( $sql );
        $curDbName = $tmpRs['serverDB'];
        $elem['serverDB'] = $curDbName;

        if( empty($curDbName) )
        {
            add_log( $serverName,  "[ERR] uid: ".$elem['uid']." var dbName not exists." );
            continue;
        }

        //预警项
        if( $now - intval($elem['lastUpdate']) < intval( $elem['interval']) ){
            add_log( $serverName, " $now - ".intval($elem['lastUpdate']) ." < ".intval( $elem['interval']) );
            continue;
        }
        
        if( $now - intval($elem['lastUpdate']) >= intval( $elem['interval']) ){
            //取当前服务器后台日志更新时间
            $sql = "select lastLoadTime from $curDbName.t_load limit 1;";
            $lastLoadRs = fetchRowOne( $sql );
            $lastLoadTick = intval( $lastLoadRs['lastLoadTime'] ) - 60; //因为load数据到后台数据库的间隔是1分钟
            //构造条件
            $where = " true ";
            if( $elem['mType'] != 0 ){
                $where .= " and mType = ".$elem['mType'];
            }else {
                $where .= " and mType in ".$produceStr;
            }
            $where .= " and itemId=".$elem['itemId'];
            $beginTime = $lastLoadTick - intval( $elem['interval'] );
            $endTime = $lastLoadTick;
            $where .= " and mTime >= $beginTime and mTime < $endTime";

            $limit = intval( $elem['amount'] );
            if( empty($limit) ){
                $debugStr = sprintf("uid: %d, limit null", $uid);
                add_log( $serverName, "【WARN】 ".$debugStr );
                continue;
            }
            
            $needUpdateTime = true;
            
            //按玩家
            if( intval($elem['mode']) == $ALARM_MODE_PLAYER ) {
                $sql = "select distinct(accountName),sum(amount) as nowVal from $curDbName.t_log_item where $where group by accountName";
                add_log( $serverName,  "[SQL] uid=$uid $sql" );
                $tmpRs = fetchRowSet( $sql );
                if( empty( $tmpRs ) ) {
                    add_log( $serverName, " result empty. " );
                    continue;
                }
                foreach( $tmpRs as $sub_elem ) {
                    $nowVal = intval( $sub_elem['nowVal'] );
                    $acc = $sub_elem['accountName'];
                    $mType = $elem['mType'];
                    if( $mType == 0 ){
                        $mName = "所有产出";
                    }else{
                        $mName = $dictItemType[ $mType ];
                    }
                    $itemId = $elem['itemId'];
                    $itemName = $dictGoods[$itemId]['name'];

                    $alarmStr = sprintf("Account: %s mType: [%s][%s] item: [%d][%s] interval: %d now: %d limit: %d", $acc, $mType, $mName, 
                        $itemId, $itemName, $elem['interval'], $nowVal, $limit );
                    if( $nowVal < $limit ) {
                        add_log( $serverName, $alarmStr );
                    }else{           
                        add_alarm( $serverName, $alarmStr );
                        add_log( $serverName, "【WARN】 ".$alarmStr );
                    }
                }//foreach
            }else{
                //按服务器
                $sql = "select sum(amount) as totalAmount from $curDbName.t_log_item where $where";
                $tmpRs = fetchRowOne( $sql );
                add_log( $serverName,  "[SQL] uid=$uid $sql" );
                if( empty( $tmpRs ) ){
                    add_log( $serverName, " result empty. " );
                    continue;
                }
                
                $totalAmount = intval( $tmpRs['totalAmount'] );
                if( empty( $totalAmount ) ) {
                    $totalAmount = 0;
                    continue;
                }
                $needUpdateTime = true;
                $mType = $elem['mType'];
                if( $mType == 0 ){
                    $mName = "所有产出";
                }else{
                    $mName = $dictItemType[ $mType ];
                }
                $itemId = $elem['itemId'];
                $itemName = $dictGoods[$itemId]['name'];

                if( $totalAmount >= $limit){
                    $alarmStr = sprintf("mType: [%s][%s] item: [%d][%s] interval: %d now: %d limit: %d", $mType, $mName, 
                        $itemId, $itemName, $elem['interval'], $totalAmount, $limit );
                    add_alarm( $serverName, $alarmStr );
                    add_log( $serverName, "【WARN】 ".$alarmStr );
                }else {
                    $alarmStr = sprintf("mType: [%s][%s] item: [%d][%s] interval: %d now: %d limit: %d", $mType, $mName, 
                        $itemId, $itemName, $elem['interval'], $totalAmount, $limit );
                    add_log( $serverName, $alarmStr );
                }
                
            }
        }
    }

    //更新检查时间
    if($needUpdateTime){
        $sql = "update t_alarm set lastUpdate=$now where uid=${elem['uid']}";
        dbQuery( $sql );
    }
}//foreach

$logDir = "/data/web/log/alarm_log.log";
$alarmLogDir = "/data/web/log/alarm.log";

foreach( $logAry as $log ) {
    file_put_contents($logDir, $log, FILE_APPEND );
}

foreach( $alarmAry as $log ) {
    file_put_contents($alarmLogDir, $log, FILE_APPEND );
}