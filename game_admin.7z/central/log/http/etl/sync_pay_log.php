<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Jan 31 06:12:22 GMT 2012
 * @desc 用于同步充值日志到中央后台。
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');
include_once(SYSDIR_ADMIN_CLASS.'/agent_server.php');
include_once('../log_template.php');

$gameAdminUrl = 'api/central/sync_pay_log.php'; //管理后台对应接口的相对地址

$objLogTemplate = new LogTemplate();
$servers = $objLogTemplate->getGameAdminUrl($gameAdminUrl);

foreach ($servers as $server) {
	$result = $objLogTemplate->getGameAdminData($server['gameAdminApiUrl'], 5);
	print_r($result);
}