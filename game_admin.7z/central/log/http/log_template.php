<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Jan 31 09:24:34 GMT 2012
 * @desc 用于格式化处理游戏管理后台的http接口地址
 */
include_once(SYSDIR_ADMIN_CLASS.'/agent_server.php');
class LogTemplate{
	
	/**
	 * Enter description here...
	 *
	 * @param unknown_type $url
	 * @param unknown_type $params
	 * @return unknown
	 */
	function getGameAdminUrl($url, $params=array())
	{
		$strParams = '';
		if (is_array($params)) {
			foreach ($params as $key=>$val) {
				$strParams .= "&{$key}=".urlencode($val);
			}
		}
		$objAgentServer = new AgentServer();
		$servers = $objAgentServer->getLogSyncServer();
		$reqTime = time();
		foreach ($servers as &$server) {
			$ticket = md5($server['gameAdminAuthKey'].$reqTime.$server['serverName']);
			$server['gameAdminApiUrl'] = $server['gameAdminUrl'].$url."?reqTime={$reqTime}&currentServerName={$server['serverName']}&ticket={$ticket}".$strParams;
		}
		return $servers;
	}
	
	/**
	 * 用于向游戏管理获取数据
	 *
	 * @param string $url
	 * @param intval $timeout
	 * @return string
	 */
	function getGameAdminData($url, $timeout)
	{
		$ch = curl_init(); 
		curl_setopt($ch,CURLOPT_URL,$url); 
		curl_setopt($ch,CURLOPT_HEADER,0); 
		curl_setopt($ch,CURLOPT_TIMEOUT,$timeout); 
		curl_setopt($ch,CURLOPT_RETURNTRANSFER, true); 
		$content = curl_exec($ch); 
		curl_close($ch);
		return json_decode($content, true);
	}
}