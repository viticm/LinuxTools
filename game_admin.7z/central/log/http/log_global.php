<?php
/**
 * @author linruirong@4399.com
 * @copyright www.4399.com
 * @desc 引用此文件，则只能用于命令行下的操作
 */

if( substr(php_sapi_name(),0,3) !== 'cli'){
	die("This Programe can only be run in CLI mode\n");
}

//时间设置
date_default_timezone_set(TIME_ZONE);
include_once SYSDIR_ADMIN_CLASS."/mysql.php";
include_once SYSDIR_ADMIN_INCLUDE."/functions.php";
include_once SYSDIR_ADMIN_INCLUDE."/db_functions.php";

global $db;
//初始化管理后台数据库连接
if(!$db) {
	$db =  new Mysql();
	$db->connect($dbConfig);
	if (!$db) {
		die('无法连接数据库');
	}
}