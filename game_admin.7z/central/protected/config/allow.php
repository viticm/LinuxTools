<?php
/**
 * 注意！
 * 此两数组作用是用于权限管理
 */


// 不管用户有没登录都可以访问的页面：
// 注意 此配置项 不清楚业务规则 绝对不能乱加！
global $ALLOW_ACCESS_PAGE; 
$ALLOW_ACCESS_PAGE = array(
	'passport.php',
);

// 已经登录的用户都可以访问的页面：
// 注意 此配置项 不清楚业务规则 绝对不能乱加！
global $LOGIN_ALLOW_ACCESS_PAGE; 
$LOGIN_ALLOW_ACCESS_PAGE = array(
	'left.php',
	'main.php',
);