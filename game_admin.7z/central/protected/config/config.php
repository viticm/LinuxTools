<?php
//=============定义各目录常量=========//
define('SYSDIR_ADMIN', realpath(dirname(__FILE__).'/../../')); //根目录
define('SYSDIR_ADMIN_PROTECTED', SYSDIR_ADMIN.'/protected'); //受保护(拒绝WEB访问)目录
define('SYSDIR_ADMIN_PUBLIC', SYSDIR_ADMIN.'/public'); //公共(允许WEB访问)目录
define('SYSDIR_ADMIN_CONFIG', SYSDIR_ADMIN_PROTECTED.'/config'); //类目录
define('SYSDIR_ADMIN_CLASS', SYSDIR_ADMIN_PROTECTED.'/class'); //类目录
define('SYSDIR_ADMIN_INCLUDE', SYSDIR_ADMIN_PROTECTED.'/include'); //引用
define('SYSDIR_ADMIN_LIBRARY', SYSDIR_ADMIN_PROTECTED.'/library'); //第三方库
//=====================================//

//=========smarty相关配置==============//
define('SYSDIR_ADMIN_SMARTY_TEMPLATE', SYSDIR_ADMIN_PROTECTED.'/template'); //smarty模版目录
define('SYSDIR_ADMIN_SMARTY_TEMPLATE_C', SYSDIR_ADMIN_PROTECTED.'/template_c'); //smarty编译目录
define('SMARTY_COMPILE_CHECK', true);
define('SMARTY_FORCE_COMPILE', true);
define('SMARTY_LEFT_DELIMITER', '<{');
define('SMARTY_RIGHT_DELIMITER', '}>');
//===================================//

//===============================//
define('TIME_ZONE', 'PRC');  //时区设置
define('SESSION_KEY', 'sessAdminCentral'); //系统session key
//===============================//

//==========页面显示的定义=========//
define('LIST_PER_PAGE_RECORDS', 20); //Search page show ... records per page
define('LIST_SHOW_PREV_NEXT_PAGES', 10); //First Prev 1 2 3 4 5 6 7 8 9 10... Next Last
//===============================//

//==============日志相关设置==========//
define('SYSDIR_LOG','/data/logs/yjxy'); //存放路径
define('SYSFILE_LOG_FILE',SYSDIR_LOG.'/admin_central.log'); //系统运行日志
define('LOG_LEVEL',1); //日志级别 1:debug,info,error都会记录, 2: info,error , 3: error
//==================================//

//==============服务器常量==========//
define('GATEWAY_SYSTEM_AUTH_KEY', 'b97c92ab1c955551d12aa135f7270e5c');//与登录授权系统校验的key
define('GATEWAY_SYSTEM_URL', 'http://admin.yjxy.local.com/'); //登录授权系统地址
//==================================//

//包含配置文件
include_once 'db.php';
