<?php
global $dbConfig;
$dbConfig = array(
        'host' => 'localhost',
        'user' => 'root',
        'passwd' => '111111',
	'dbname' => 'admin_central',
);
