<?php
////////////////////////////////////////////////////////////

/**
 * 管理后台数据库 执行SQL查询
 * @param $sql
 */
function dbQuery ($sql){
	global $db;
	return $db->query($sql);
}
/**
 * 管理后台数据库 执行SQL查询，获取结果集的第一行
 * @param $sql
 */
function fetchRowOne ($sql){
	global $db;
	return $db->fetchOne($sql);
}

/**
 * 管理后台数据库 执行SQL查询，获取结果集的全部
 * @param $sql
 */
function fetchRowSet($sql){
	global $db;
	return $db->fetchAll($sql);
}

function makeInsertSql($table, $data)
{
	if (!is_array($data) || !$table) {
		return false;
	}
	$sql = '';
	$sqlKey = '';
	$sqlVal = '';
	foreach ($data as $key => $val) {
		if ($key) {
			$sqlKey .= "`{$key}`, ";
			$sqlVal .= "'{$val}', ";
		}
	}
	$sqlKey = trim($sqlKey, ', ');
	$sqlVal = trim($sqlVal, ', ');
	
	if ($sqlKey && $sqlVal) {
		$sql = " insert into {$table} ({$sqlKey}) values ({$sqlVal}) ";
	}
	return $sql;
}

function makeUpdatetSql($table, $primaryKey, $data)
{
	if (!is_array($data) || !$primaryKey || !$table) {
		return false;
	}
	$sqlSet = '';
	$sqlWhere = '';
	foreach ($data as $key => $val) {
		if ($key) {
			if ($key == $primaryKey) {
				$sqlWhere = " where `{$key}`='{$val}' ";
			}else {
				$sqlSet .= "`{$key}`='{$val}', ";
			}
		}
	}
	$sqlSet = trim($sqlSet, ', ');
	if ($sqlSet) {
		$sql = " update {$table} set {$sqlSet} {$sqlWhere}  ";
	}
	return $sql;
}

////////////////////////////////////////////////////////////
///分页显示的常用操作方法
/**
 * 查询结果的分页列表
 * 参数： 当前第几页， 总共多少条记录， 每页显示多少条记录
 */
function getPages($page, $recordCount, $perPageRecord = LIST_PER_PAGE_RECORDS) {
	$recordCount = intval($recordCount);
	$total_page = ceil($recordCount / $perPageRecord);
	if ($total_page < 2){
		return array();
	}
    $start=max(1, $page-(int)(LIST_SHOW_PREV_NEXT_PAGES/2));
    if(($end=$start+LIST_SHOW_PREV_NEXT_PAGES-1)>=$total_page)
    {
        $end=$total_page;
        $start=max(1,$end-LIST_SHOW_PREV_NEXT_PAGES+1);
    }
	$arr['首页'] = 1;
	$arr['上页'] = ($page > 1) ? ($page -1) : 1;
	for ($i = $start; $i <= $end; $i++) {
		if ($i == $page)
			$arr["<font color=red>{$i}</font>"] = $i;
		else
			$arr[$i] = $i;
	}
	$arr['下页'] = ($page < $total_page) ? ($page +1) : $total_page;
	$arr['末页'] = $total_page;
	return $arr;
}
