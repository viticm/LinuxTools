<?php

$ALARM_MODE_PLAYER = 0;
$ALARM_MODE_SERVER = 1;

$alarmModeDic = array( $ALARM_MODE_PLAYER => "按玩家",
						$ALARM_MODE_SERVER => "全服");
						
$BY_AGENT = 0;
$BY_SERVER = 1;
$BY_ALL = 2;