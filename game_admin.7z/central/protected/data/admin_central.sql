SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

create database admin_central;
use admin_central;

CREATE TABLE IF NOT EXISTS `t_log_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `username` varchar(64) NOT NULL DEFAULT '' COMMENT '管理员帐号名',
  `ip` varchar(32) NOT NULL DEFAULT '' COMMENT '管理员IP',
  `playerAccount` varchar(64) NOT NULL COMMENT '受影响的玩家帐号',
  `mTime` int(11) NOT NULL DEFAULT '0' COMMENT '操作时间',
  `mType` int(11) NOT NULL DEFAULT '0' COMMENT '操作类型',
  `detail` text NOT NULL COMMENT '操作内容',
  `num` int(11) NOT NULL COMMENT '涉及数量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='管理后台的日志表' ;


#各游戏服配置表
CREATE TABLE IF NOT EXISTS `t_game_server` (
  `serverName` varchar(32) NOT NULL COMMENT '服务器编号',
  `serverDB` varchar(32) NOT NULL COMMENT '服务器后台数据库',
  `serverId` int(11) NOT NULL COMMENT '服务器索引号',
  `agentName` varchar(32) NOT NULL COMMENT '代理名称',
  `agentId` int(11) NOT NULL COMMENT '代理编号',
  `gameAdminUrl` varchar(64) NOT NULL COMMENT '游戏管理后台URL基地址',
  `gameAdminAuthKey` varchar(32) NOT NULL COMMENT '游戏管理后台与中央后台验证key',
  `serverOnlineDate` int(11) NOT NULL COMMENT '开服日期',
  `serverCombineDate` int(11) DEFAULT NULL COMMENT '合服日期',
  `syncData` tinyint(4) NOT NULL COMMENT '数据同步开关状态',
  PRIMARY KEY (`serverName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#服务器概要信息缓存表
CREATE TABLE `t_servers_summary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serverName` varchar(32) NOT NULL COMMENT '服务器编号',
  `summaryJson` varchar(2048) NOT NULL COMMENT '服务器概况信息',
  `updateTime` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='服务器概要信息缓存表' ;

#预警设置表
CREATE TABLE `t_alarm` (
	`uid` INT NOT NULL ,
	`agentName` VARCHAR(32) NOT NULL COMMENT '平台名',
	`serverName` VARCHAR(32) NOT NULL COMMENT '服务器名',
	`mType` INT NOT NULL COMMENT '操作类型',
	`itemId` INT NOT NULL COMMENT '物品类型',
	`amount` INT NOT NULL COMMENT '数量',
	`interval` INT NOT NULL COMMENT '间隔',
	`lastUpdate` INT NOT NULL COMMENT '上次检查时间',
	`mode` tinyint(4) NOT NULL COMMENT '模式',
	`switch` TINYINT NOT NULL COMMENT '开关',
	PRIMARY KEY ( `uid` )
) ENGINE = MYISAM  DEFAULT CHARSET=utf8 COMMENT='预警设置表' ;

