<?php

/*
 * 逻辑值，所需宏 
 * 
 */
 
//金钱类型enum
define( TYPE_MONEY_GOLD, 1);
define( TYPE_MONEY_SILVER, 2);

//金钱绑定enum
define( TYPE_BIND, 1 );
define( TYPE_UNBIND, 2 );