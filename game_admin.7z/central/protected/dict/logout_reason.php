<?php
	$dictLogoutReason = array(
		0=>'正常下线',
	);