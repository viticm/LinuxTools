<?php

/*
 * grep '^BATTLE' /home/shuiyuandan/dev/server/game_script/data/define_battle.lua  | grep -v BATTLE_EXCEPTION | grep -v BATTLE_SEG | grep -v BATTLE_PER_CDTIME | grep -v BATTLE_VERSION | awk '{print "define(\"" $1"\","$3");" }' 
 */

define("BATTLE_ATHLETIC",1);
define("BATTLE_REALM",2);
define("BATTLE_STAGE",3);
define("BATTLE_SLAVE",4);
define("BATTLE_TEAM",5);
define("BATTLE_MAGIC",6);
define("BATTLE_PK",7);
define("BATTLE_PVP",8);
define("BATTLE_NORMAL",9);
define("BATTLE_WAR",10);
define("BATTLE_TOWER",11);
define("BATTLE_BOSSWAR",12);
define("BATTLE_FATE",13);
define("BATTLE_MELEE",14);
define("BATTLE_MONSTER_ATTACK",15);
define("BATTLE_HERO_PARTY",16);
define("BATTLE_TEAM_STAGE",17);
define("BATTLE_GUILD_BOSS",18);
define("BATTLE_BARRIER",19);
define("BATTLE_GUILD_WAR",20);

