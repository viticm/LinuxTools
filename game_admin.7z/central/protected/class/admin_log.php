<?php
/**
 * @author linruirong@4399.com
 * @Created  Wed Nov 30 12:58:24 GMT 2011
 * @desc 用来处理管理员操作日志
 */
class AdminLog {

	const LOG_TYPE_LOGIN = 1;

	public static $arrLogType =array(
		self::LOG_TYPE_LOGIN => '登录',
	);

	public function writeLog($mType, $detail='', $playerAccount='', $num=0 )
	{
		$playerAccount = SS($playerAccount);
		$userInfo = getSession('user');
		$username = $userInfo['username'];
		$uid = intval($userInfo['uid']);
		$ip = getIP();
		$mTime  = time();
		$sql = " insert into t_log_admin (`uid`, `username`, `ip`, `playerAccount`, `mTime`, `mType`, `detail`, `num`) values 
		         ( '{$uid}', '{$username}', '{$ip}', '{$playerAccount}', '{$mTime}', '{$mType}', '{$detail}', '{$num}')  ";
		dbQuery($sql);
	}
}