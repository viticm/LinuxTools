<?php
/**
 * @author linruirong@4399.com
 * @Created  Thu Dec 01 10:39:41 GMT 2011
 * @desc 用于服务器管理及权限验证
 */

class AgentServer {
	
	const ROOT_AGENT_ID = 9999; //虚拟的代理编号  所有代理
	const ROOT_SERVER_ID = 9999; //虚拟的服务器编号  所有服
	
	public function getAllAgent($withAll=true )
	{
		$sql = " select `agentId`, `agentName` from t_game_server group by `agentId`, `agentName` ";
		$rsServer = fetchRowSet($sql);
		$arrServer = array();
		if ($withAll) {
			$arrServer[self::ROOT_AGENT_ID] = '所有代理';
		}
		foreach ($rsServer as $row) {
			$arrServer[$row['agentId']] = $row['agentName'];
		}
		return $arrServer;
	}
	
	public function getServerByAgent($agentId, $withAll=true)
	{
		if ($agentId != self::ROOT_AGENT_ID ) {
			$where = " where `agentId`= {$agentId} ";
		}
		$sql = " select * from t_game_server {$where}  order by agentId, serverId ";
		$rsServer = fetchRowSet($sql);
		
		if ($withAll) {
			$arrServer[self::ROOT_SERVER_ID] = '所有服务器';
		}
		foreach ($rsServer as $row) {
			if ($agentId == self::ROOT_AGENT_ID) {
				$arrServer[$row['serverName']] = $row['serverName'];
			}else {
				$arrServer[$row['serverName']] = $row['serverName'];
			}
		}
		return $arrServer;
	}
	
	function getServerInfoByServerName($serverName)
	{
		$sql = " select * from t_game_server where `serverName`='{$serverName}' ";
		return fetchRowOne($sql);
	}
	
	function getServerInfo($agentId, $serverId)
	{
		$sql = " select * from t_game_server where `agentId`='{$agentId}' and `serverId`='{$serverId}' order by agentId, serverId ";
		return fetchRowOne($sql);
	}
	
	function getLogSyncServer()
	{
		$sql = " select * from t_game_server  where `syncData`=1 ";
		return fetchRowSet($sql);
	}
}