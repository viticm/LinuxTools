<?php
/**
 * @author linruirong@4399.com
 * @copyright www.4399.com
 */
include_once(SYSDIR_ADMIN_CLASS.'/socket_client.php');

class ServerApi {   

    ////////////*发送GM指令*////////////////////////
    function sendGmCmd( $ip, $port, $gmStr )
    {
        $gmStr = trim(stripslashes( $gmStr ));
        
        if( empty( $gmStr ) ){
            $msg = "操作失败， GM指令不能为空";
            $retAry = array( 'msg' => $msg, 'ret' => 0 );
            return $retAry;
        }
        
        $socketData = array(
            'cmd' => $gmStr,
        );
        
        $socket = new SocketClient();
        $socket->setIpPort( $ip, $port );
        $ret = $socket->rpc(0xA004,$socketData);
        
        $bSucc = 1;
        if (1 == $ret['result']) {
            $msg = '操作成功！描述：'.$ret['data'];
            $bSucc = 1;
        }else {
            $msg = '操作失败！原因：'.$ret['errorMsg'];
            $bSucc = 0;
        }
        
        $retAry = array( 'msg'=>$msg, 'ret'=>$bSucc );
        return $retAry;
    }
}

