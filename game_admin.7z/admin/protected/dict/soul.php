<?php

// index, id, level, exp

function parseSoulStr( $str ){
    global $dictSoul;
    $ary = split(",", $str );
    $id = intval( $ary[1] );
    $itemData = $dictSoul[$id];
    $item['level'] = $ary[2];
    $item['exp'] = $ary[3];
    $item['Name'] = $itemData['Name'];

    return $item;
}



/*
 * 导库的脚本
 * awk '{if($0~/\[/){print $0}}' game_script/data/prop_soul.lua | awk '{print 0+$8" => array(\"id\"=>"$8 " \"Name\"=>"$11"),"}'
 */
$dictSoul=array(
    1 => array("id"=>1, "Name"=>"云·中府",),
    2 => array("id"=>2, "Name"=>"云·侠白",),
    3 => array("id"=>3, "Name"=>"云·尺泽",),
    4 => array("id"=>4, "Name"=>"云·太渊",),
    5 => array("id"=>5, "Name"=>"云·鱼际",),
    6 => array("id"=>6, "Name"=>"云·曲泽",),
    7 => array("id"=>7, "Name"=>"云·中冲",),
    8 => array("id"=>8, "Name"=>"云·神门",),
    9 => array("id"=>9, "Name"=>"星·阳谷",),
    10 => array("id"=>10, "Name"=>"星·秉风",),
    11 => array("id"=>11, "Name"=>"星·阳溪",),
    12 => array("id"=>12, "Name"=>"星·迎香",),
    13 => array("id"=>13, "Name"=>"星·商阳",),
    14 => array("id"=>14, "Name"=>"星·曲池",),
    15 => array("id"=>15, "Name"=>"星·关冲",),
    16 => array("id"=>16, "Name"=>"星·中渚",),
    17 => array("id"=>17, "Name"=>"月·云门",),
    18 => array("id"=>18, "Name"=>"月·天府",),
    19 => array("id"=>19, "Name"=>"月·天池",),
    20 => array("id"=>20, "Name"=>"月·天泉",),
    21 => array("id"=>21, "Name"=>"月·天宗",),
    22 => array("id"=>22, "Name"=>"月·天容",),
    23 => array("id"=>23, "Name"=>"月·天鼎",),
    24 => array("id"=>24, "Name"=>"月·天井",),
    25 => array("id"=>25, "Name"=>"日·少商",),
    26 => array("id"=>26, "Name"=>"日·少海",),
    27 => array("id"=>27, "Name"=>"日·少府",),
    28 => array("id"=>28, "Name"=>"日·少冲",),
    29 => array("id"=>29, "Name"=>"日·少泽",),
    30 => array("id"=>30, "Name"=>"日·少阳",),
    31 => array("id"=>31, "Name"=>"日·少阴",),
    32 => array("id"=>32, "Name"=>"日·少空",),
    33 => array("id"=>33, "Name"=>"一阶精魂",),
    34 => array("id"=>34, "Name"=>"二阶精魂",),
    35 => array("id"=>35, "Name"=>"三阶精魂",),
    36 => array("id"=>36, "Name"=>"四阶精魂",),
    37 => array("id"=>37, "Name"=>"五阶精魂",),
);
