<?php
$dictSex = array(
	0=>'女',
	1=>'男',
);
$dictColor = array(
	1=>'灰色',
	2=>'绿色',
	3=>'蓝色',
	4=>'紫色',
	5=>'橙色',
	6=>'金色',
);
$dictColorValue = array(
	1=>'gray',
	2=>'green',
	3=>'blue',
	4=>'purple',
	5=>'#ff9000',
	6=>'#ffff00',
);
