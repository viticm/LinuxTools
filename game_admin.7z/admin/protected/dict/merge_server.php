<?php
//默认不合并的后台数据表
$Arr_AdminDefaultNotMergeTable = array(
    't_log_admin',
    't_log_online',
    't_stat_gold',
    't_stat_return',
    't_stat_silver'
);
 //默认不合并的游戏数据表
$Arr_GameDefaultNotMergeTable = array(
    'GLOBAL_TBL',
	'RANK_PLAYER_TBL',
	'MAIL_TBL',
	'PET_TBL',
	'DREAM_RANK_TBL'
);

// 表中不能被合并的字段数据
$Arr_AdminDefaultNotMergeTableField = array();
$Arr_GameDefaultNotMergeTableField  = array(
    'PLAYER_TBL' => array(
        'tile_index',
    ),
	'PAY_ORDER_TBL' => array(
	    'id',
	),
	'ATHLETIC_TBL' => array(
        'rank',
	),
	'SLAVE_TBL' => array(
	    'master_id',
		'master_name',
		'free_time',
		'state',
		'catch_count',
		'rescue_count',
		'flatter',
		'reset_time',
		'catch_list',
		'pain_op_list',
		'pacify_op_list',
		'catch_op_list'
	),
	'DREAM_RANK_TBL' => array(
	    'dream_rank'
	),
	'LOGINOP_TBL' => array(
	    'id'
	)
);

// 特殊表的主键( 指唯一值的键名 )
$Arr_AdminRollbackSpecailKey = array() ;
$Arr_GameRollbackSpecailKey  = array(
    'LOG_TBL' => 'op_type',
	'GUILD_TBL' => 'guild_id',
	'STAGE_TBL' => 'player_id'
) ;

// 默认需清空的游戏数据表
$Arr_GameDefaultTruncateTable = array(
    'BANK_TBL', 'BAN_TBL', 'BLACKNPC_TBL', 'CDKEY_TBL',
	'GM_TBL', 'ACHIEVE_TBL', 'GUILD_APPLY_TBL', 'GUILD_INVITE_TBL',
	'GUILD_WAR_TBL', 'LOG_TBL', 'LOOPAN_TBL', 'LUCKY_DIAL_TBL',
	'MAIL_TBL', 'TRIAL_TBL','OPERATE_TBL'
) ;

// 需清理的角色数据表，注意默认清空的表不要放在这里，虽然也是正确的
$Arr_ClearRoleDataTable = array(
    'ATHLETIC_TBL', 'BAG_TBL', 'COUNT_TBL', 'DREAMLAND_TBL', 'DREAM_RANK_TBL',
	'DREAM_RANK_TBL', 'FRIEND_TBL', 'GARDEN_TBL', 'GROWPLAN_TBL', 'INLAY_TBL',
	'ITEM_TBL', 'LIVENESS_TBL', 'LOGINOP_TBL', 'LOGIN_TBL', 'MAGIC_TBL',
	'PARTNER_TBL', 'PLAYER_ETC_TBL', 'QUEST_TBL', 'RACING_TBL', 'DAYQUEST_TBL',
	'SKILL_TBL', 'SLAVE_TBL', 'SOUL_TBL', 'STAGE_TBL', 'TRIAL_TBL'
) ;

// 特殊的角色ID，默认为id，对应需要清理的表
$Arr_ClearRoleDataTableSpecialKey = array(
    'PARTNER_TBL' => 'player_id',
	'STAGE_TBL' => 'player_id',
	'LOGINOP_TBL' => 'dst_id'
) ;

// 清理角色数据完成后额外自动执行的sql
$Arr_ClearCompletedDoSql = array(
    'DELETE FROM `GUILD_TBL` WHERE `chief_id` NOT IN ( SELECT `id` FROM `PLAYER_TBL` )', // 清理仙盟数据
) ;
