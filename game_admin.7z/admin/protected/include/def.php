<?php

/*
 * 逻辑值，所需宏 
 * 
 */
 
//金钱类型enum
define( TYPE_MONEY_GOLD, 1);
define( TYPE_MONEY_SILVER, 2);

//金钱绑定enum
define( TYPE_BIND, 1 );
define( TYPE_UNBIND, 2 );

//cdkey人群分类enum
define( TYPE_CDKEY_NORMAL, 1 );
define( TYPE_CDKEY_VIP, 2 );

//拍卖场操作定义
define( AUCTION_EVENT_OP_ALL,		0 );
define( AUCTION_EVENT_OP_ADD,		1 );
define( AUCTION_EVENT_OP_CANCEL,	2 );
define( AUCTION_EVENT_OP_SOLD,		3 );
define( AUCTION_EVENT_OP_BUY,		4 );


$AUCTION_OP_DIC = array( 
						 AUCTION_EVENT_OP_ALL=>"【所有】",
						 AUCTION_EVENT_OP_ADD=>"上架",
						 AUCTION_EVENT_OP_CANCEL=>"下架",
						 AUCTION_EVENT_OP_SOLD=>"卖出",
						 AUCTION_EVENT_OP_BUY=>"买入" );