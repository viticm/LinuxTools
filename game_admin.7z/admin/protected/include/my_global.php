<?php
/**
 *
 * @desc 重写自动载入类的方法，只要类的规则正确，放置的路径也正确，则在新建对象时自动载入类
 * @desc 类命名规则：所有类都放置在protected/class下，而且类的规则是目录_+子目录+……+类名（目录_+子目录+……这里就是类文件在class的相对路径）
 * @desc 类文件命名规则：class.目录+子目录+……+类名.php（目录同上）--注意这里的文件名必须全为小写，如果不清楚请发邮件<duchuanpd@gmail.com>
 * @param string $OBJ_Name
 * @return void
 */
function __autoload( $OBJ_Name )
{
	if ( class_exists($OBJ_Name) )
	{
		return false;
	}
	$Arr_ClassName = array();
	$iArrTotalCount = 0;
	$cClassPath = '';
	$cClassFile = '';
	$cClassName = strtolower($OBJ_Name);
	$Arr_ClassName = explode( '_', $cClassName );
	$iArrTotalCount = count( $Arr_ClassName );
	for ( $i =0 ; $i < $iArrTotalCount; $i++ )
	{
		if ( $i < $iArrTotalCount - 1 )
		{
			$cClassPath .= $Arr_ClassName[ $i ].DIRECTORY_SEPARATOR;
		}
	}
	$cClassFile = 'class.'.str_replace( '_', '', $cClassName).'.php';
	require_once( SYSDIR_ADMIN_CLASS.'/'.$cClassPath. $cClassFile);
}

define( 'SYSTEM_TYPE', 'LINUX' ) ; // 系统标识：LINUX,WINDOWS 现在的后台只支持LINUX模式，后期可以自由扩展