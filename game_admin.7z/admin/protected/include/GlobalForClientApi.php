<?php
/**
 * @uses include this file will not check login status
 * @author viticm<duchuanpd@gamail.com>
 * @date 2013-6-24
 */
header('Content-Type: text/html; charset=UTF-8');
date_default_timezone_set(TIME_ZONE);//时间设置
include_once SYSDIR_ADMIN_INCLUDE."/db_defines.php";
include_once SYSDIR_ADMIN_CLASS."/mysql.php";
include_once SYSDIR_ADMIN_INCLUDE."/functions.php";
include_once SYSDIR_ADMIN_INCLUDE."/db_functions.php";
global $db, $dbGame;
define( 'SAVE_CLIENT_AUTH_KEY', 'h8qqu2j8kLGF4LaTCHY1VWVjLAS8zwad' ); //
define( 'CURRENT_SERVER_NAME', trim( GetUrlParam( 'serverNum' ) ) ); //当前操作的服务器
$confFile                  = SYSDIR_ADMIN_CONFIG_SERVERS.DIRECTORY_SEPARATOR.CURRENT_SERVER_NAME.'.php';
$Arr_Result                = array();
$Arr_Result[ 'ErrorCode' ] = 1;
$Arr_Result[ 'ErrorDesc' ] = '';
if (!file_exists($confFile)) {
	$Arr_Result[ 'ErrorCode' ] = 2;
	$Arr_Result[ 'ErrorDesc' ] = urlencode( "config file not exist : {$confFile} " );
    SprintJsonStrAndExit( $Arr_Result );
}else {
	include_once($confFile);

	$cTicket = md5( SAVE_CLIENT_AUTH_KEY.GetUrlParam( 'timeStamp' ).GetUrlParam('serverNum') );
	if ( $cTicket != GetUrlParam('ticket') )
	{
		$Arr_Result[ 'ErrorCode' ] = 3;
		$Arr_Result[ 'ErrorDesc' ] = urlencode( 'auth key check failed!' );
		SprintJsonStrAndExit( $Arr_Result );
	}

	if(!$db ) {//初始化管理后台数据库连接
		$config['host'] = DB_HOST;
		$config['user'] = DB_USER;
		$config['passwd'] = DB_PASSWD;
		$config['dbname'] = DB_NAME;
		$db =  new Mysql();
		$db->connect($config);
		if (!$db) {
			$Arr_Result[ 'ErrorCode' ] = 4;
			$Arr_Result[ 'ErrorDesc' ] = urlencode( "can not connect to database : ".DB_HOST.':'.DB_NAME );
			SprintJsonStrAndExit( $Arr_Result );
		}
	}
	if(!$dbGame ) {//初始化游戏数据库连接
		$config['host'] = DB_GAME_HOST;
		$config['user'] = DB_GAME_USER;
		$config['passwd'] = DB_GAME_PASSWD;
		$config['dbname'] = DB_GAME_DB_NAME;
		$dbGame =  new Mysql();
		$dbGame->connect($config);
		if (!$dbGame) {
			$Arr_Result[ 'ErrorCode' ] = 5;
			$Arr_Result[ "ErrorDesc" ] = urlencode( "can not connect to database : ".DB_HOST.':'.DB_NAME );
			SprintJsonStrAndExit( $Arr_Result );
		}
	}
}