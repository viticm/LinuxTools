<?php
/**
 * @author linruirong@4399.com
 * @copyright www.4399.com
 * @desc 引用此文件，则不验证用户是否登录。用于那些不需要登录可使用的功能
 */
header('Content-Type: text/html; charset=UTF-8');
session_start(); 
date_default_timezone_set(TIME_ZONE);//时间设置
include_once SYSDIR_ADMIN_INCLUDE."/db_defines.php";
include_once SYSDIR_ADMIN_CLASS."/mysql.php";
include_once SYSDIR_ADMIN_INCLUDE."/functions.php";
include_once SYSDIR_ADMIN_INCLUDE."/db_functions.php";
include_once SYSDIR_ADMIN_LIBRARY."/smarty/Smarty.class.php";

global $smarty, $db, $dbGame, $auth;

//初始化smarty
$smarty = new Smarty();
$smarty->compile_check = SMARTY_COMPILE_CHECK;
$smarty->force_compile = SMARTY_FORCE_COMPILE;
$smarty->template_dir = SYSDIR_ADMIN_SMARTY_TEMPLATE;
$smarty->compile_dir = SYSDIR_ADMIN_SMARTY_TEMPLATE_C;
$smarty->left_delimiter = SMARTY_LEFT_DELIMITER;
$smarty->right_delimiter = SMARTY_RIGHT_DELIMITER;

define('CURRENT_SERVER_NAME', trim($_GET['currentServerName'])); //当前操作的服务器
$sessionLoginServers = getSession('sessionLoginServers'); //已经登录的服务器列表
$sessionLoginServers = empty($sessionLoginServers) ? array() : $sessionLoginServers;
if (CURRENT_SERVER_NAME && in_array(CURRENT_SERVER_NAME, $sessionLoginServers)) {
	$confFile = SYSDIR_ADMIN_CONFIG_SERVERS.DIRECTORY_SEPARATOR.CURRENT_SERVER_NAME.'.php';
	if (file_exists($confFile)) {
		include_once($confFile);
		
		if(!$db ) {//初始化管理后台数据库连接
			$config['host'] = DB_HOST;
			$config['user'] = DB_USER;
			$config['passwd'] = DB_PASSWD;
			$config['dbname'] = DB_NAME;
			$db =  new Mysql();
			$db->connect($config);
			if (!$db) {
				die('无法连接数据库');
			}
		}
		if(!$dbGame ) {//初始化游戏数据库连接
			$config['host'] = DB_GAME_HOST;
			$config['user'] = DB_GAME_USER;
			$config['passwd'] = DB_GAME_PASSWD;
			$config['dbname'] = DB_GAME_DB_NAME;
			$dbGame =  new Mysql();
			$dbGame->connect($config);
			if (!$dbGame) {
				die('无法连接数据库');
			}
		}
	}else {
		die('配置文件丢失！');
	}
}else{
	die('缺少服务器名称currentServerName参数或未通过验证！请通过正常方式切换，勿手动修改地址！');
}

if (!$auth) {
	require_once(SYSDIR_ADMIN_CLASS.'/user_auth.php');
	$auth = new UserAuth();
}
if ( UserAuth::AUTH_RESULT_OK === $auth->auth() ) {
	//如果验证通过，则不做处理，放行...
}elseif ( UserAuth::AUTH_RESULT_NOT_LOGIN === $auth->auth() ){
	die('<script language="javascript">window.top.location.href="'.GATEWAY_SYSTEM_URL.'";</script>');
}elseif ( UserAuth::AUTH_RESULT_NO_PERMITION === $auth->auth() ) {
	die('没权限');
}else {
	die('没权限');
}
	