<?php
/**
 * @author linruirong@4399.com
 * @Created  Wed Nov 30 12:58:24 GMT 2011
 * @desc 用来处理管理员操作日志
 */
class AdminLog {

	const LOG_TYPE_LOGIN                  = 1;
	const LOG_TYPE_SET_GAME_STATUS        = 2;
	const LOG_TYPE_LOGIN_PLAYER_ACCOUNT   = 3;
	const LOG_TYPE_SET_CLIENT_VARS        = 4;
	const LOG_TYPE_BAN_ACCOUNT            = 5;
	const LOG_TYPE_UNBAN_ACCOUNT          = 6;
	const LOG_TYPE_BAN_IP                 = 7;
	const LOG_TYPE_UNBAN_IP               = 8;
	const LOG_TYPE_BAN_CHAT               = 9;
	const LOG_TYPE_UNBAN_CHAT             = 10;
	const LOG_TYPE_SET_PLAYER_OFFLINE     = 11;
	const LOG_TYPE_SEND_GOLD              = 12;
	const LOG_TYPE_SEND_SILVER            = 13;
	const LOG_TYPE_SEND_MAIL              = 14;
	const LOG_TYPE_SEND_ANNOUNCE          = 15;
	
	const LOG_TYPE_REWARD_VIP             = 16;  //赠送VIP
	const LOG_TYPE_LOOP_AN_ADD            = 17;  //添加循环公告
	const LOG_TYPE_LOOP_AN_DEL            = 18;  //删除循环公告
	const LOG_TYPE_SEND_CDKEY             = 19;  //发送CDKEY
	const LOG_TYPE_MERGE_SERVER           = 20;  //合区
	
	public static $arrLogType =array(
		self::LOG_TYPE_LOGIN                     => '登录',
		self::LOG_TYPE_SET_GAME_STATUS           => '游戏入口开关',
		self::LOG_TYPE_LOGIN_PLAYER_ACCOUNT      => '登录玩家帐号',
		self::LOG_TYPE_SET_CLIENT_VARS           => '设置应用服务器变量',
		self::LOG_TYPE_BAN_ACCOUNT               => '封禁帐号',
		self::LOG_TYPE_UNBAN_ACCOUNT             => '解禁帐号',
		self::LOG_TYPE_BAN_IP                    => '封禁IP',
		self::LOG_TYPE_UNBAN_IP                  => '解禁IP',
		self::LOG_TYPE_BAN_CHAT                  => '帐号禁言',
		self::LOG_TYPE_UNBAN_CHAT                => '帐号解禁言',
		self::LOG_TYPE_SET_PLAYER_OFFLINE        => '踢玩家下线',
		self::LOG_TYPE_SEND_GOLD                 => '给玩家送元宝',
		self::LOG_TYPE_SEND_SILVER               => '给玩家送铜钱',
		self::LOG_TYPE_SEND_MAIL                 => '发批量邮件',
		self::LOG_TYPE_SEND_ANNOUNCE             => '发系统公告',
		self::LOG_TYPE_REWARD_VIP             	 => '赠送VIP',
		self::LOG_TYPE_LOOP_AN_ADD               => '添加循环公告',
		self::LOG_TYPE_LOOP_AN_DEL            	 => '删除循环公告',
		self::LOG_TYPE_SEND_CDKEY                => '发送CDKEY',
		self::LOG_TYPE_MERGE_SERVER		         => '合区',
	);

	public function writeLog($mType, $detail='', $playerAccount='', $num=0 )
	{
		$playerAccount = SS($playerAccount);
		$userInfo = getSession('user');
		$username = $userInfo['username'];
		$uid = intval($userInfo['uid']);
		$ip = getIP();
		$mTime  = time();
		$sql = " insert into t_log_admin (`uid`, `username`, `ip`, `playerAccount`, `mTime`, `mType`, `detail`, `num`) values 
		         ( '{$uid}', '{$username}', '{$ip}', '{$playerAccount}', '{$mTime}', '{$mType}', '{$detail}', '{$num}')  ";
		dbQuery($sql);
	}
}
