<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Oct 28 12:22:12 GMT 2011
 * @desc 用于验证用户权限
 */
include_once(SYSDIR_ADMIN_CONFIG.'/allow.php');
include_once(SYSDIR_ADMIN_CLASS.'/menu.php');

class UserAuth
{
	const AUTH_RESULT_OK = 1;
	const AUTH_RESULT_NOT_LOGIN = 2;
	const AUTH_RESULT_NO_PERMITION = 3;
	
	public function getUserName()
	{
		$user = getSession('user');
		return $user['username'];
	}
	
	
	/**
	 * 验证用户是否有权限
	 *
	 * @return bool
	 */
	public function auth()
	{
		$url = trim(str_replace(SYSDIR_ADMIN_PUBLIC, '', realpath($_SERVER['SCRIPT_FILENAME']) ),'/');
		$userInfo = getSession('user');
		
		global $ALLOW_ACCESS_PAGE;
		global $LOGIN_ALLOW_ACCESS_PAGE;
		if (in_array($url,$ALLOW_ACCESS_PAGE)) { //如果不需要验证即可访问的
			return self::AUTH_RESULT_OK;
		}
		if ('' != $userInfo['username'] && in_array($url, $LOGIN_ALLOW_ACCESS_PAGE) ) { //对于所有已经登录用户都可以访问的
			return self::AUTH_RESULT_OK;
		}
		$exist = false;
		if ( is_array($userInfo['rules']) && !empty($userInfo)) {
			foreach ($userInfo['rules'] as $rule) {
				if ( $url == $rule['url']) {
					global $navPosition;
					$navPosition=CURRENT_SERVER_NAME.' &gt;&gt; '.$rule['class'].' &gt;&gt; '.$rule['name'];
					$exist = true;
					break;
				}
			}
		}else {
			return self::AUTH_RESULT_NOT_LOGIN ;
		}
		if ('' != $userInfo['username'] && $exist ) { //如果用户已经登录，且其权限列表里面有本系统此url的访问权
			return self::AUTH_RESULT_OK;
		}
		return self::AUTH_RESULT_NO_PERMITION ;
	}
}