<?php
/*
 *  MergeServer is just use for pindian .
 *  @link        http://www.gzpindian.com/
 *  @package     mergeserver
 */

/**
 * Description of MergeServer
 * Mysql 数据库相关类
 * @author viticm<duchuanpd@gmail.com>
 * @version 1.0
 */
class MergeServer extends MysqlNew
{
    private $Arr_DbConfig = array();
     public $bConnect = true;

     /**
      * @desc 析构函数
      * @param array $Arr_DbConfig
      */
    public function __construct( $Arr_DbConfig )
    {
        $this->Arr_DbConfig = $Arr_DbConfig;
        $this->bConnect = $this->connect( $this->Arr_DbConfig );
    }

    /**
     * @desc 获得数据库所有表
     * @param void
     * @return mixed
     */
    public function getAllTables()
    {
        $cSqlStr = '';
        $cSqlStr .= 'SHOW TABLES';
        $Arr_Tables = array();
        $Result = $this->fetchAll( $cSqlStr );
        if( is_array( $Result ) )
        {
            $cKey = 'Tables_in_'.$this->Arr_DbConfig[ 'dbname' ];
            foreach ( $Result as $key => $val )
            {
                array_push( $Arr_Tables, $val[ $cKey ] );
            }
        }
        else
        {
            $Arr_Tables = $Result;
        }
        return $Arr_Tables;
    }

    /**
     * @desc 向某个表插入数据
     * @param string $cTableName
     * @param array $Arr_Insert
     * @return mixed
     */
    public function addItemsToTable( $cTableName, $Arr_Insert )
    {
        if( count( $Arr_Insert ) < 1 ) return ;
        $cSqlStr = '';
        $cSqlStr .= makeInsertSql( $cTableName, $Arr_Insert ) ;
        return $this->query( $cSqlStr ) ;
    }

    /**
     * @desc 使用多维数组向某个表中插入数据，如果回滚目录不为空则认为需要数据库回滚功能
     * @param string $cTableName
     * @param array $Arr_MultiArray
     * @param string $cRollBackDir
     * @param string $szRollbackInfoJson
     * @param string $cTableKey
     * @param bool $bFirstRecords
     * @return bool
     */
    public function addItemsToTableByMultiArray( $cTableName, $Arr_MultiArray, $cRollBackDir = '',
        $szRollbackInfoJson = '', $cTableKey = '', $bFirstRecords = false )
    {
        $bReturn = true;
        foreach ( $Arr_MultiArray as $key => $Arr_Insert )
        {
        	$bReturn = false === $this->addItemsToTable( $cTableName, $Arr_Insert ) ? false : $bReturn ;
            if ( '' != $cRollBackDir )
            {
            	$bFirstRecords = 0 == $key ? $bFirstRecords : false ;
                if ( false === $this->saveRollbackData( $cRollBackDir, $szRollbackInfoJson, $cTableName, $cTableKey, $Arr_Insert, $bFirstRecords ) ) return false ;
            }
        }
        return $bReturn;
    }

    /**
     *
     * @desc 获得某个表中的所有数据（根据起始位置）
     * @param string $cTableName
     * @return array
     */
    public function getItemOfTable( $cTableName, $iOffsetStart = 0, $iRecords = 10 )
    {
        $cSqlStr = '';
        $cSqlStr .= 'SELECT * FROM `'.$cTableName.'`';
        $cSqlStr .= ' LIMIT '.$iOffsetStart.','.$iRecords;
        return $this->fetchAll( $cSqlStr );
    }

    /**
     *
     * @desc 获得某个表中的所有数据
     * @param string $cTableName
     * @return array
     */
    public function getAllItemOfTable( $cTableName )
    {
        $cSqlStr = '';
        $cSqlStr .= 'SELECT * FROM `'.$cTableName.'`';
        return $this->fetchAll( $cSqlStr );
    }

    /**
     * @desc 获得某个表的记录数量
     * @param string $cTableName
     * @param mixed
     */
    public function getRecordsOfTable( $cTableName )
    {
        $cSqlStr = '';
        $cSqlStr .= 'SELECT COUNT( * ) AS `Records` FROM `'.$cTableName.'`';
        $Return = $this->fetchOne( $cSqlStr );
        if( is_array( $Return ) )
        {
            return empty( $Return[ 'Records' ] ) ? 0 : intval( $Return[ 'Records' ] );
        }
        else
        {
            return $Return;
        }
    }

    /**
     * 写入回滚数据文件
     * @param string $cRollBackDir
     * @param string $szRollbackInfoJson
     * @param string $cTableName
     * @param string $cTableKey
     * @param array  $Arr_InsertData
     * @param bool   $bFirstRecords
     * @return boolean
     */
    private function saveRollbackData( $cRollBackDir, $szRollbackInfoJson, $cTableName, $cTableKey, $Arr_InsertData, $bFirstRecords )
    {
        if( !file_exists( $cRollBackDir ) )
        {
            $bMkdir = @mkdir( $cRollBackDir ) ;
            if( !$bMkdir ) return false ;
        }
        $Arr_RollbackInfo     = array() ;
        $Arr_RollbackInfo     = json_decode( $szRollbackInfoJson, true ) ;
        $cRollbackFile        = $Arr_RollbackInfo[ 'agentName' ]. 's' .$Arr_RollbackInfo[ 'srcServerId' ]. '.txt' ;
        $szRollbackFilePath   = $cRollBackDir.DIRECTORY_SEPARATOR.$cRollbackFile ;
        if ( true === $bFirstRecords )
        {
            if( 'LINUX' == SYSTEM_TYPE )
                $bClearRollbackData = $this->clearLinuxRollbackData( $cTableName, $szRollbackFilePath ) ;
            if( false === $bClearRollbackData ) return false ;
        }

        if( !file_exists( $szRollbackFilePath ) || 0 == $this->getLinuxFileLine( $szRollbackFilePath ) )
        {
            file_put_contents( $szRollbackFilePath, $szRollbackInfoJson. "\n" ) ;
        }
        if ( !array_key_exists( $cTableKey, $Arr_InsertData ) || empty( $Arr_InsertData[ $cTableKey ] ) ) // special
        	$Arr_InsertData[ $cTableKey ] = $this->getLastInsertId() ;
        $cRollbackSqlStr = 'DELETE FROM `' .$cTableName. '` WHERE `' .$cTableKey. '` = ' .$Arr_InsertData[ $cTableKey ]. ' ;' ;
        if( !file_put_contents( $szRollbackFilePath, $cRollbackSqlStr."\n", FILE_APPEND ) ) return false ;
        return true ;
    }

    /**
     * 清理角色数据，根据角色等级，是否充值，最大离线天数来删除
     * @param string $szTableName
     * @param string $szRoleId
     * @param number $iMinRoleLevel
     * @param bool   $bNotClearVip
     * @param number $iMaxNotLoginDay
     */
    public function clearRoleData( $szTableName, $szRoleId = 'id',  $iMinRoleLevel = 20, $bNotClearVip = true, $iMaxNotLoginDay = 30 )
    {
        $szNeedDelRoleSqlStr = '' ;
        $szNeedDelRoleSqlStr .= 'SELECT `id` FROM `PLAYER_TBL` WHERE 1 = 1' ;
        $szClearPlayerSqlStr = '' ;
        $szClearPlayerSqlStr .= 'DELETE FROM `PLAYER_TBL` WHERE 1 = 1' ;
        $iThirtyDayTimeStamp = time() - 30 * 24 * 60 * 60 ;
        $szWhere = '' ;
        $szWhere .= ' AND `level` <= ' .$iMinRoleLevel ;
        if ( true === $bNotClearVip )
        	$szWhere .= ' AND `vip` = 0' ;
        $szWhere .= ' AND `last_logout_time` <= '. $iThirtyDayTimeStamp ;

        $szNeedDelRoleSqlStr .= $szWhere ;
        $szClearPlayerSqlStr .= $szWhere ;
        $szClearRoleDataStr = '' ;
        $szWhere = '' ;
        $szClearRoleDataStr .= 'DELETE FROM `' .$szTableName. '` WHERE 1 = 1 ' ;
        $szWhere .= ' AND `' .$szRoleId. '` IN ( ' .$szNeedDelRoleSqlStr. ' )' ;
        $szClearRoleDataStr .= $szWhere ;
        if ( 'PLAYER_TBL' == $szTableName ) $szClearRoleDataStr = $szClearPlayerSqlStr ;
        return $this->query( $szClearRoleDataStr ) ;
    }

    /**
     * LINUX系统中清除某个表的回滚记录
     * @param string $cTableName
     * @param string $cRollbackFile
     */
    private function clearLinuxRollbackData( $cTableName, $cRollbackFile )
    {
        $cCmdStr = '' ;
        $cCmdStr = 'sed -i \'/.*`' .$cTableName. '`.*/d\' '. $cRollbackFile ;
        return '' == exec( $cCmdStr ) ? true : false ;
    }

    /**
     * del the file end lines, default last one
     * @param string $cFilePath
     * @param number $iLines
     */
    private function delLinuxFileEndLines( $cFilePath, $iLines = 1 )
    {
        $cCmdStr = '' ;
        $cCmdStr = 'sed -i $(( `sed -n "$=" ' .$cFilePath. '` - ' .$iLines. ' + 1 )),`sed -n "$=" '.$cFilePath.'`d '. $cFilePath ;
        return '' == exec( $cCmdStr ) ? true : false ;
    }

    /**
     * 从文件中读取倒数几行内容，最后一个参数是否倒序读取，默认为否（ 倒序效率较低 ）
     * @param string $cFilePath
     * @param number $iLines
     * @param bool   $bDesc
     * @return array
     */
    private function getLinuxFileEndLines( $cFilePath, $iLines = 1, $bDesc = false )
    {
        $cCmdStr = '' ;
        $cCmdStr = true === $bDesc ? 'tac ' .$cFilePath. ' | head -n '. $iLines : 'tail -' .$iLines.' '.$cFilePath ;
        $Arr_FileLine = array() ;
        exec( $cCmdStr, $Arr_FileLine ) ;
        return $Arr_FileLine ;
    }

    /**
     * 回滚数据库数据
     * @param string $cRollbackFile
     * @param number $iOnceRecords
     * @return boolean
     */
    public function rollbackDbData( $cRollbackFile, $iOnceRecords )
    {
    	$Arr_RollbackSql = $this->getLinuxFileEndLines( $cRollbackFile, $iOnceRecords ) ;
    	$Return = true ;
    	if ( 0 < $Arr_RollbackSql )
    	{
    	    foreach ( $Arr_RollbackSql as $key => $val )
    	    {
    	        $Return = $this->query( $val ) ;
    	        if ( false === $Return ) return $Return ;
    	    }
    	}
    	$this->delLinuxFileEndLines( $cRollbackFile, $iOnceRecords ) ;
        return $Return ;
    }

    /**
     * 获取文件的行数，不会判断文件是否存在
     * @param $szFilePath
     * @return mixed
     */
    private function getLinuxFileLine( $szFilePath )
    {
        $szCmdStr = '' ;
        $szCmdStr = 'wc -l ' .$szFilePath. ' | awk \'{print $1}\'' ;
        return exec( $szCmdStr ) ;
    }

    /**
     * 获得文件指定行的内容
     * @param int $iLine
     * @return int
     */
    private function getLinuxFileLineContent( $szFilePath, $iLine )
    {
        $szCmdStr = '' ;
        $szCmdStr .= 'sed -n "' .$iLine. 'p" ' .$szFilePath ;
        return exec( $szCmdStr ) ;
    }

    public function __destruct()
    {

    }
}