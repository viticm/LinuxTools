<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Oct 25 06:59:19 GMT 2011
 * @desc 系统权限项管理
 */
class Menu {
	
	/**
	 * 取得显示在左边的菜单
	 *
	 * @return array
	 */
	function getMyMenu()
	{
		$menu = array();
		$user = getSession('user');
		$rules = $user['rules'];
		@chdir(SYSDIR_ADMIN_PUBLIC);
		@exec('find . -name "*.php"',$pathList);
		
		if ( is_array($rules)) {
			foreach ($rules as $rule) {
				foreach ($pathList as $k => $path) {
					$path = str_replace('./', '', $path);
					if ($rule['url'] == $path) {  //如果这个路径有在玩家菜单列表中，则显示到菜单中
						$menu[$rule['class']][] = array(
							'id'=>$rule['id'],
							'class'=>$rule['class'],
							'name'=>$rule['name'],
							'url'=>$rule['url'],
						);
						break;
					}
				}
			}
		}
		
		return $menu;
	}
}