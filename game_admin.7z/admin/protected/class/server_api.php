<?php
/**
 * @author linruirong@4399.com
 * @copyright www.4399.com
 */
include_once(SYSDIR_ADMIN_CLASS.'/socket_client.php');

class ServerApi {
	
	/**
	 * 玩家充值接口
	 *
	 * @param string $PayNum 订单号
	 * @param string $PayToUser 玩家帐号名
	 * @param int $PayMoney 支付金额(元)
	 * @param int $PayGold 充值获得的元宝
	 * @param int $PayTime 充值时间
	 * @return array
	 */
	function pay($PayNum, $PayToUser, $PayMoney, $PayGold, $PayTime, $ticket)
	{
		$data = array(
			'order_id'  => $PayNum,
			'pay_to'=>$PayToUser,
			'pay_rmb'=>floatval($PayMoney),
			'pay_gold'=>intval($PayGold),
			'pay_time'=>intval($PayTime),
			'ticket'=>$ticket,
		);
		$socket = new SocketClient();
		return $socket->rpc(SOCKET_API_ID_PAY,$data);
	}
	
	/**
	 * 获得服务器当前在线人数
	 *
	 * @return int
	 */
	public function getOnlineCount()
	{
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_GET_CURRENT_ONLINE, array());
		if (1==$ret['result']) {
			return intval($ret['data']);
		}else {
			return 0;
		}
	}
	
	/**
	 * 封禁帐号
	 *
	 * @param string $accountName
	 * @param int $endTime
	 * @param string $reason
	 * @return array
	 */
	public function banAccount($accountName, $endTime, $reason)
	{
		$data = array(
			'accountName'=>$accountName,
			'endTime'=>$endTime,
			'reason'=>$reason,
		);
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_BAN_ACCOUNT, &$data);
		return $ret;
	}
	
	/**
	 * 解禁
	 *
	 * @param string $accountName
	 * @return array
	 */
	public function unBanAccount($accountName)
	{
		$data = array(
			'accountName'=>$accountName,
		);
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_UNBAN_ACCOUNT, &$data);
		return $ret;
	}
	
	/**
	 * 获取封禁帐号列表
	 *
	 * @return array
	 */
	public function getBanAccountList()
	{
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_GET_ACCOUNT_BAN_LIST, array());
		return $ret;
	}
	
	/**
	 * 封禁IP
	 *
	 * @param string $ip
	 * @param int $endTime
	 * @param string $reason
	 * @return array
	 */
	public function banIp($ip, $endTime, $reason)
	{
		$data = array(
			'ip'=>$ip,
			'endTime'=>$endTime,
			'reason'=>$reason,
		);
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_BAN_IP, &$data);
		return $ret;
	}
	
	/**
	 * 解封ip
	 *
	 * @param string $ip
	 * @return array
	 */
	public function unBanIp($ip)
	{
		$data = array(
			'ip'=>$ip,
		);
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_UNBAN_IP, &$data);
		return $ret;
	}
	
	/**
	 * 获取IP帐号列表
	 *
	 * @return array
	 */
	public function getBanIpList()
	{
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_GET_IP_BAN_LIST, array());
		return $ret;
	}
	
	/**
	 * 帐号禁言
	 *
	 * @param string $accountName
	 * @param int $endTime
	 * @param string $reason
	 * @return array
	 */
	public function banChat($accountName, $endTime, $reason)
	{
		$data = array(
			'accountName'=>$accountName,
			'endTime'=>$endTime,
			'reason'=>$reason,
		);
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_BAN_CHAT, &$data);
		return $ret;
	}
	
	/**
	 * 解禁言
	 *
	 * @param string $accountName
	 * @return array
	 */
	public function unBanChat($accountName)
	{
		$data = array(
			'accountName'=>$accountName,
		);
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_UNBAN_CHAT, &$data);
		return $ret;
	}
	
	/**
	 * 获取禁言帐号列表
	 *
	 * @return array
	 */
	public function getBanChatList()
	{
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_GET_CHAT_BAN_LIST, array());
		return $ret;
	}
	
	/**
	 * 踢玩家下线
	 * @param int $roleId
	 * @param string $reason
	 */
	public function setPlayerOffLine($roleId, $reason='')
	{
		$data = array(
			'roleId'=>intval($roleId),
			'reason'=>$reason,
		);
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_SET_PLAYER_OFF_LINE, &$data);
		return $ret;
	}
	
	/**
	 * 送元宝
	 * @param int $roleId
	 * @param int $moneyType
	 * @param int $num
	 * @param int $bindType
	 * @param string $reason
	 */
	public function sendMoney($roleId, $moneyType, $num, $bindType, $reason='')
	{
		$bindType = intval($bindType);
		//$bindType = TYPE_BIND==$bindType ? TYPE_BIND : TYPE_UNBIND;  //1绑定 ，2不绑
		$data = array(
			'roleId'=>intval($roleId),
			'moneyType'=>intval($moneyType), //元宝
			'num'=>intval($num),
			'bindType'=>intval($bindType),
			'reason'=>$reason,
		);
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_SEND_MONEY, &$data);
		return $ret;
	}
    
	/**
	 * 发送CDKEY
	 * @param int $iGroupType
	 * @return array
	 */
	public function sendCdkey( $iGroupType )
	{
		$iGroupType = intval( $iGroupType );
		$Arr_Data = array();
		$Arr_Data = array( 'iGroupType' => $iGroupType, );
		$OBJ_Socket = new SocketClient();
		$Arr_Result = $OBJ_Socket->rpc( GPT_GM_SEND_CDKEY_MAIL, $Arr_Data );
		return $Arr_Result; 
	}
	
    /**
	 * 发系统公告
	 * @param int    $interval
	 * @param int    $times
	 * @param string $content
	 */
	public function sendAnnounce( $interval, $times, $content )
	{
		$interval = intval($interval);
        $times    = intval( $times );
		$data = array(
			'interval'=> $interval,
			'times'=>$times, 
			'content'=>$content,
		);
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_SEND_ANNOUNCE, &$data);
		return $ret;
	}

    /**
	 * 发批量邮件
	 * @param int    $pidAryStr
	 * @param int    $silverNum
	 * @param string $itemStr
	 * @param string $title
	 * @param string $content
	 */
	public function sendBatchMail( $pidAryStr, $silverNum, $itemStr, $title, $content, $iSpirit, $iCrystal )
	{
		$silverNum = intval($silverNum);
		$data = array(
			'pidStr'=> $pidAryStr,
			'silverNum'=>$silverNum, 
			'itemStr'=>$itemStr,
			'title'=>$title,
			'content'=>$content,
		    'spiritNum' => $iSpirit,
		    'crystalNum' => $iCrystal,
		);
		$socket = new SocketClient();
		$ret = $socket->rpc(GPT_GM_SEND_MAIL, &$data);
		return $ret;
	}

	/**
	 * 获取循环公告列表
	 *
	 * @return array
	 */
	public function getLoopAnList()
	{
		$socket = new SocketClient();
		$ret = $socket->rpc(GPT_GM_LOOP_AN_LIST, array());
		return $ret;
	}
	
	/**
	 * 新增循环公告列表
	 *
	 * @return array
	 */
	public function addLoopAn( $startTick, $endTick, $interval, $content, $link )
	{
		$socket = new SocketClient();
		$data = array(
			'start_tick'=> $startTick,
			'end_tick'=>$endTick, 
			'interval'=>$interval,
			'content'=>$content,
			'link'=>$link,
		);
		$ret = $socket->rpc(GPT_GM_LOOP_AN_ADD, &$data );
		return $ret;
	}
	
	 /**
	 * 更新循环公告列表
	 *
	 * @return array
	 */
	public function updateLoopAn( $id, $startTick, $endTick, $interval, $content, $link )
	{
		$socket = new SocketClient();
		$data = array(
			'id' => $id,
			'start_tick'=> $startTick,
			'end_tick'=>$endTick, 
			'interval'=>$interval,
			'content'=>$content,
			'link'=>$link,
		);
		$ret = $socket->rpc(GPT_GM_LOOP_AN_UPDATE, &$data );
		return $ret;
	}
	
	/**
	 * 删除循环公告列表
	 *
	 * @return array
	 */
	public function delLoopAn( $id )
	{
		$socket = new SocketClient();
		$data = array(
			'id' => $id,
		);
		$ret = $socket->rpc(GPT_GM_LOOP_AN_DEL, &$data );
		return $ret;
	}
}
