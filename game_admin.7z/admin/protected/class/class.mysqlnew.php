<?php
/*
 *  MergeServer is just use for pindian .
 *  @link        http://www.gzpindian.com/
 *  @package     mergeserver
 */

/**
 * Description of Mysql
 * Mysql 数据库相关类
 * @author viticm<duchuanpd@gmail.com>
 * @version 1.1
 */
class MysqlNew
{
	private static $conn = null;
	private $query_result;
	private $rows;
	private $cHost;
	private $cUser;
	private $cPassword;
	private $cDbName;
	public  $bConnect;
	const LOG_FILE = '../../public/download/mysql.log' ;

	/**
	 *
	 * @desc 连接数据库
	 * @param array $config 数据库连接数组
	 * @param bool $bDebug 是否为调试模式，如果是则抛出错误，否则失败时返回false
	 * @throws Exception
	 * @return void
	 */
	public function connect( $config, $bDebug = false )
	{
		$this->cHost = $config['host'];
		$this->cUser = $config['user'];
		$this->cPassword = $config['password'];
		$this->cDbName = $config['dbname'];
		if (!is_resource( $this->conn )) {
			$link = mysql_connect( $this->cHost, $this->cUser, $this->cPassword );
			if (!$link){
				$this->bConnect = false;
				if( true === $bDebug )
				{
				    throw new Exception("create connect error :" . mysql_error());
				}
			}
			$this->conn = $link;
			if ( $this->cDbName )
			{
			    if (!mysql_select_db( $this->cDbName, $link )) {
				    $this->bConnect = false;
				    if ( true === $bDebug )
				    {
				        throw new Exception("select db error: " . mysql_error());
				    }
			    }
			}
			mysql_query("set names utf8", $link);
			$this->bConnect = true;
		}
	}

	/**
	 * 执行sql语句，并返回Resource
	 * @param string $sql 查询sql字符串
	 * @param bool $bDebug 是否为调试模式，如果是则抛出错误，否则失败时返回false
	 * @throws Exception
	 * @return resource
	 */
	public function query( $sql, $bDebug = false )
	{
		$this->query_result = mysql_query($sql, $this->conn );
		if ( false === $this->query_result )
		{
			file_put_contents( self::LOG_FILE, '[' .date( 'Y-m-d H:i:s' ). '] query error: ' .mysql_error(). "\n", FILE_APPEND ) ;
			if ( true === $bDebug )
			    throw new Exception("exceute error, sql= {$sql} ;" . mysql_error());
		}
		return $this->query_result;
	}

	/**
	 * 执行select语句并返回结果
	 * @param string $sql
	 * @return array 0r bool
	 */
	public function fetchAll($sql)
	{
		$this->query($sql);
		return $this->getAll($this->query_result);
	}
    /**
     *
     * 执行查询，并返回所有结果
     * @param $string $sql
     * @return array or bool
     */
	public function fetchOne($sql)
	{
		$this->query($sql);
		return $this->getOne($this->query_result);
	}

    /**
     *
     * @desc 从结果集中获取一条信息
     * @param obj $result 结果集
     * @param bool $bDebug 是否为调试模式，如果是则抛出错误，否则失败时返回false
     * @throws Exception
     * @return bool or array
     */
	public function getOne( $result, $bDebug = false )
	{
		if ($this->query_result) {
			$result =  mysql_fetch_assoc($this->query_result);
			if (!$result) {
				return array();
			}
			return $result;
		}
		if ( true === $bDebug )
		{
		    throw new Exception('can not excute sql');
		}
		else
		{
			return false;
		}
	}
    /**
     *
     * @desc 从结果集中获得所有信息
     * @param obj $result 结果集
     * @param bool $bDebug 是否为调试模式，如果是则抛出错误，否则失败时返回false
     * @throws Exception
     * @return bool or array
     */
	public function getAll( $result, $bDebug = false )
	{
		if ($this->query_result) {
			$this->rows = array();
			while (($row = mysql_fetch_assoc($this->query_result)) !== false) {
				array_push($this->rows, $row);
			}
			return $this->rows;
		}
		if ( true === $bDebug )
		{
		    throw new Exception('get query_result error ');
		}
		else
		{
			return false;
		}
	}

	/**
	 * truncate table
	 * @param string $szTableName
	 * @return bool
	 */
	public function truncateTable( $szTableName )
	{
	    $szSqlStr = '' ;
	    $szSqlStr .= 'TRUNCATE TABLE `' .$szTableName. '`' ;
	    return $this->query( $szSqlStr ) ;
	}

	/**
	 * auto source sql file ( work in linux, also can work in windows but you will test it )
	 * @param string $cSqlFile
	 * @return bool
	 * @access public
	 */
	public function sourceLinuxSqlFile( $cSqlFile )
	{
		if( ! $this->bConnect ) return false;
		$cCmdStr  = '';
		$cCmdStr .= 'mysql -u' .$this->cUser. ' -h' .$this->cHost. ' -p'.$this->cPassword;
		$cCmdStr .= ' ' .$this->cDbName. ' < ' .$cSqlFile;
		return '' == exec( $cCmdStr ) ? true : false; // null then is success
	}

	/**
	 * dump linux db file ( work in linux, also can work in windows but you will test it )
	 * @param string $cDumpPath
	 * @param string $cDumpFileName
	 * @return bool
	 * @access public
	 */
	public function dumpLinuxDb( $cDumpPath, $cDumpFileName = '' )
	{
		if( false === $this->bConnect ) return false;
		$cDumpFileName = '' == $cDumpFileName ? $this->cDbName.'.sql' : $cDumpFileName;
		$cCmdStr .= 'mysqldump -u' .$this->cUser. ' -h' .$this->cHost. ' -p'.$this->cPassword;
		$cCmdStr .= ' --default-character-set=utf8 --opt --extended-insert=false --single-transaction';
		$cCmdStr .= ' ' .$this->cDbName. ' > ' .$cDumpPath.DIRECTORY_SEPARATOR.$cDumpFileName;
		return '' == exec( $cCmdStr ) ? true : false; // null then is success
	}

	/**
	 * get last instsert id
	 * @param void
	 * @return number
	 */
	public function getLastInsertId()
	{
	    return mysql_insert_id( $this->conn ) ;
	}

	/**
	 * 析构函数
	 */
	public function __destruct()
	{
		if (is_resource($this->query_result)) {
			mysql_free_result($this->query_result);
		}
		mysql_close( $this->conn );
	}
}
