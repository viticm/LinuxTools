<?php
class Mysql
{
	private static $conn = null;
	private $query_result;
	private $rows;

	/**
	 *
	 * 连接数据库
	 * @param array $config
	 * @throws Exception
	 */
	public function connect($config)
	{
		if (!is_resource($this->conn)) {
			$link = mysql_connect($config['host'], $config['user'], $config['passwd']);
			if (!$link){
				throw new Exception("create connect error :" . mysql_error());
			}
			$this->conn = $link;
			if (!mysql_select_db($config['dbname'], $link)) {
				throw new Exception("select db error: " . mysql_error());
			}
			mysql_query("set names utf8", $link);
		}
	}

	/**
	 * 执行sql语句，并返回Resource
	 * @param string $sql
	 * @throws Exception
	 * @return resource
	 */
	public function query($sql)
	{
		$this->query_result = mysql_query($sql, $this->conn);
		if ($this->query_result === false) {
			throw new Exception("exceute error, sql= {$sql} ;" . mysql_error());
		}
		return $this->query_result;
	}

	/**
	 * 执行select语句并返回结果
	 * @param string $sql
	 * @return array
	 */
	public function fetchAll($sql)
	{
		$this->query($sql);
		return $this->getAll($this->query_result);
	}

	public function fetchOne($sql)
	{
		$this->query($sql);
		return $this->getOne($this->query_result);
	}

	public function getOne($result)
	{
		if ($this->query_result) {
			$result =  mysql_fetch_assoc($this->query_result);
			if (!$result) {
				return array();
			}
			return $result;
		}
		throw new Exception('can not excute sql');
	}

	public function getAll($result)
	{
		if ($this->query_result) {
			$this->rows = array();
			while (($row = mysql_fetch_assoc($this->query_result)) !== false) {
				array_push($this->rows, $row);
			}
			return $this->rows;
		}
		throw new Exception('get query_result error ');
	}
	
	public function __destruct()
	{
		if (is_resource($this->query_result)) {
			mysql_free_result($this->query_result);
		}
		mysql_close($this->conn);
	}
}