<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Nov 07 07:04:42 GMT 2011
 * @desc 用于查询玩家信息，需要与服务端对接
 */

class Player {
	/**
	 * 按角色名、帐号名或ID查找玩家
	 *
	 * @param string $roleName
	 * @param string $accountName
	 * @param int $roleId
	 * @return array
	 */
	public static function getUser($roleName='',$accountName='',$roleId=false) {
		$roleId = intval($roleId);
		$roleName = SS(  $roleName  );
		$accountName = SS($accountName);
		$where = '';
		if ($roleId) {
			$where .= " `id`={$roleId} ";
		}elseif ($roleName) {
			$where .= " `name`='{$roleName}' ";
		}elseif ($accountName){
			$where .= " `account`='{$accountName}' ";
		}
		if (!$where) {
			return  array('roleId' =>0, 'roleName'=>'', 'accountName'=>'', 'roleLevel' =>0 );
		}else {
			$sql = " SELECT `id` AS roleId, `name` AS roleName, `account` AS accountName, `level` AS roleLevel, `gold`, last_login_time>last_logout_time AS online, `last_logout_ip` AS lastLoginIp FROM PLAYER_TBL WHERE {$where} ";
			$rs = GFetchRowOne($sql);
			return array(
				'roleId'=>intval($rs['roleId']), 
				'roleName'=>$rs['roleName'],  
				'accountName'=>$rs['accountName'], 
				'roleLevel'=>intval($rs['roleLevel']),
				'gold'=>intval($rs['gold']),
				'online'=>$rs['online'],
				'lastLoginIp'=>$rs['lastLoginIp']
			);
		}
	}
	/**
	 * 按最后登录IP查找玩家
	 *
	 * @param string $lastLoginIp
	 * @return array
	 */
	public static function getPlayerByIp($lastLoginIp) {
		$lastLoginIp = SS(  $lastLoginIp  );
		if (!$lastLoginIp) {
			return  array();
		}else {
			$sql = " SELECT `id` AS roleId, `name` AS roleName, `account` AS accountName, `level` AS roleLevel, `gold`, last_login_time>last_logout_time AS online, last_logout_ip as lastLoginIp FROM PLAYER_TBL WHERE last_logout_ip='{$lastLoginIp}' ";
			return GFetchRowSet($sql);
		}
	}
	
}
