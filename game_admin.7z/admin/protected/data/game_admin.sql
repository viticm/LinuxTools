-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2013 年 07 月 16 日 14:43
-- 服务器版本: 5.1.62-log
-- PHP 版本: 5.3.14

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `yjxy_admin_91s1`
--

-- --------------------------------------------------------

--
-- 表的结构 `t_load`
--

CREATE TABLE IF NOT EXISTS `t_load` (
  `lastLoadTime` int(11) NOT NULL COMMENT '上次导库时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `t_log_access`
--

CREATE TABLE IF NOT EXISTS `t_log_access` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `roleLevel` int(11) NOT NULL COMMENT '角色等级',
  `ip` varchar(32) NOT NULL COMMENT '登录时ip',
  `mTime` int(11) NOT NULL COMMENT '访问时间',
  `mDateTime` int(11) NOT NULL COMMENT '访问时间',
  `mYear` int(11) NOT NULL COMMENT '访问时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '访问时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '访问时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '访问时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '访问时间(周几)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='玩家访问日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_act`
--

CREATE TABLE IF NOT EXISTS `t_log_act` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `mType` int(11) NOT NULL COMMENT '操作类型',
  `mTime` int(11) NOT NULL COMMENT '操作时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='活动表';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_admin`
--

CREATE TABLE IF NOT EXISTS `t_log_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `username` varchar(64) NOT NULL DEFAULT '' COMMENT '管理员帐号名',
  `ip` varchar(32) NOT NULL DEFAULT '' COMMENT '管理员IP',
  `playerAccount` varchar(64) NOT NULL COMMENT '受影响的玩家帐号',
  `mTime` int(11) NOT NULL DEFAULT '0' COMMENT '操作时间',
  `mType` int(11) NOT NULL DEFAULT '0' COMMENT '操作类型',
  `detail` text NOT NULL COMMENT '操作内容',
  `num` int(11) NOT NULL COMMENT '涉及数量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='管理后台的日志表' AUTO_INCREMENT=68 ;

-- --------------------------------------------------------

--
-- 表的结构 `t_log_auction`
--

CREATE TABLE IF NOT EXISTS `t_log_auction` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `auctionId` int(11) NOT NULL COMMENT '拍卖流水账单号',
  `mType` tinyint(4) NOT NULL COMMENT '操作类型',
  `itemId` int(11) NOT NULL COMMENT '物品ID',
  `itemNum` int(11) NOT NULL COMMENT '物品数量',
  `price` int(11) NOT NULL COMMENT '售价',
  `mTime` int(11) NOT NULL COMMENT '操作时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='拍卖操作日志表';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_battle`
--

CREATE TABLE IF NOT EXISTS `t_log_battle` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `defId` int(11) NOT NULL COMMENT '防守角色ID',
  `defName` varchar(64) NOT NULL COMMENT '防守角色名',
  `defAccount` varchar(64) NOT NULL COMMENT '防守玩家帐号',
  `warType` tinyint(4) NOT NULL COMMENT '战斗类型',
  `processNum` tinyint(4) NOT NULL COMMENT '回合数',
  `winFlag` tinyint(4) NOT NULL COMMENT '胜负',
  `mTime` int(11) NOT NULL COMMENT '操作时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='战斗日志表';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_chat`
--

CREATE TABLE IF NOT EXISTS `t_log_chat` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '帐号名',
  `roleLevel` int(11) NOT NULL COMMENT '玩家等级',
  `content` varchar(160) NOT NULL COMMENT '聊天内容',
  `dstRoleId` int(11) NOT NULL COMMENT '对方角色ID',
  `dstRoleName` varchar(64) NOT NULL COMMENT '对方角色名',
  `dstAccountName` varchar(64) NOT NULL COMMENT '对方账号名',
  `dstRoleLevel` int(11) NOT NULL COMMENT '对方玩家等级',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间（0点unix时间）',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='玄晶日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_client`
--

CREATE TABLE IF NOT EXISTS `t_log_client` (
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `clientModel` varchar(64) NOT NULL COMMENT '客户端使用的机型',
  `releaseVersion` varchar(255) NOT NULL,
  `lastVersion` varchar(255) NOT NULL COMMENT '小包版本',
  `logStr` text COMMENT '日志信息',
  `mTime` int(11) NOT NULL COMMENT '操作时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户端日志表';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_client_load`
--

CREATE TABLE IF NOT EXISTS `t_log_client_load` (
  `logId` bigint(11) DEFAULT NULL COMMENT '日志ID',
  `roleId` int(11) DEFAULT NULL COMMENT '角色ID',
  `roleName` varchar(64) DEFAULT NULL COMMENT '角色名',
  `accountName` varchar(64) DEFAULT NULL COMMENT '玩家帐号',
  `roleLevel` int(11) DEFAULT NULL COMMENT '下线时玩家等级',
  `ip` varchar(32) NOT NULL COMMENT '登录IP',
  `step` tinyint(4) NOT NULL COMMENT '进度标识',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间(周几)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户端资源加载进度日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_create_page`
--

CREATE TABLE IF NOT EXISTS `t_log_create_page` (
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `ip` varchar(32) NOT NULL COMMENT 'IP',
  `mTime` int(11) NOT NULL COMMENT '访问时间',
  `mDateTime` int(11) NOT NULL COMMENT '访问时间',
  `mYear` int(11) NOT NULL COMMENT '访问时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '访问时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '访问时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '访问时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '访问时间(周几)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='创角页访问日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_crystal`
--

CREATE TABLE IF NOT EXISTS `t_log_crystal` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '帐号名',
  `roleLevel` int(11) NOT NULL COMMENT '玩家等级',
  `crystal` int(11) NOT NULL COMMENT '不绑定玄晶的数量',
  `bindcrystal` int(11) NOT NULL COMMENT '绑定玄晶的数量',
  `mType` int(11) NOT NULL COMMENT '操作类型',
  `itemId` int(11) NOT NULL COMMENT '涉及道具ID',
  `color` tinyint(4) NOT NULL COMMENT '道具颜色',
  `quality` tinyint(4) NOT NULL COMMENT '道具品质',
  `amount` int(11) NOT NULL COMMENT '涉及的道具或其他物品数量',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间（0点unix时间）',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='玄晶日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_exp`
--

CREATE TABLE IF NOT EXISTS `t_log_exp` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `exp` int(11) NOT NULL COMMENT '经验值',
  `mType` int(11) NOT NULL COMMENT '操作类型',
  `mTime` int(11) NOT NULL COMMENT '操作时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='经验表';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_experience`
--

CREATE TABLE IF NOT EXISTS `t_log_experience` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '帐号名',
  `roleLevel` int(11) NOT NULL COMMENT '玩家等级',
  `experience` int(11) NOT NULL COMMENT '不绑定阅历的数量',
  `bindExperience` int(11) NOT NULL COMMENT '绑定阅历的数量',
  `mType` int(11) NOT NULL COMMENT '操作类型',
  `itemId` int(11) NOT NULL COMMENT '涉及道具ID',
  `color` tinyint(4) NOT NULL COMMENT '道具颜色',
  `quality` tinyint(4) NOT NULL COMMENT '道具品质',
  `amount` int(11) NOT NULL COMMENT '涉及的道具或其他物品数量',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间（0点unix时间）',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='阅历日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_first_mission`
--

CREATE TABLE IF NOT EXISTS `t_log_first_mission` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `missionId` int(11) NOT NULL COMMENT '任务ID',
  `mTime` int(11) NOT NULL COMMENT '首个任务完成时间',
  `mDateTime` int(11) NOT NULL COMMENT '完成时间',
  `mYear` int(11) NOT NULL COMMENT '完成时间（年',
  `mMonth` tinyint(4) NOT NULL COMMENT '完成时间（月)',
  `mDate` tinyint(4) NOT NULL COMMENT '完成时间（日)',
  `mHour` tinyint(4) NOT NULL COMMENT '完成时间（小时)',
  `mWeek` tinyint(4) NOT NULL COMMENT '完成时间（周几)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='完成首个任务日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_first_view`
--

CREATE TABLE IF NOT EXISTS `t_log_first_view` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `ip` varchar(32) NOT NULL COMMENT 'IP',
  `useTime` int(11) NOT NULL COMMENT '耗时时间(秒)',
  `mTime` int(11) NOT NULL COMMENT '加载完成时间',
  `mDateTime` int(11) NOT NULL COMMENT '加载完成时间',
  `mYear` int(11) NOT NULL COMMENT '加载完成时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '加载完成时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '加载完成时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '加载完成时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '加载完成时间(周几)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='进入首场景日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_gold`
--

CREATE TABLE IF NOT EXISTS `t_log_gold` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '帐号名',
  `roleLevel` int(11) NOT NULL COMMENT '玩家等级',
  `gold` int(11) NOT NULL COMMENT '不绑定元宝的数量',
  `bindGold` int(11) NOT NULL COMMENT '绑定元宝的数量',
  `mType` int(11) NOT NULL COMMENT '操作类型',
  `itemId` int(11) NOT NULL COMMENT '涉及道具ID',
  `color` tinyint(4) NOT NULL COMMENT '道具颜色',
  `quality` tinyint(4) NOT NULL COMMENT '道具品质',
  `amount` int(11) NOT NULL COMMENT '涉及的道具或其他物品数量',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间（0点unix时间）',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='金币日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_item`
--

CREATE TABLE IF NOT EXISTS `t_log_item` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '帐号名',
  `roleLevel` int(11) NOT NULL COMMENT '玩家等级',
  `mType` int(11) NOT NULL COMMENT '操作类型',
  `itemId` int(11) NOT NULL COMMENT '涉及道具ID',
  `color` tinyint(4) NOT NULL COMMENT '道具颜色',
  `quality` tinyint(4) NOT NULL COMMENT '道具品质',
  `amount` int(11) NOT NULL COMMENT '涉及的道具数量',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间（0点unix时间）',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='道具日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_login`
--

CREATE TABLE IF NOT EXISTS `t_log_login` (
  `roleId` int(11) DEFAULT NULL COMMENT '角色ID',
  `roleName` varchar(64) DEFAULT NULL COMMENT '角色名',
  `accountName` varchar(64) DEFAULT NULL COMMENT '玩家帐号',
  `roleLevel` int(11) DEFAULT NULL COMMENT '下线时玩家等级',
  `loginIp` varchar(64) NOT NULL COMMENT '最后登录的IP',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间(周几)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色上线日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_logout`
--

CREATE TABLE IF NOT EXISTS `t_log_logout` (
  `roleId` int(11) DEFAULT NULL COMMENT '角色ID',
  `roleName` varchar(64) DEFAULT NULL COMMENT '角色名',
  `accountName` varchar(64) DEFAULT NULL COMMENT '玩家帐号',
  `loginTime` int(11) DEFAULT NULL COMMENT '登录时间',
  `logoutTime` int(11) DEFAULT NULL COMMENT '下线时间',
  `onlineTime` int(11) DEFAULT NULL COMMENT '在线时间(秒)',
  `roleLevel` int(11) DEFAULT NULL COMMENT '下线时玩家等级',
  `lastLoginIp` varchar(64) NOT NULL COMMENT '最后登录的IP',
  `logoutReason` int(11) NOT NULL COMMENT '退出原因编号',
  `loginDate` int(11) DEFAULT NULL COMMENT '登录时间',
  `logoutDate` int(11) DEFAULT NULL COMMENT '下线时间',
  `logoutMapId` int(11) DEFAULT NULL COMMENT '下线时的地图ID',
  `logoutX` int(11) DEFAULT NULL COMMENT '下线时的x坐标',
  `logoutY` int(11) DEFAULT NULL COMMENT '下线时的y坐标'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色下线日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_mission`
--

CREATE TABLE IF NOT EXISTS `t_log_mission` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `groupId` int(11) DEFAULT NULL COMMENT '任务组ID',
  `groupName` varchar(64) DEFAULT NULL COMMENT '任务组名',
  `missionId` int(11) NOT NULL COMMENT '任务ID',
  `missionName` varchar(64) NOT NULL COMMENT '任务名',
  `missionType` tinyint(4) NOT NULL COMMENT '任务类型',
  `status` tinyint(4) NOT NULL COMMENT '状态',
  `minLevel` int(11) NOT NULL COMMENT '可接此任务的最低角色等级',
  `maxLevel` int(11) NOT NULL COMMENT '可接此任务的最高角色等级',
  `loopTime` int(11) NOT NULL COMMENT '循环任务当天循环次数',
  `roleLevel` int(11) NOT NULL COMMENT '玩家完成当前任务的等级',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间(周几)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='任务日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_online`
--

CREATE TABLE IF NOT EXISTS `t_log_online` (
  `online` int(10) NOT NULL COMMENT '在线数量',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间(周几)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='玩家在线数历史表';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_pay`
--

CREATE TABLE IF NOT EXISTS `t_log_pay` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `orderId` varchar(128) NOT NULL COMMENT '订单号',
  `payMoney` float NOT NULL COMMENT '充值金额(元)',
  `payGold` int(11) NOT NULL COMMENT '充值获得的金币',
  `roleLevel` tinyint(4) NOT NULL COMMENT '充值时的等级',
  `totalTimes` int(11) NOT NULL COMMENT '玩家充值次数',
  `mTime` int(11) NOT NULL COMMENT '充值时间(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）',
  `onlineDays` int(11) NOT NULL COMMENT '上线第几天'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='玩家充值日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_pay_request`
--

CREATE TABLE IF NOT EXISTS `t_log_pay_request` (
  `logId` bigint(20) NOT NULL,
  `payToUser` varchar(100) NOT NULL DEFAULT '' COMMENT '充值用户名',
  `userIp` varchar(30) NOT NULL DEFAULT '' COMMENT '玩家IP',
  `detail` varchar(600) NOT NULL DEFAULT '' COMMENT '参数内容',
  `desc` varchar(300) NOT NULL DEFAULT '' COMMENT '备注',
  `mTime` int(11) NOT NULL,
  `action` tinyint(4) NOT NULL COMMENT '充值结果',
  PRIMARY KEY (`logId`),
  KEY `mtime` (`mTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='充值请求详细日志表';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_power`
--

CREATE TABLE IF NOT EXISTS `t_log_power` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `power` int(11) NOT NULL COMMENT '精力值',
  `mType` int(11) NOT NULL COMMENT '操作类型',
  `mTime` int(11) NOT NULL COMMENT '操作时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='精力表';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_register`
--

CREATE TABLE IF NOT EXISTS `t_log_register` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `roleSex` tinyint(4) NOT NULL COMMENT '角色性别',
  `roleJob` tinyint(4) NOT NULL COMMENT '角色职业',
  `ip` varchar(32) NOT NULL COMMENT 'IP	',
  `mTime` int(11) NOT NULL COMMENT '创角时间',
  `mDateTime` int(11) NOT NULL COMMENT '创角时间',
  `mYear` int(11) NOT NULL COMMENT '创角时间（年）	',
  `mMonth` tinyint(4) NOT NULL COMMENT '创角时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '创角时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '创角时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '创角时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色创建日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_repu`
--

CREATE TABLE IF NOT EXISTS `t_log_repu` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `roleLevel` int(11) NOT NULL COMMENT '玩家等级',
  `amount` int(11) NOT NULL COMMENT '声望数量',
  `mType` int(11) NOT NULL COMMENT '操作类型',
  `mTime` int(11) NOT NULL COMMENT '操作时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='声望表';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_silver`
--

CREATE TABLE IF NOT EXISTS `t_log_silver` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '帐号名',
  `roleLevel` int(11) NOT NULL COMMENT '玩家等级',
  `silver` int(11) NOT NULL COMMENT '不绑定元宝的数量',
  `bindSilver` int(11) NOT NULL COMMENT '绑定元宝的数量',
  `mType` int(11) NOT NULL COMMENT '操作类型',
  `itemId` int(11) NOT NULL COMMENT '涉及道具ID',
  `color` tinyint(4) NOT NULL COMMENT '道具颜色',
  `quality` tinyint(4) NOT NULL COMMENT '道具品质',
  `amount` int(11) NOT NULL COMMENT '涉及的道具或其他物品数量',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间（0点unix时间）',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='银币日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_spirit`
--

CREATE TABLE IF NOT EXISTS `t_log_spirit` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '帐号名',
  `roleLevel` int(11) NOT NULL COMMENT '玩家等级',
  `spirit` int(11) NOT NULL COMMENT '不绑定战魂的数量',
  `bindSpirit` int(11) NOT NULL COMMENT '绑定战魂的数量',
  `mType` int(11) NOT NULL COMMENT '操作类型',
  `itemId` int(11) NOT NULL COMMENT '涉及道具ID',
  `color` tinyint(4) NOT NULL COMMENT '道具颜色',
  `quality` tinyint(4) NOT NULL COMMENT '道具品质',
  `amount` int(11) NOT NULL COMMENT '涉及的道具或其他物品数量',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间（0点unix时间）',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='战魂日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_stage`
--

CREATE TABLE IF NOT EXISTS `t_log_stage` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `stageId` int(11) NOT NULL COMMENT '副本ID',
  `mTime` int(11) NOT NULL COMMENT '操作时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='副本表';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_tally`
--

CREATE TABLE IF NOT EXISTS `t_log_tally` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '帐号名',
  `roleLevel` int(11) NOT NULL COMMENT '玩家等级',
  `tally` int(11) NOT NULL COMMENT '不绑定玉符的数量',
  `bindTally` int(11) NOT NULL COMMENT '绑定玉符的数量',
  `mType` int(11) NOT NULL COMMENT '操作类型',
  `itemId` int(11) NOT NULL COMMENT '涉及道具ID',
  `color` tinyint(4) NOT NULL COMMENT '道具颜色',
  `quality` tinyint(4) NOT NULL COMMENT '道具品质',
  `amount` int(11) NOT NULL COMMENT '涉及的道具或其他物品数量',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间（0点unix时间）',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='玉符日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_target`
--

CREATE TABLE IF NOT EXISTS `t_log_target` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `roleLevel` int(11) NOT NULL COMMENT '角色等级',
  `targetId` int(11) NOT NULL COMMENT '目标ID',
  `targetType` tinyint(4) NOT NULL COMMENT '类型',
  `mTime` int(11) NOT NULL COMMENT '完成时间(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='目标完成日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_log_upgrade`
--

CREATE TABLE IF NOT EXISTS `t_log_upgrade` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `currentLevel` int(11) NOT NULL COMMENT '角色等级',
  `mTime` int(11) NOT NULL COMMENT '日志记录(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色升级日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_stat_gold`
--

CREATE TABLE IF NOT EXISTS `t_stat_gold` (
  `mDateTime` int(11) NOT NULL COMMENT '日期',
  `saveGold` bigint(11) NOT NULL COMMENT '存留不绑定金币',
  `saveBindGold` bigint(11) NOT NULL COMMENT '存留绑定金币',
  `consumeGold` bigint(11) NOT NULL COMMENT '消费不绑定金币',
  `consumeBindGold` bigint(11) NOT NULL COMMENT '消费绑定金币',
  `getGold` bigint(11) NOT NULL COMMENT '获得不绑定金币',
  `getBindGold` bigint(11) NOT NULL COMMENT '获得绑定金币',
  `circulateConsumeGold` bigint(11) NOT NULL COMMENT '流通消费金币',
  `circulateGetGold` bigint(11) NOT NULL COMMENT '流通获得金币',
  `lvGold` bigint(11) NOT NULL COMMENT '某等级以上金币留存',
  `lvBindGold` bigint(11) NOT NULL COMMENT '某等级以上绑定金币留存',
  PRIMARY KEY (`mDateTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='金币存量与消耗';

-- --------------------------------------------------------

--
-- 表的结构 `t_stat_return`
--

CREATE TABLE IF NOT EXISTS `t_stat_return` (
  `roleId` int(11) NOT NULL DEFAULT '0' COMMENT '角色ID',
  `roleName` varchar(64) DEFAULT NULL COMMENT '角色名',
  `accountName` varchar(64) DEFAULT NULL COMMENT '玩家帐号',
  `regDate` int(11) NOT NULL COMMENT '创建角色时间',
  `roleLevel` int(11) DEFAULT NULL COMMENT '下线时玩家等级',
  `firstLoginDate` int(11) NOT NULL COMMENT '首次登录时间',
  `secondLoginDate` int(11) NOT NULL COMMENT '第二次登录时间',
  `firstReturnDiffDay` int(11) NOT NULL COMMENT '首次回访间隔天数',
  `prevLoginDate` int(11) NOT NULL COMMENT '上次登录时间',
  `lastLoginDate` int(11) NOT NULL COMMENT '本次登录时间',
  `returnDiffDay` int(11) NOT NULL COMMENT '回访间隔天数',
  `seqLoginDay` int(11) NOT NULL COMMENT '连续登录天数',
  PRIMARY KEY (`roleId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='角色上线日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_stat_silver`
--

CREATE TABLE IF NOT EXISTS `t_stat_silver` (
  `mDateTime` int(11) NOT NULL COMMENT '日期',
  `saveSilver` bigint(11) NOT NULL COMMENT '存留不绑定银币',
  `saveBindSilver` bigint(11) NOT NULL COMMENT '存留绑定银币',
  `consumeSilver` bigint(11) NOT NULL COMMENT '消费不绑定银币',
  `consumeBindSilver` bigint(11) NOT NULL COMMENT '消费绑定银币',
  `getSilver` bigint(11) NOT NULL COMMENT '获得不绑定银币',
  `getBindSilver` bigint(11) NOT NULL COMMENT '获得绑定银币',
  `circulateConsumeSilver` bigint(11) NOT NULL COMMENT '流通消费银币',
  `circulateGetSilver` bigint(11) NOT NULL COMMENT '流通获得银币',
  PRIMARY KEY (`mDateTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='银币存量与消耗';

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
