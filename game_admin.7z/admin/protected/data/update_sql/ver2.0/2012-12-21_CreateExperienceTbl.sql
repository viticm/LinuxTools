USE game_admin;
--
-- 表的结构 `t_log_experience`
--
CREATE TABLE IF NOT EXISTS `t_log_experience` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '帐号名',
  `roleLevel` int(11) NOT NULL COMMENT '玩家等级',
  `experience` int(11) NOT NULL COMMENT '不绑定阅历的数量',
  `bindExperience` int(11) NOT NULL COMMENT '绑定阅历的数量',
  `mType` int(11) NOT NULL COMMENT '操作类型',
  `itemId` int(11) NOT NULL COMMENT '涉及道具ID',
  `color` tinyint(4) NOT NULL COMMENT '道具颜色',
  `quality` tinyint(4) NOT NULL COMMENT '道具品质',
  `amount` int(11) NOT NULL COMMENT '涉及的道具或其他物品数量',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间（0点unix时间）',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='阅历日志';