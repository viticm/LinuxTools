USE game_admin;
--
-- 表的结构 `t_log_client`
--
CREATE TABLE IF NOT EXISTS `t_log_client` (
  `accountName` varchar(64) NOT NULL COMMENT '玩家帐号',
  `clientModel` varchar( 64 ) NOT NULL COMMENT '客户端使用的机型',
  `logStr` text COMMENT '日志信息',
  `releaseVersion` varchar( 255 ) COMMENT '大包版本',
  `lastVersion` varchar( 255 ) COMMENT '小包版本',
  `mTime` int(11) NOT NULL COMMENT '操作时间',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户端日志表';