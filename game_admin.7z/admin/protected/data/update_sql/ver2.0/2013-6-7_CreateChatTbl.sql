USE game_admin;
--
-- 表的结构 `t_log_chat`
--
CREATE TABLE IF NOT EXISTS `t_log_chat` (
  `roleId` int(11) NOT NULL COMMENT '角色ID',
  `roleName` varchar(64) NOT NULL COMMENT '角色名',
  `accountName` varchar(64) NOT NULL COMMENT '帐号名',
  `roleLevel` int(11) NOT NULL COMMENT '玩家等级',
  `content` varchar( 160 ) NOT NULL COMMENT '聊天内容',
  `dstRoleId` int(11) NOT NULL COMMENT '对方角色ID',
  `dstRoleName` varchar(64) NOT NULL COMMENT '对方角色名',
  `dstAccountName` varchar(64) NOT NULL COMMENT '对方账号名',
  `dstRoleLevel` int(11) NOT NULL COMMENT '对方玩家等级',
  `mTime` int(11) NOT NULL COMMENT '日志记录时间(unix时间)',
  `mDateTime` int(11) NOT NULL COMMENT '日志记录时间（0点unix时间）',
  `mYear` int(11) NOT NULL COMMENT '日志记录时间（年）',
  `mMonth` tinyint(4) NOT NULL COMMENT '日志记录时间（月）',
  `mDate` tinyint(4) NOT NULL COMMENT '日志记录时间（日）',
  `mHour` tinyint(4) NOT NULL COMMENT '日志记录时间（小时）',
  `mWeek` tinyint(4) NOT NULL COMMENT '日志记录时间（周几）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='玄晶日志';