USE game_admin;
ALTER TABLE  `t_log_client` ADD  `releaseVersion` VARCHAR( 255 ) NOT NULL COMMENT  '大包版本' AFTER  `clientModel`;
ALTER TABLE  `t_log_client` ADD  `lastVersion` VARCHAR( 255 ) NOT NULL COMMENT  '小包版本' AFTER  `releaseVersion`;