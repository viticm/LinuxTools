<?php
/**
 * 数据定义文件
 * @var unknown_type
 */
define('GOLD_STAT_LEVEL', 10);//费数据统计中的元宝存量与消耗需要显示的级别