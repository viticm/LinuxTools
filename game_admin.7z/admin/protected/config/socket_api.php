<?php
/**
 * @author linruirong@4399.com
 * @Created  Wed Dec 07 10:58:38 GMT 2011
 * @desc 与服务端的socket 接口协议ID 配置列表
 */

//====以下配置主要是用于游戏管理后台与游戏服之间的即时交互，请按照以下格式配置:===//
//10玩家相关接口
//20消息、广播模块相关接口
//define('SOCKET_XXX',10XX);//XXX

define('SOCKET_PAY_TO_SERVER',            0xA001); //充值接口
define('SOCKET_GM_REPLY',                 0xA002); //GM回复接
define('SOCKET_GET_CURRENT_ONLINE',       0xA003); //获取当前在线人数
define('SOCKET_GM_CMD',                   0xA004); //GM指令接口
define('SOCKET_BAN_ACCOUNT',              0xA005); //封禁帐号登陆
define('SOCKET_UNBAN_ACCOUNT',            0xA006); //解禁帐号
define('SOCKET_BAN_IP',                   0xA007); //封禁IP登陆
define('SOCKET_UNBAN_IP',                 0xA008); //解禁IP
define('SOCKET_BAN_CHAT',                 0xA009); //禁言
define('SOCKET_UNBAN_CHAT',               0xA00A); //解禁言
define('SOCKET_BAN_IP_CHAT',              0xA00B); //IP禁言
define('SOCKET_BAN_IP_CHAT',              0xA00C); //解IP禁言
define('SOCKET_GET_ACCOUNT_BAN_LIST',     0xA00D); //获取帐号封禁列表
define('SOCKET_GET_IP_BAN_LIST',          0xA00E); //获取IP封禁列表
define('SOCKET_GET_CHAT_BAN_LIST',        0xA00F); //获取玩家禁言列表
define('SOCKET_SET_PLAYER_OFF_LINE',      0xA010); //把玩家踢下线
define('SOCKET_SEND_MONEY',               0xA011); //把给玩家送游戏币
define('SOCKET_SEND_ANNOUNCE',            0xA012); //发送系统公告
define('GPT_GM_SEND_MAIL',                0xA013); //发送系统邮件
define('GPT_GM_REWARD_VIP',               0xA014); //赠送VIP
define('GPT_GM_LOOP_AN_ADD',              0xA015); //添加循环公告
define('GPT_GM_LOOP_AN_DEL',              0xA016); //删除循环公告
define('GPT_GM_LOOP_AN_UPDATE',           0xA017); //公告更新
define('GPT_GM_LOOP_AN_LIST',             0xA018); //公告列表
define('GPT_GM_SEND_CDKEY_MAIL',          0xA01A); //发送CDKEY

//define('SOCKET_GET_PLAYER_INFO_BY_IP',    0xA007); //按ip查询玩家信息
