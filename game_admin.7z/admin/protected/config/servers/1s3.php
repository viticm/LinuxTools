<?php
// 注意：以下各配置项严禁手动修改，必须通过登录授权系统中的“服务器管理”进行修改，
//      否则将导致数据出错！
define('SERVER_NAME', '1s3'); //服务器编号
define('SERVER_ID', '3'); //服务器索引号
define('AGENT_NAME', '1'); //代理名称
define('AGENT_ID', '1'); //代理编号
define('DB_HOST', 'localhost'); //数据库所在机器地址
define('DB_USER', 'root_gm'); //数据库用户名
define('DB_PASSWD', 'mysql'); //数据库密码
define('DB_NAME', 'game_admin'); //数据库名
define('GAME_ADMIN_URL', 'http://admins1.yjxy.local.com/'); //本服管理后台地址
define('GAME3W_URL', 'http://applyserver.local.com/'); //本服游戏入口后台地址
define('GAME3W_AUTH_KEY', 'a5395fa6f42bf2b2fe91bd767e36a2b9'); //游戏管理后台与游戏前端入口校验的
define('PLATFORM_LOGIN_KEY', '1234562'); //平台登录key
define('SERVER_SOCKET_HOST', '192.168.1.106'); //服务端所在机地址
define('SERVER_SOCKET_PORT', '9333'); //服务端端口
define('SERVER_AUTH_KEY', 'da1b52975d14c27c6b0b117bec7f1f3b'); //管理后台与服务端校验
define('SERVER_API_URL', 'localhost'); //服务端接口地址
define('SYSDIR_GAME_ETL_CSV', '/tmp/logcsv/1s3/'); //格式化后的csv文件存放路径
define('SYSDIR_GAME_LOG', '/data/logs/yjxy/1s3/'); //日志总目录
define('SYSDIR_GAME_LOG_WAIT','/data/logs/yjxy/1s3//wait'); //等待处理的日志存放路径
define('SYSDIR_GAME_LOG_ERROR','/data/logs/yjxy/1s3//error'); //错误日志存放路径
define('SYSDIR_GAME_LOG_OK','/data/logs/yjxy/1s3//ok'); //已经入库日志存放路径
define('GM_SYSTEM_AUTH_KEY','1234563'); //游戏管理后台与GM后台验证的key
define('GM_SYNC_COMPLAINT_URL','http://admin.yjxy.local.com/'); //GM后台接收投诉的api地址
define('GAME_ADMIN_AUTH_KEY','1234564'); //游戏管理后台与中央后台验证key
define('SERVER_ONLINE_DATE','2012-11-05'); //开服日期
define('DB_GAME_HOST','localhost'); //游戏库所在机地址
define('DB_GAME_USER','root'); //游戏库用户名
define('DB_GAME_PASSWD','111111'); //游戏库密码
define('DB_GAME_DB_NAME','hzl_character'); //游戏库名