<?php
/**
 * @author linruirong@4399.com
 * @Created  Wed Dec 07 07:09:43 GMT 2011
 * @desc 用于控制游戏入口开关
 */

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';

$action = $_GET['action'];
define('GAME_SERVER_ON',1); //游戏正常开启状态
define('GAME_SERVER_OFF',2); //游戏关闭状态
define('GAMER_SERVER_GET_STATUS_URL',GAME3W_URL.'api/get_server_status.php'); //获取游戏前端入口状态接口
define('GAMER_SERVER_SET_STATUS_URL',GAME3W_URL.'api/set_server_status.php'); //设置游戏前端入口状态接口

$serverStatus = @file_get_contents(GAMER_SERVER_GET_STATUS_URL);
$serverStatus = intval($serverStatus);

if ('toggleGameSwitch' == $action ) {
	if (GAME_SERVER_ON==$serverStatus) { //如果当前开户,则关闭
		 $newServerStatus = GAME_SERVER_OFF;
	}else {
		 $newServerStatus = GAME_SERVER_ON;
	}
	$timestamp = time();
	$key = md5($timestamp.GAME3W_AUTH_KEY);
	$params = "timestamp={$timestamp}&key={$key}&switch={$newServerStatus}";
	$jsonResult = @file_get_contents(GAMER_SERVER_SET_STATUS_URL.'?'.$params);
	$result = json_decode($jsonResult,true);
	if(1==$result['result']){
		$strMsg='操作成功!';
		$serverStatus = $newServerStatus;
		$loger = new AdminLog();
		$detail = $serverStatus==2?"关闭游戏开关":"开启游戏开关";
		$loger->writeLog(AdminLog::LOG_TYPE_SET_GAME_STATUS, $detail);
	}else{
		$strMsg='操作失败!原因:'.$result['errorMsg'];
	}
}
$data  = array(
	'serverStatus'=>$serverStatus,
	'strMsg'=>$strMsg,
);
render('switch/switch.tpl', $data);
