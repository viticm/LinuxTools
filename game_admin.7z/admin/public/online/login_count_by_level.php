<?php

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$GAME_MIN_LEVEL = 1;
$GAME_MAX_LEVEL = 120;
$minLevel = intval($_POST['minLevel']);
$maxLevel = intval($_POST['maxLevel']);
$minLevel = $minLevel && $minLevel >= $GAME_MIN_LEVEL ? $minLevel : $GAME_MIN_LEVEL ;
$maxLevel = $maxLevel && $maxLevel <= $GAME_MAX_LEVEL ? $maxLevel : $GAME_MAX_LEVEL ;

$tmpStartTime = strtotime($_POST['startDate']);
$tmpEndTime = strtotime($_POST['endDate']);
$startTime = $tmpStartTime ? $tmpStartTime  : strtotime(date('Y-m-d',strtotime('-6day')));
$endTime = $tmpEndTime ? $tmpEndTime  : strtotime(date('Y-m-d'));
$startDate = date('Y-m-d',$startTime);
$endDate = date('Y-m-d',$endTime);
$prevDate = date('Y-m-d',$startTime-86400);
$nextDate = date('Y-m-d',$startTime+86400);
$startYmd = date('Ymd',$startTime);
$endYmd = date('Ymd',$endTime);
$tblLogout = 't_log_logout';


$sqlLogout =" SELECT logoutDate, roleLevel, COUNT(DISTINCT roleId) AS roleCnt, COUNT(roleId) as roleTimes  FROM {$tblLogout} 
			  WHERE logoutDate BETWEEN {$startTime} AND {$endTime}
			  AND roleLevel >= {$minLevel} AND roleLevel <= {$maxLevel}
			  GROUP BY logoutDate, roleLevel ";
$rsLogout = fetchRowSet($sqlLogout);

$initData = array();
for ($i=$minLevel; $i<=$maxLevel; $i++){
	$initData[$i] = 0;
}

$arrResult = array();
$maxCnt = 0;

$diffDay = ($endTime - $startTime)/86400;
$serverOnlineTime = strtotime(SERVER_ONLINE_DATE);
for ($i=$diffDay; $i>=0 ; $i--){
	$datetime = strtotime ("+{$i}day",$startTime);
	$arrResult[$datetime] = $initData;
}

foreach ($rsLogout as &$row) {
	$arrResult[$row['logoutDate']][$row['roleLevel']] = $row['roleCnt'];
	$maxCnt =$row['roleCnt'] > $maxCnt ? $row['roleCnt'] : $maxCnt;
}

$data = array(
	'arrResult'=>$arrResult,
	'maxCnt'=>$maxCnt,
	'minLevel'=>$minLevel,
	'maxLevel'=>$maxLevel,
	'startDate'=>$startDate,
	'endDate'=>$endDate,
	'prevDate' =>$prevDate,
	'nextDate' =>$nextDate,
	'serverOnlineDate' =>SERVER_ONLINE_DATE,
	'today' =>date('Y-m-d'),
);
render('online/login_count_by_level.tpl',$data);
exit();
