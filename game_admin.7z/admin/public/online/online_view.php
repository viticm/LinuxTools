<?php
/**
 * @author linruirong@4399.com
 * @Created  Sat Dec 10 03:10:37 GMT 2011
 * @desc 显示每天在线变化图
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
$bViewFull = true;
if (isPost()) {
	$dateStartTimeStamp = strtotime($_POST['dateStart']);
	$dateEndTimeStamp = strtotime($_POST['dateEnd']);
}
$bViewFull = 'small' == GetUrlParam( 'view' ) ? false : true;
$iTimeInterval = 0;
$iWidthScale = 100;
$dateStartTimeStamp = $dateStartTimeStamp ? $dateStartTimeStamp : strtotime(date('Y-m-d'));
$dateEndTimeStamp = $dateEndTimeStamp ? $dateEndTimeStamp : strtotime(date('Y-m-d'));
$dateStart = date('Y-m-d', $dateStartTimeStamp);
$dateEnd = date('Y-m-d', $dateEndTimeStamp);
$iTimeInterval = time() - $dateStartTimeStamp;
$iViewPointWidthScale = 10; // every point have width scale
$iOnlineViewPoint = intval( $iTimeInterval / ( 60 * 5 ) ); // every 5 minutes is a view point
$iWidthScale = $iOnlineViewPoint - intval( 100 / $iViewPointWidthScale ) > 0 ? 
    ( $iOnlineViewPoint - intval( 100 / $iViewPointWidthScale ) ) * $iViewPointWidthScale + $iWidthScale : $iWidthScale;
    
$sql = " select * from t_log_online where mDateTime>={$dateStartTimeStamp} and mDateTime<={$dateEndTimeStamp} order by mTime asc ";
$rs= fetchRowSet($sql);
$strText = '';
$strData = '';
foreach ($rs as &$row) {
	$strText .= '\''.date('Y-m-d H:i', $row['mTime']).'\',';
	$strData .=  intval($row['online']).',';
}
$strText = trim($strText,',');
$strData = trim($strData,',');
$iWidthScale = true === $bViewFull ? $iWidthScale : 100;
$data = array(
	'dateStart' => &$dateStart,
	'dateEnd' => &$dateEnd,
	'strText' => &$strText,
	'strData' => &$strData,
    'iWidthScale' => &$iWidthScale,
);

render('online/online_view.tpl', $data);

