<?php
/**
 * game admin website
 * @desc this file is online time of diffrent days
 * @link duchuanpd@gmail.com
 * @copyright Copyright (c) 2012-2013 Gzpd.(www.gzpindian.com)
 * @license none
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';

$iServerOnlineTime = strtotime(SERVER_ONLINE_DATE);
$iTodayTime = strtotime( date( 'Y-m-d' ) );
$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStart = $dateStartStamp ? date('Y-m-d H:i:s',$dateStartStamp) : date('Y-m-d',strtotime('-6day')).' 00:00:00';
$dateEnd = $dateEndStamp ? date('Y-m-d H:i:s',$dateEndStamp) : date('Y-m-d').' 23:59:59';

$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);

$rowPerPage = intval($_POST['rowPerPage']);
$rowPerPage = $rowPerPage ? $rowPerPage : LIST_PER_PAGE_RECORDS;
$page = intval($_POST['page']);
$page = $page > 0 ? $page : 1;

//===============start 查角色==============//
$role = $_POST['role'];
$msg = array();
$bSearchRole = false;
if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	$bSearchRole = true;
	if (!$role['roleId']) {
		$msg[] = '找不到对应玩家';
	}
}
//===============end 查角色===============//

$where = " where `logoutTime`>={$dateStartStamp} and `logoutTime` <= {$dateEndStamp} ";
$where .= $role['roleId'] ? " and roleId = {$role['roleId']} ":'';
$where .= ' GROUP BY `logoutDate`,`roleId` ORDER BY `logoutDate` ASC';
//===========查出记录数=======
$sqlCnt = " SELECT `roleId` FROM t_log_logout {$where} ";
$rsCnt = fetchRowSet($sqlCnt);
$rowCount = count( $rsCnt );
//===========================

$offset = ($page-1) * $rowPerPage;//每页开始位置
$pageCount =  ceil($rowCount/$rowPerPage);
$pageList = getPages($page, $rowCount, $rowPerPage);

//===========查出符合条件的数据=======
$sql = "SELECT SUM(`onlineTime`) AS `onlineTime`, `logoutDate`, `roleId`, `roleName`, `accountName`, `roleLevel`, `lastLoginIp`";
$sql .= " FROM `t_log_logout` {$where} limit  {$offset} , {$rowPerPage} ";
$rs = fetchRowSet($sql);
//=================================

//find the roleId list
//$cSqlStr = 'SELECT `roleId` FROM `t_log_logout` '.$where;
//$Arr_RoleIdList = fetchRowSet( $cSqlStr );

//find all login roleId list
$cWhere = '';
$cWhere = ' WHERE `logoutTime`>= '.$iServerOnlineTime.' and `logoutTime` <= '.$iTodayTime;
$cWhere .= ' GROUP BY `logoutTime`';
$cSqlStr = '';
$cSqlStr .= ' SELECT DISTINCT `roleId` FROM `t_log_logout` '.$cWhere;
$Arr_AllLoginRoleIdList = fetchRowSet( $cSqlStr );
$iAllLoginUser = count( $Arr_AllLoginRoleIdList );

//find all role online time
$cWhere = '';
$cWhere .= ' WHERE `logoutTime`>= '.$iServerOnlineTime.' and `logoutTime` <= '.$iTodayTime;
$cSqlStr = '';
$cSqlStr .= 'SELECT SUM(`onlineTime`) AS `onlineTime` FROM `t_log_logout` '.$cWhere;
$Arr_AllOnlineTime = fetchRowOne( $cSqlStr );
$iAllPlayerOnlineTime = $Arr_AllOnlineTime[ 'onlineTime' ];

//get the all online data of the search time
$cWhere = '';
$cWhere .= ' WHERE `logoutTime`>= '.$dateStartStamp.' and `logoutTime` <= '.$dateEndStamp;
$cWhere .= $role['roleId'] ? " and roleId = {$role['roleId']} ":'';
$cWhere .= ' GROUP BY `roleId`, `logoutDate` ORDER BY `logoutDate` ASC';
$cSqlStr = '';
$cSqlStr .= 'SELECT SUM(`onlineTime`) AS `onlineTime`, `roleId` FROM `t_log_logout` '.$cWhere;
$Arr_AllRoleOnlineTime = fetchRowSet( $cSqlStr );

//get the server online days
$Arr_DiffServerOnlineAndTodayDate = diffDate( $iServerOnlineTime, $iTodayTime );
$iServerOnlineDays = $Arr_DiffServerOnlineAndTodayDate[ 'diffDays' ] + 1;

//get all player avg online time
$iAllPlayerAvgOnlineTime = 0;
$iAllPlayerAvgOnlineTime = 0 == $iAllLoginUser || 0 == $iServerOnlineDays ? 0 : $iAllPlayerOnlineTime / ( $iAllLoginUser * $iServerOnlineDays );
//total onlineTime and AvgOnlineTime of the search time
$Arr_TotalAndAvgOnlineTime = array();
$Arr_AllTotalAndAvgOnlineTime = array();
$Arr_AllTotalAndAvgOnlineTime[ 'totalOnlineTime' ] = 0;
$Arr_AllTotalAndAvgOnlineTime[ 'avgOnlineTime' ] = 0;
$Arr_AllTotalAndAvgOnlineTime[ 'totalAvgOnlineTime' ] = 0;
$iLoginPlayers = count( $rs );
$Arr_DiffStartAndEndDate = diffDate( $dateStartStamp, $dateEndStamp );
$iLoginDays = $Arr_DiffStartAndEndDate[ 'diffDays' ] + 1;
foreach ( $rs as $key1 => $Role )
{
	$Arr_TotalAndAvgOnlineTime[ $Role[ 'roleId' ] ] = array();
	$Arr_TotalAndAvgOnlineTime[ $Role[ 'roleId' ] ][ 'totalOnlineTime' ] = 0;
	$Arr_TotalAndAvgOnlineTime[ $Role[ 'roleId' ] ][ 'avgOnlineTime' ] = 0;
	foreach ( $Arr_AllRoleOnlineTime as $key2 => $Player )
	{
		if( $Role[ 'roleId' ] == $Player[ 'roleId' ] )
		{
			$Arr_TotalAndAvgOnlineTime[ $Role[ 'roleId' ] ][ 'totalOnlineTime' ] += $Player[ 'onlineTime' ];
		}
	}
	$Arr_AllTotalAndAvgOnlineTime[ 'totalOnlineTime' ] += $Arr_TotalAndAvgOnlineTime[ $Role[ 'roleId' ] ][ 'totalOnlineTime' ];
	$Arr_TotalAndAvgOnlineTime[ $Role[ 'roleId' ] ][ 'avgOnlineTime' ] = 0 == $iLoginDays ? 0 :
	    $Arr_TotalAndAvgOnlineTime[ $Role[ 'roleId' ] ][ 'totalOnlineTime' ] / $iLoginDays;
}
$Arr_AllTotalAndAvgOnlineTime[ 'avgOnlineTime' ] = 0 == $iLoginPlayers || 0 == $iLoginDays ? 0 : 
    $Arr_AllTotalAndAvgOnlineTime[ 'totalOnlineTime' ] / ( $iLoginPlayers * $iLoginDays );


$data = array(
	'dateStart'=>&$dateStart,
	'dateEnd'=>&$dateEnd,
	'rowPerPage'=>&$rowPerPage,
	'rowCount'=>&$rowCount,
	'page'=>&$page,
	'pageCount'=>&$pageCount,
	'pageList'=>&$pageList,
	'role' => &$role,
	'rs' => &$rs,
    'Arr_TotalAndAvgOnlineTime' => &$Arr_TotalAndAvgOnlineTime,
    'Arr_AllTotalAndAvgOnlineTime' => &$Arr_AllTotalAndAvgOnlineTime,
    'iAllPlayerAvgOnlineTime' => &$iAllPlayerAvgOnlineTime,
	'msg' => empty($msg) ? '' : implode('<br>',$msg),
);
render('online/online_time.tpl',&$data);