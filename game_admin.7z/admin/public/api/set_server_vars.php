<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Oct 31 14:46:45 GMT 2011
 * @desc 设置各游戏服管理后台配置。
 */
include_once '../../protected/config/config.php';
require_once ( SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'functions.php' );
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'my_global.php');
$ticket = GetUrlParam( 'ticket' );
$base64Params = GetUrlParam( 'base64Params' );
$jsonParams = base64_decode(base64_decode($base64Params));
$key = md5(GATEWAY_SYSTEM_AUTH_KEY.$base64Params);

$result['result'] = 1;
$result['errorMsg'] = '';
if ($key == $ticket) {
	$params = json_decode($jsonParams,true);
	if (!$params['SERVER_NAME']) {
		$result['result'] = 3;
		$result['errorMsg'] = '服务器编号不能为空';
		dieJson($result);
	}
	$path = SYSDIR_ADMIN_CONFIG_SERVERS.DIRECTORY_SEPARATOR.$params['SERVER_NAME'].'.php';
	if (file_exists($path) && !is_writable($path)) {
		$result['result'] = 4;
		$result['errorMsg'] = "{$path} ,文件不可写";
		dieJson($result);
	}
	if (!file_exists($path) && !is_writable(SYSDIR_ADMIN_CONFIG_SERVERS)) {
		$result['result'] = 5;
		$result['errorMsg'] = SYSDIR_ADMIN_CONFIG_SERVERS."，目录不可写";
		dieJson($result);
	}
	if ($params['SYSDIR_GAME_ETL_CSV'] && !file_exists($params['SYSDIR_GAME_ETL_CSV'])) {
		$mkdirRs = @mkdir($params['SYSDIR_GAME_ETL_CSV'],0777);
		if (!$mkdirRs) {
			$result['result'] = 5;
			$result['errorMsg'] = $params['SYSDIR_GAME_ETL_CSV']."，目录创建失败";
			dieJson($result);
		}
	}
	if ($params['SYSDIR_GAME_LOG'] && !file_exists($params['SYSDIR_GAME_LOG'])) {
		$mkdirRs = @mkdir($params['SYSDIR_GAME_LOG'],0777);
		if (!$mkdirRs) {
			$result['result'] = 5;
			$result['errorMsg'] = $params['SYSDIR_GAME_LOG']."，目录创建失败";
			dieJson($result);
		}
	}
	if ($params['SYSDIR_GAME_LOG_WAIT'] && !file_exists($params['SYSDIR_GAME_LOG_WAIT'])) {
		$mkdirRs = @mkdir($params['SYSDIR_GAME_LOG_WAIT'],0777);
		if (!$mkdirRs) {
			$result['result'] = 5;
			$result['errorMsg'] = $params['SYSDIR_GAME_LOG_WAIT']."，目录创建失败";
			dieJson($result);
		}
	}
	if ($params['SYSDIR_GAME_LOG_ERROR'] && !file_exists($params['SYSDIR_GAME_LOG_ERROR'])) {
		$mkdirRs = @mkdir($params['SYSDIR_GAME_LOG_ERROR'],0777);
		if (!$mkdirRs) {
			$result['result'] = 5;
			$result['errorMsg'] = $params['SYSDIR_GAME_LOG_ERROR']."，目录创建失败";
			dieJson($result);
		}
	}
	if ($params['SYSDIR_GAME_LOG_OK'] && !file_exists($params['SYSDIR_GAME_LOG_OK'])) {
		$mkdirRs = @mkdir($params['SYSDIR_GAME_LOG_OK'],0777);
		if (!$mkdirRs) {
			$result['result'] = 5;
			$result['errorMsg'] = $params['SYSDIR_GAME_LOG_OK']."，目录创建失败";
			dieJson($result);
		}
	}

	//create db
    if ( $params['DB_NAME'] )
    {
        $OBJ_DB                 = new MysqlNew();
        $Arr_DB                 = array();
        $Arr_DB[ 'host' ]       = $params['DB_HOST'];
        $Arr_DB[ 'user' ]       = $params['DB_USER'];
        $Arr_DB[ 'password' ]   = $params['DB_PASSWD'];
        $OBJ_DB->connect( $Arr_DB );
        if( true === $OBJ_DB->bConnect )
        {
            $cSqlStr        = '';
            $cSqlStr       .= 'SHOW DATABASES';
            $Arr_DBList     = array();
            $Arr_DBList     = $OBJ_DB->fetchAll( $cSqlStr );
            $Arr_DBListSort = array();
            foreach ( $Arr_DBList as $key => $val )
            {
                array_push( $Arr_DBListSort, $val[ 'Database' ] );
            }
            if( !in_array( $params[ 'DB_NAME' ], $Arr_DBListSort ) )
            {
                $cSqlStr  = '';
                $cSqlStr .= 'CREATE DATABASE IF NOT EXISTS ' .$params[ 'DB_NAME' ]. ' DEFAULT CHARACTER SET UTF8';
                if( !$OBJ_DB->query( $cSqlStr ) )
                {
                    $result[ 'result' ]   = 7;
                    $result[ 'errorMsg' ] = '数据库' .$params[ 'DB_NAME' ]. '创建失败';
                    unset( $OBJ_DB );
                    dieJson( $result );
                }
                else
                {
                	$Arr_DB[ 'dbname' ] = $params[ 'DB_NAME' ];
                	$OBJ_DB->connect( $Arr_DB ); // reconnect
                    $cSqlFile     = SYSDIR_ADMIN_PROTECTED.'/data/game_admin.sql';
                    if( !$OBJ_DB->sourceLinuxSqlFile( $cSqlFile ) )
                    {
                    	$result[ 'result' ]   = 8;
                    	$result[ 'errorMsg' ] = '数据库' .$params[ 'DB_NAME' ]. ' sqlfile: ' .$cSqlFile. '执行失败';
                    	unset( $OBJ_DB );
                    	dieJson( $result );
                    }
                }
            }
        }
        else
        {
            $result[ 'result' ] = 6;
            $result[ 'errorMsg' ] = '连接到后台数据库失败';
            unset( $OBJ_DB );
            dieJson( $result );
        }
        unset( $OBJ_DB );
    }

	$strParams =<<<STR
<?php
// 注意：以下各配置项严禁手动修改，必须通过登录授权系统中的“服务器管理”进行修改，
//      否则将导致数据出错！
define('SERVER_NAME', '{$params['SERVER_NAME']}'); //服务器编号
define('SERVER_ID', '{$params['SERVER_ID']}'); //服务器索引号
define('AGENT_NAME', '{$params['AGENT_NAME']}'); //代理名称
define('AGENT_ID', '{$params['AGENT_ID']}'); //代理编号
define('DB_HOST', '{$params['DB_HOST']}'); //数据库所在机器地址
define('DB_USER', '{$params['DB_USER']}'); //数据库用户名
define('DB_PASSWD', '{$params['DB_PASSWD']}'); //数据库密码
define('DB_NAME', '{$params['DB_NAME']}'); //数据库名
define('GAME_ADMIN_URL', '{$params['GAME_ADMIN_URL']}'); //本服管理后台地址
define('GAME3W_URL', '{$params['GAME3W_URL']}'); //本服游戏入口后台地址
define('GAME3W_AUTH_KEY', '{$params['GAME3W_AUTH_KEY']}'); //游戏管理后台与游戏前端入口校验的
define('PLATFORM_LOGIN_KEY', '{$params['PLATFORM_LOGIN_KEY']}'); //平台登录key
define('SERVER_SOCKET_HOST', '{$params['SERVER_SOCKET_HOST']}'); //服务端所在机地址
define('SERVER_SOCKET_PORT', '{$params['SERVER_SOCKET_PORT']}'); //服务端端口
define('SERVER_AUTH_KEY', '{$params['SERVER_AUTH_KEY']}'); //管理后台与服务端校验
define('SERVER_API_URL', '{$params['SERVER_API_URL']}'); //服务端接口地址
define('SYSDIR_GAME_ETL_CSV', '{$params['SYSDIR_GAME_ETL_CSV']}'); //格式化后的csv文件存放路径
define('SYSDIR_GAME_LOG', '{$params['SYSDIR_GAME_LOG']}'); //日志总目录
define('SYSDIR_GAME_LOG_WAIT','{$params['SYSDIR_GAME_LOG_WAIT']}'); //等待处理的日志存放路径
define('SYSDIR_GAME_LOG_ERROR','{$params['SYSDIR_GAME_LOG_ERROR']}'); //错误日志存放路径
define('SYSDIR_GAME_LOG_OK','{$params['SYSDIR_GAME_LOG_OK']}'); //已经入库日志存放路径
define('GM_SYSTEM_AUTH_KEY','{$params['GM_SYSTEM_AUTH_KEY']}'); //游戏管理后台与GM后台验证的key
define('GM_SYNC_COMPLAINT_URL','{$params['GM_SYNC_COMPLAINT_URL']}'); //GM后台接收投诉的api地址
define('GAME_ADMIN_AUTH_KEY','{$params['GAME_ADMIN_AUTH_KEY']}'); //游戏管理后台与中央后台验证key
define('SERVER_ONLINE_DATE','{$params['SERVER_ONLINE_DATE']}'); //开服日期
define('DB_GAME_HOST','{$params['DB_GAME_HOST']}'); //游戏库所在机地址
define('DB_GAME_USER','{$params['DB_GAME_USER']}'); //游戏库用户名
define('DB_GAME_PASSWD','{$params['DB_GAME_PASSWD']}'); //游戏库密码
define('DB_GAME_DB_NAME','{$params['DB_GAME_DB_NAME']}'); //游戏库名
STR;

	$inputSize = file_put_contents($path, $strParams);
	if (!$inputSize) {
		$result['result'] = 6;
		$result['errorMsg'] = '出现未知错误，写入失败';
		dieJson($result);
	}else {
		dieJson($result);
	}
}else {
	$result = array(
		'result'=> 2,
		'errorMsg'=>'key验证不通过',
	);
	dieJson($result);
}

//==============
function dieJson($arr)
{
	echo json_encode($arr);
	die();
}