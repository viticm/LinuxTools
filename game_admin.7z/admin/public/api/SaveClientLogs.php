<?php
/**
 * @uses for save client log api
 * @author viticm<duchuanpd@gmail.com>
 * @date 2013-6-24
 */
require_once '../../protected/config/config.php';
require_once SYSDIR_ADMIN_INCLUDE.'/GlobalForClientApi.php';

$cAccountName     = GetUrlParam( 'uin' );
$cClientModel     = GetUrlParam( 'clientModel' );
$cLogStr          = GetUrlParam( 'logStr' );
$cReleaeVersion   = GetUrlParam( 'releaseVersion' );
$cLastVersion     = GetUrlParam( 'lastVersion' );
$iCreateTimeStamp = intval( GetUrlParam( 'timeStamp' ) );

$Arr_Result                = array(); //result array
$Arr_Result[ 'ErrorCode' ] = 1;
$Arr_Result[ 'ErrorDesc' ] = '';

// error code 1-10 use by global, this file error code begin by 10
if( empty( $cAccountName ) || empty( $cClientModel ) || empty( $cLogStr ) || empty( $iCreateTimeStamp ) )
{
    $Arr_Result[ 'ErrorCode' ] = 11;
    $Arr_Result[ 'ErrorDesc' ] = urlencode( 'params lost!' );
    SprintJsonStrAndExit( $Arr_Result );
}

$Arr_Data                     = array();
$Arr_Data[ 'accountName' ]    = $cAccountName;
$Arr_Data[ 'clientModel' ]    = $cClientModel;
$Arr_Data[ 'releaseVersion' ] = $cReleaeVersion ? $cReleaeVersion : "";
$Arr_Data[ 'lastVersion' ]    = $cLastVersion ? $cLastVersion : "";
$Arr_Data[ 'logStr' ]         = str_replace( "'", "\'", str_replace( "\\", "/", $cLogStr ) );
$Arr_Data[ 'mTime' ]          = $iCreateTimeStamp;
$Arr_Data[ 'mYear' ]          = date( 'Y', $Arr_Data[ 'mTime' ] );
$Arr_Data[ 'mMonth' ]         = date( 'm', $Arr_Data[ 'mTime' ] );
$Arr_Data[ 'mDate' ]          = date( 'd', $Arr_Data[ 'mTime' ] );
$Arr_Data[ 'mHour' ]          = date( 'H', $Arr_Data[ 'mTime' ] );
$Arr_Data[ 'mWeek' ]          = date( 'w', $Arr_Data[ 'mTime' ] );

$cSqlStr  = '';
$cSqlStr .= makeInsertSql( 't_log_client', $Arr_Data );
if ( false === $cSqlStr )
{
	$Arr_Result[ 'ErrorCode' ] = 12;
	$Arr_Result[ 'ErrorDesc' ] = urlencode( 'get insert sql string failed!' );
	SprintJsonStrAndExit( $Arr_Result );
}

$bQueryReturn = dbQuery( $cSqlStr ); // do db query
if ( false === $bQueryReturn )
{
	$Arr_Result[ 'ErrorCode' ] = 13;
	$Arr_Result[ 'ErrorDesc' ] = urlencode( 'query sql to db failed!' );
}
SprintJsonStrAndExit( $Arr_Result );