<?
/*
 * 输出服务器概况数据
 * 
 */
 

include_once '../../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global_for_central_api.php';

$dateStart = SS($_GET['dateStart']);
$dateEnd = SS($_GET['dateEnd']);
$dateStart = $dateStart ? $dateStart :  date('Y-m-d',strtotime('-6day'));
$dateEnd = $dateEnd ? $dateEnd : date("Y-m-d");

$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);

$summary['AGENT_NAME'] = AGENT_NAME;
$summary['SERVER_NAME'] = SERVER_NAME;
$summary['SERVER_ONLINE_DATE'] = SERVER_ONLINE_DATE;
$summary['onlineDays'] = (strtotime(date('Y-m-d'))-strtotime(SERVER_ONLINE_DATE))/86400+1;

$sqlRole = " select count(`id`) as roleCnt , max(`level`) as maxLevel from PLAYER_TBL WHERE `id`>0";
$rsRole  = GFetchRowOne($sqlRole);
$summary['totalRole'] = $rsRole['roleCnt'];
$summary['maxRoleLevel'] = $rsRole['maxLevel'];

$sqlAccount = "  SELECT COUNT(DISTINCT a.`accountName`) AS totalAccount  FROM t_log_access a";
$rsAccount = fetchRowOne($sqlAccount);
$sqlMission = "  SELECT  COUNT(DISTINCT m.`roleId`) AS totalFirstMission FROM t_log_first_mission m";
$rsMission  = fetchRowOne($sqlMission);

$summary['totalAccount'] = $rsAccount['totalAccount'];
$summary['totalLost'] =  $rsAccount['totalAccount'] > 0  && $rsAccount['totalAccount'] >  $rsMission['totalFirstMission'] ?  round(($rsAccount['totalAccount']-$rsMission['totalFirstMission'])*100/$rsAccount['totalAccount'], 2) : 0;

$sqlTotalPay = " SELECT COUNT(DISTINCT `roleId`) AS totalPayRole, SUM(payMoney) AS totalPay,  MAX(payMoney) AS maxPay FROM t_log_pay ";
$rsTotalPay = fetchRowOne($sqlTotalPay);
$summary['totalPay'] = $rsTotalPay['totalPay'];
$summary['totalPayRole'] = $rsTotalPay['totalPayRole'];
$summary['maxTotalPay'] = $rsTotalPay['maxPay'];
$summary['totalAvgArpu'] = $rsTotalPay['totalPayRole'] > 0 ? round($rsTotalPay['totalPay']/$rsTotalPay['totalPayRole'],2) :0;

$sqlMaxOnline = "SELECT MAX(`online`) AS maxOnline FROM t_log_online";
$rsMaxOnline = fetchRowOne($sqlMaxOnline);
$sqlAvgOnline = "SELECT AVG(`online`) AS avgOnline FROM t_log_online WHERE mHour >= 8 AND mHour <= 23";
$rsAvgOnline = fetchRowOne($sqlAvgOnline);
$summary['totalMaxOnline'] = $rsMaxOnline['maxOnline'];
$summary['totalAvgOnline'] = round($rsAvgOnline['avgOnline']);


$diffDay = ($dateEndStamp - $dateStartStamp)/86400;

$result = array();
for ($i=0; $i<=$diffDay; $i++){
	$dateTime = $dateStartStamp + $i*86400;
	$result[$dateTime]['date'] = date('Y.m.d',$dateTime);
	$result[$dateTime]['week'] = date('w',$dateTime);
	$result[$dateTime]['online'] = 0;
	$result[$dateTime]['totalPay'] = 0;
}

$sqlOnline = " SELECT MAX(`online`) AS online, mDateTime FROM t_log_online WHERE mDateTime BETWEEN {$dateStartStamp} AND {$dateEndStamp} GROUP BY mDateTime";
$sqlPay    = " SELECT COUNT(DISTINCT `roleId`) as roleCnt, SUM(payMoney) AS totalPay, mDateTime FROM t_log_pay  WHERE mDateTime BETWEEN {$dateStartStamp} AND {$dateEndStamp} GROUP BY mDateTime";
$rsOnline = fetchRowSet($sqlOnline);
$rsPay = fetchRowSet($sqlPay);
$maxOnline = 0;
$maxPay = 0;
$totalPay = 0;
foreach ($rsOnline as $row) {
	$result[$row['mDateTime']]['online'] = $row['online']; 
	if ($row['online']>$maxOnline) {
		$maxOnline =  $row['online'];
	}
}
foreach ($rsPay as $row) {
	$result[$row['mDateTime']]['totalPay'] = $row['totalPay']; 
	if ($row['totalPay']>$maxPay) {
		$maxPay =  $row['totalPay'];
	}
	$totalPay+=$row['totalPay'];
}

$data = array(
	'dateStart' => &$dateStart,
	'dateEnd' => &$dateEnd,
	'prevDate' =>date('Y-m-d', $dateStartStamp-86400),
	'nextDate' =>date('Y-m-d', $dateStartStamp+86400),
	'serverOnlineDate' =>SERVER_ONLINE_DATE,
	'today' =>date('Y-m-d'),
	'summary' => &$summary,
	'result' => &$result,
	'maxOnline' => &$maxOnline,
	'maxPay' => &$maxPay,
	'totalPay' => &$totalPay,
);

$resultAry = array("result"=>1, "errMsg"=>"", "data"=>$data );
echo json_encode( $resultAry );