<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Jan 31 06:23:56 GMT 2012
 * @desc 用于同步充值日志到中央后台。
 */
include_once '../../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global_for_central_api.php';

$data = 'ok';
dieJsonMsg(1,'',$data);
