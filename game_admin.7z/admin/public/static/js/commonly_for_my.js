/*!
 * My ui 
 * @desc this js is commonly used of javascript func for myself
 * @author viticm<duchuan@gmail.com>
 * @date 2013-4-23
 */
/**
 * @desc 通过名称获得复选框值数组
 * @param string cCheckBoxName
 * @returns array
 */
function getCheckBoxByName( cCheckBoxName )
{
    var Arr_CheckBoxVal = [];
    $( "input[name='"+cCheckBoxName+"']:checked" ).each(function(index, element) {
        Arr_CheckBoxVal.push( $(this).val() )
    });
    return Arr_CheckBoxVal;
}

/**
 * @desc 通用小提示
 * @param string cType
 * @param string cContent
 * @returns array
 */
function showTips( cType, cContent )
{
    cTipHtml = '';
    cColor = 'error' == cType ? 'red' : 'green';
    cTipHtml = '<span style="color:'+cColor+';">'+cContent+'</span>';
    $( '#tips' ).html( cTipHtml );
}

/** 记住javscript中的数字和字符串的比较 **/
Array.prototype.max = function() 
{   
    var max = parseInt( this[ 0 ] );   
    var len = this.length;
    var maxIndex = 0;
    if ( 0 == len ) return undefined;
    for (var i = 1; i < len; i++)
    {  
    	var nowVal = parseInt( this[ i ] );
    	if( max < nowVal )
        {
    		max = nowVal;
    		maxIndex = i;
    	}
    }
    return maxIndex;   
}

/**
 * @desc get ajax return
 * @param string cRequestMethod http request method( POST OR GET )
 * @param string cRequestUrl get url
 * @param string cSendData the url param string
 * @returns bool|Object
 */
function getAjaxRequest( cRequestMethod, cRequestUrl, cSendData )
{
    var iHttpRequestStatus = 0;
    var OBJ_RequestJson = null;
    $.ajax({
            type: cRequestMethod,
            url: cRequestUrl,
            data: cSendData,
            async: false,
            success: function( data )
            {
                OBJ_RequestJson = $.parseJSON( data );
            },
            error: function( OBJ_XMLHttpRequest )
            {
                iHttpRequestStatus = OBJ_XMLHttpRequest.status;
            }
    });
    if( 0 !== iHttpRequestStatus ) showTips( 'error', 'Request failed, Error code: ' +iHttpRequestStatus );
    // ErrorCode is a compatible variable just for mine, you can del it.
    if( null !== OBJ_RequestJson && 'undefined' !== typeof OBJ_RequestJson.ErrorCode && 1 != OBJ_RequestJson.ErrorCode )
    	showTips( 'error', 'Url request have some error, Error desc: ' +decodeURIComponent( OBJ_RequestJson.ErrorDesc ) );
    return 0 !== iHttpRequestStatus || ( 'undefined' !== typeof OBJ_RequestJson.ErrorCode && 1 != OBJ_RequestJson.ErrorCode )
        ? false : OBJ_RequestJson;
}