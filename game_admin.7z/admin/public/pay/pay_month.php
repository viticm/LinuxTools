<?php

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStart = $dateStartStamp ? date('Y-m',$dateStartStamp) : date('Y-m',strtotime(SERVER_ONLINE_DATE));
$dateEnd = $dateEndStamp ? date('Y-m',$dateEndStamp) : date('Y-m');
$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);
$end = date('t', $dateEndStamp);
$dateEndStamp = strtotime($dateEnd.'-'.$end);

$diffMonth = (date('Y',$dateEndStamp)-date('Y',$dateStartStamp))*12 + date('m',$dateEndStamp)-date('m',$dateStartStamp);
if ($diffDay >= 0) {
	$sql = " SELECT CONCAT(`mYear`,'.',`mMonth`) AS `month`, SUM(payMoney) AS `money`,  SUM(payGold) AS `gold`, 
				    COUNT(*) AS `times`, COUNT(DISTINCT `roleId`) AS `roles` 
		     FROM t_log_pay WHERE mDateTime >= {$dateStartStamp} AND mDateTime <= {$dateEndStamp} GROUP BY mYear, mMonth order by mYear,mMonth ";
	$result = fetchRowSet($sql);
}

$maxMoney = 0;
$maxGold = 0;
$maxRoleCnt = 0;
$maxTimes = 0;
$maxArpu = 0;
$allTotalMoney = 0;
$allTotalGold = 0;
$avgMoney = 0;
$avgGold = 0;
$payMonths = array();
if (is_array($result)) {
	foreach ($result as $key => $row) {
		$allTotalMoney += $row['money'];
		$allTotalGold += $row['gold'];
		$payMonths[$row['month']]['money'] = round($row['money'],1);
		$payMonths[$row['month']]['gold']  = $row['gold'];
		$payMonths[$row['month']]['times'] = $row['times'];
		$payMonths[$row['month']]['roles'] = $row['roles'];
		$payMonths[$row['month']]['arpu']  = $row['roles'] > 0 ? round($row['money']/$row['roles'],1) : 0;
		$maxMoney = $row['money'] > $maxMoney ? $row['money'] : $maxMoney;
		$maxGold  = $row['gold']  > $maxGold  ? $row['gold']  : $maxGold;
		$maxRoleCnt = $row['roles'] > $maxRoleCnt ? $row['roles'] : $maxRoleCnt;
		$maxTimes = $row['times'] > $maxTimes ? $row['times'] : $maxTimes;
		$maxArpu = $payMonths[$row['month']]['arpu'] > $maxArpu ? $payMonths[$row['month']]['arpu'] : $maxArpu;
		$payMonths[$row['month']]['tip'] = "金额：{$row['money']}；元宝：{$row['gold']}；人次：{$row['times']}；人数：{$row['roles']}；ARPU：{$payMonths[$row['month']]['arpu']}";
	}
}
$avgMoney = $diffMonth > 0 ? round($allTotalMoney/$diffMonth,1) : 0;
$avgGold = $diffMonth > 0 ? round($allTotalGold/$diffMonth,1) : 0;

$arrShowType = array(9=>'全部',1=>'金额',2=>'人数',3=>'人次',4=>'ARPU值',5=>'充值所得元宝');
$showType = intval($_POST['showType']) ? intval($_POST['showType'])  : 1 ;
$data = array(
	'payMonths' => $payMonths,
	'maxMoney'=>$maxMoney,
	'maxGold'=>$maxGold,
	'maxRoleCnt' => $maxRoleCnt,
	'maxTimes' => $maxTimes,
	'maxArpu'=>$maxArpu,
	'allTotalMoney'=>round($allTotalMoney,1),
	'allTotalGold'=>$allTotalGold,
	'avgMoney' => $avgMoney,
	'avgGold' => $avgGold,
	'dateStart' => $dateStart,
	'dateEnd' => $dateEnd,
	'showType'=>$showType,
	'arrShowType'=>$arrShowType,
	'dateToday'=>date('Y-m'),
	'datePrev'=>date('Y-m',strtotime('-1month',$dateStartStamp)),
	'dateNext'=>date('Y-m',strtotime('+1month',$dateStartStamp)),
	'dateOnline'=>date('Y-m',strtotime(SERVER_ONLINE_DATE)),
);
//echo '<pre>';print_r($data);die();
render("pay/pay_month.tpl",$data);



