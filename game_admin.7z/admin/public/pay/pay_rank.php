<?php
/**
 * @author linruirong@4399.com
 * @Created  Wed Dec 14 01:57:13 GMT 2011
 * @desc 玩家充值排行
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';

$rowPerPage = intval($_POST['rowPerPage']);
$rowPerPage = $rowPerPage ? $rowPerPage : LIST_PER_PAGE_RECORDS;
$page = intval($_POST['page']);
$page = $page > 0 ? $page : 1;

//===============start 查角色==============//
$role = $_POST['role'];
$msg = array();
if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	if (!$role['roleId']) {
		$msg[] = '找不到对应玩家';
	}
}
//===============end 查角色===============//

$where .= $role['roleId'] ? " where roleId = {$role['roleId']} ":'';

//===========查出记录数=======
$sqlCnt = " select count(distinct roleId) as cnt from t_log_pay {$where} ";
$rsCnt = fetchRowOne($sqlCnt);
$rowCount = $rsCnt['cnt'];
//===========================

$offset = ($page-1) * $rowPerPage;//每页开始位置
$pageCount =  ceil($rowCount/$rowPerPage);
$pageList = getPages($page, $rowCount, $rowPerPage);

//===========查出符合条件的数据=======
$sql = " SELECT roleId, COUNT(*) AS times , SUM(payMoney) AS totalPay, MAX(payMoney) AS maxPay, MIN(payMoney) AS minPay,
                AVG(payMoney) AS avgPay, MIN(mTime) AS minPayTime, MAX(mTime) AS maxPayTime
         FROM t_log_pay  {$where} GROUP BY roleId ORDER BY totalPay DESC limit  {$offset} , {$rowPerPage}  ";
$rs = fetchRowSet($sql);
//=================================
$result = array();
$roleIds = array();
foreach ($rs as $i => &$row) {
	$row['minPayTime'] = date('Y-m-d H:i:s',$row['minPayTime']);
	$row['maxPayTime'] = date('Y-m-d H:i:s',$row['maxPayTime']);
	$row['totalPay'] = round($row['totalPay'],1);
	$row['maxPay'] = round($row['maxPay'],1);
	$row['minPay'] = round($row['minPay'],1);
	$row['avgPay'] = round($row['avgPay'],1);
	$result[$row['roleId']] = $row;
	$result[$row['roleId']]['rankNum'] = $offset+1+$i;
	array_push($roleIds,$row['roleId']);
}
//===========查出玩家信息=========
$strIds = implode(',', $roleIds);
if ($strIds) {
	$sql = " SELECT `id` AS roleId, `name` AS roleName, `account` AS accountName, `level` AS roleLevel, gold, last_login_time AS lastLoginTime
		 	 FROM PLAYER_TBL WHERE `id` IN ({$strIds}) ";
	$palyer = GFetchRowSet($sql);	
	
	$sqlArena = " select id,rank from ATHLETIC_TBL WHERE `id` IN ({$strIds}) ";
	$rsArena  = GFetchRowSet($sqlArena);
	
	foreach ($palyer as &$p) {
		$result[$p['roleId']]['roleName'] = $p['roleName'];
		$result[$p['roleId']]['accountName'] = $p['accountName'];
		$result[$p['roleId']]['roleLevel'] = $p['roleLevel'];
		$result[$p['roleId']]['gold'] = $p['gold'];
		$result[$p['roleId']]['lastLoginTime'] = date('Y-m-d H:i:s', $p['lastLoginTime']);
		$result[$p['roleId']]['diffDay'] = floor( (time()-$p['lastLoginTime'])/86400);
	}
	foreach ($rsArena as &$a) {
		$result[$a['id']]['rank'] = $a['rank'];
	}
}
//echo '<pre>';
//print_r($result);
//echo '</pre>';
//==================================
$data = array(
	'dateStart'=>&$dateStart,
	'dateEnd'=>&$dateEnd,
	'rowPerPage'=>&$rowPerPage,
	'rowCount'=>&$rowCount,
	'page'=>&$page,
	'pageCount'=>&$pageCount,
	'pageList'=>&$pageList,
	'role' => &$role,
	'result' => &$result,
	'msg' => empty($msg) ? '' : implode('<br>',$msg),
);
render('pay/pay_rank.tpl',&$data);