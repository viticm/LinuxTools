<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Dec 13 05:58:41 GMT 2011
 * @desc 按天充值统计
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStart = $dateStartStamp ? date('Y-m-d',$dateStartStamp) : date('Y-m-d',strtotime('-1 month'));
$dateEnd = $dateEndStamp ? date('Y-m-d',$dateEndStamp) : date('Y-m-d');
$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);
$diffDay = ($dateEndStamp - $dateStartStamp)/86400;

$maxMoney   = 0;
$maxTimes   = 0;
$maxRoleCnt = 0 ;
$maxArpu    = 0 ;

$strDate = '';
$strMoney = '';
$strTimes = '';
$strRoleCnt = '';
$strArpu = '';
if ($diffDay >= 0) {
	$sql = " SELECT mDateTime, SUM(payMoney) AS payMoney, COUNT(*) AS `times`, COUNT(distinct `roleId`) AS `roles`  FROM t_log_pay WHERE mDateTime >= {$dateStartStamp} AND  mDateTime <= {$dateEndStamp} GROUP BY mDateTime ";
	$rs = fetchRowSet($sql);
	for ($i=0; $i<=$diffDay; $i++){
		$time = $dateStartStamp + $i*86400;
		$strDate .= '"'.date('Y-m-d', $time).'",';
		$exist = false;
		foreach ($rs as $k => $v) {
			if ($v['mDateTime'] == $time) {
				$strMoney .= round($v['payMoney'],1).',';
				$strTimes .= $v['times'].',';
				$strRoleCnt .=  $v['roles'].',';
				$strArpu .=  $v['roles']>0 ? round($v['payMoney']/$v['roles'],1).',' : '0,';
				$exist = true;
				unset($rs[$k]);
			}
		}
		if (!$exist) {
			$strMoney .= '0,';
			$strTimes .= '0,';
			$strRoleCnt .= '0,';
			$strArpu .= '0,';
		}
	}
}
$strDate = trim($strDate,',');
$strMoney = trim($strMoney,',');
$strTimes = trim($strTimes,',');
$strRoleCnt = trim($strRoleCnt,',');
$strArpu = trim($strArpu,',');
$data = array(
	'strDate' => &$strDate,
	'strMoney' => &$strMoney,
	'strTimes' => &$strTimes,
	'strRoleCnt' => &$strRoleCnt,
	'strArpu' => &$strArpu,
	'dateStart' => $dateStart,
	'dateEnd' => $dateEnd,
);
render('pay/pay_day.tpl',$data);