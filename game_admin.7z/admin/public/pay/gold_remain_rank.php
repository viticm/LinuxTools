<?php
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$bindType = intval($_POST['bindType']);
$bindType = $bindType ? $bindType  : 1; //默认查不绑定的.
$rowPerPage = intval($_POST['record']);

$table = 'PLAYER_TBL';
if (1==$bindType) {
	$orderBy = " ORDER BY gold DESC ";
	$where = " gold > 0 ";
}elseif (2==$bindType) {
	$orderBy = " ORDER BY bind_gold DESC ";
	$where = " bind_gold > 0 ";
}else {
	$orderBy = " ORDER BY totalGold DESC ";
	$where = " (gold+bind_gold) > 0 ";
}

//===========查出记录数=======
$sqlCnt = " SELECT count(id) as cnt FROM {$table} where {$where} ";
$rsCnt = GFetchRowOne($sqlCnt);
$rowCount = $rsCnt['cnt'];
//===========================

$rowPerPage = intval($_POST['rowPerPage']);
$rowPerPage = $rowPerPage ? $rowPerPage : LIST_PER_PAGE_RECORDS;
$page = intval($_POST['page']);
$page = $page > 0 ? $page : 1;
$offset = ($page-1) * $rowPerPage;//每页开始位置
$pageCount =  ceil($rowCount/$rowPerPage);
$pageList = getPages($page, $rowCount, $rowPerPage);



$sql = " SELECT id,account,name, bind_gold as bindGold, gold, (bind_gold+gold) as totalGold, last_login_time FROM {$table} where {$where} {$orderBy} limit {$offset}, {$rowPerPage} ";
$rs = GFetchRowSet($sql);
$datetime = strtotime(date('Y-m-d',time()));
foreach ($rs as $key => &$row) {
	$row['rank'] = ($page-1)*$rowPerPage + $key +1; 
	$row['days'] = ($datetime-strtotime(date('Y-m-d',$row['last_login_time'])))/86400;
}
$arrBindAttr = array(
	1=>'按不绑定元宝数',
	2=>'按绑定元宝数',
	3=>'按全部元宝数',
);

$data = array(
    'arrBindAttr'=>$arrBindAttr,
    'bindType'=>$bindType,
    'rs'=>$rs,
	'rowPerPage'=>&$rowPerPage,
	'rowCount'=>&$rowCount,
	'page'=>&$page,
	'pageCount'=>&$pageCount,
	'pageList'=>&$pageList,
);
render('pay/gold_remain_rank.tpl', $data);