<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Nov 07 07:10:47 GMT 2011
 * @desc 玩家退出日志
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStart = $dateStartStamp ? date('Y-m-d',$dateStartStamp) : date('Y-m-d',strtotime('-6day'));
$dateEnd = $dateEndStamp ? date('Y-m-d',$dateEndStamp) : date('Y-m-d');
$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd)+86399;
$accountName = SS($_POST['accountName']);

$rowPerPage = intval($_POST['rowPerPage']);
$rowPerPage = $rowPerPage ? $rowPerPage : LIST_PER_PAGE_RECORDS;
$page = intval($_POST['page']);
$page = $page > 0 ? $page : 1;

$where = " where `mTime`>={$dateStartStamp} and `mTime` <= {$dateEndStamp} ";
$where .= $accountName ? " and payToUser = '{$accountName}' ":'';

//===========查出记录数=======
$sqlCnt = " select count(*) as cnt from t_log_pay_request {$where} ";
$rsCnt = fetchRowOne($sqlCnt);
$rowCount = $rsCnt['cnt'];
//===========================

$offset = ($page-1) * $rowPerPage;//每页开始位置
$pageCount =  ceil($rowCount/$rowPerPage);
$pageList = getPages($page, $rowCount, $rowPerPage);

//===========查出符合条件的数据=======
$sql = " select * from t_log_pay_request {$where} limit  {$offset} , {$rowPerPage} ";
$rs = fetchRowSet($sql);
//=================================

$data = array(
	'dateStart'=>&$dateStart,
	'dateEnd'=>&$dateEnd,
	'rowPerPage'=>&$rowPerPage,
	'rowCount'=>&$rowCount,
	'page'=>&$page,
	'pageCount'=>&$pageCount,
	'pageList'=>&$pageList,
	'accountName' => &$accountName,
	'rs' => &$rs,
	'msg' => empty($msg) ? '' : implode('<br>',$msg),
);
render('pay/pay_request.tpl',&$data);