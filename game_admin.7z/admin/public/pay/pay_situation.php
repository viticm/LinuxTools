<?php
/**
 * game admin website
 * @desc this file is amount the pay money
 * @link duchuanpd@gmail.com
 * @copyright Copyright (c) 2012-2013 Gzpd.(www.gzpindian.com)
 * @license none
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
$iServerOnlineTime = strtotime(SERVER_ONLINE_DATE);
$iTodayTimestamp = strtotime( date( 'Y-m-d' ) );
$iTmpStartTime = strtotime($_POST['dateStart']);
$iTmpEndTime = strtotime($_POST['dateEnd']);
$iStartTime = $iTmpStartTime ? $iTmpStartTime  : strtotime(date('Y-m-d',strtotime('-7day')));
$iStartTime = $iStartTime <= $iServerOnlineTime ? $iServerOnlineTime : $iStartTime;
$iEndTime = !$iTmpEndTime || $iTmpEndTime > $iTodayTimestamp ? $iTodayTimestamp : $iTmpEndTime;
$cDateStart = date( 'Y-m-d', $iStartTime );
$cDateEnd = date( 'Y-m-d', $iEndTime );
$iOneDaySeconds = 24 * 60 * 60;

// get the pay rate
$timestamp = time();
$key = md5($timestamp.GAME3W_AUTH_KEY);
// get appserver conf enter url
define('GAMER_SERVER_GET_CLIENT_CONF_URL', GAME3W_URL.'api/get_server_conf.php'); 
$params = "?timestamp={$timestamp}&key={$key}&gamenum=".GAME_NO."&servernum=".SERVER_NAME;
$getJsonClientConf = @file_get_contents(GAMER_SERVER_GET_CLIENT_CONF_URL.$params);
$result = json_decode($getJsonClientConf,true);
$Arr_AppserverConf = array();
$Arr_AppserverConf = $result[ 'data' ];
$iPayRate = $Arr_AppserverConf[ 'PAY_RATE' ] ? $Arr_AppserverConf[ 'PAY_RATE' ] : 10;


$cSqlStr = '';
$cSqlStr .= 'SELECT DISTINCT `roleId`, sum( `payMoney` ) AS `payMoney`, `mDateTime` FROM `t_log_pay`';
$cSqlStr .= ' WHERE `mDateTime` >= '.$iStartTime. ' AND `mDateTime` <= '.$iEndTime;
$cSqlStr .= ' GROUP BY `mDateTime`, `roleId` ORDER BY `mDateTime` ASC';
$Arr_Pay = array();
$Arr_Pay = fetchRowSet( $cSqlStr );

$cSqlStr = '';
$cSqlStr .= 'SELECT DISTINCT `roleId`, `mDateTime` FROM `t_log_register`';
$cSqlStr .= ' WHERE `mDateTime` >= '.$iStartTime. ' AND `mDateTime` <= '.$iEndTime;
$cSqlStr .= ' GROUP BY `mDateTime`, `roleId` ORDER BY `mDateTime` ASC';
$Arr_NewRegister = array();
$Arr_NewRegister = fetchRowSet( $cSqlStr );

//find all login count user in the interval date
$cSqlStr = '';
$cSqlStr .= 'SELECT DISTINCT `roleId`, `loginDate`  from `t_log_logout`';
$cSqlStr .= ' where `loginDate` >= '.$iStartTime.' and `loginDate` <= '.$iEndTime;
$cSqlStr .= ' GROUP BY `loginDate`,`roleId` ORDER BY `loginDate` ASC';
$Arr_Login = fetchRowSet( $cSqlStr );

// get the new pay list by pay date time
$Arr_PayList = array();
$Arr_PayIdList = array();
$iPayTime = $iStartTime;
$Arr_LoginIdList = array();
$Arr_NewRegisterIdList = array();

while( $iPayTime <= $iEndTime )
{
	$Arr_PayList[ $iPayTime ] = array();
    $Arr_PayIdList[ $iPayTime ] = array();
	$Arr_PlayerPay = array();
	$Arr_NewRegisterIdList[ $iPayTime ] = array();
	$Arr_LoginIdList[ $iPayTime ] = array();
	
	foreach ( $Arr_Pay as $key => $value )
	{
		if( $iPayTime == $value[ 'mDateTime' ] )
		{
			$Arr_PlayerPay[ 'roleId' ] = $value[ 'roleId' ];
			$Arr_PlayerPay[ 'payMoney' ] = $value[ 'payMoney' ];  
			array_push( $Arr_PayList[ $iPayTime ], $Arr_PlayerPay );
			array_push( $Arr_PayIdList[ $iPayTime ], $value[ 'roleId' ] );
		}
	}
	foreach ( $Arr_NewRegister as $key => $value )
	{
		if( $iPayTime == $value[ 'mDateTime' ] )
		{
			array_push( $Arr_NewRegisterIdList[ $iPayTime ], $value[ 'roleId' ] );
		}
	}
	foreach ( $Arr_Login as $key => $value )
	{
		if( $iPayTime == $value[ 'loginDate' ] )
		{
			array_push( $Arr_LoginIdList[ $iPayTime ], $value[ 'roleId' ] );
		}
	}
	$iPayTime += $iOneDaySeconds;
}

$iPayTime = $iStartTime;
// get the pay situation
$Arr_PaySutiation = array();
while ( $iPayTime <= $iEndTime )
{
    $Arr_Pay = array();
    $Arr_NewPayIdList = array();
    $Arr_PaySutiation[ $iPayTime ] = array();
    $Arr_PaySutiation[ $iPayTime ][ 'totalPayMoney' ] = 0;
    $Arr_PaySutiation[ $iPayTime ][ 'totalPayPeople' ] = 0;
    $Arr_PaySutiation[ $iPayTime ][ 'arpu' ] = 0;
    $Arr_PaySutiation[ $iPayTime ][ 'totalGold' ] = 0;    
    $Arr_PaySutiation[ $iPayTime ][ 'conversionRate' ] = 0;
    $Arr_PaySutiation[ $iPayTime ][ 'totalNewPlayerPayMoney' ] = 0;
    $Arr_PaySutiation[ $iPayTime ][ 'totalNewPlayerPayPeople' ] = 0;
    $Arr_PaySutiation[ $iPayTime ][ 'newPlayerArpu' ] = 0;
    $Arr_PaySutiation[ $iPayTime ][ 'newPlayerPayMoneyProportion' ] = 0;
    $Arr_PaySutiation[ $iPayTime ][ 'newPlayerPayPeopleProportion' ] = 0;
    $Arr_PaySutiation[ $iPayTime ][ 'totalNewPlayerCount' ] = 0;
    $Arr_PaySutiation[ $iPayTime ][ 'totalLoginCount' ] = 0;
    $Arr_Pay = $Arr_PayList[ $iPayTime ];
    
    if ( is_array( $Arr_NewRegisterIdList[ $iPayTime ] ) && is_array( $Arr_PayIdList[ $iPayTime ] ) )
        $Arr_NewPayIdList = array_intersect( $Arr_NewRegisterIdList[ $iPayTime ], $Arr_PayIdList[ $iPayTime ] );
    foreach ( $Arr_Pay as $key => $value )
    {
    	$Arr_PaySutiation[ $iPayTime ][ 'totalPayMoney' ] += $value[ 'payMoney' ];
    	if( true == in_array( $value[ 'roleId' ], $Arr_NewPayIdList ) )
    	{
    		$Arr_PaySutiation[ $iPayTime ][ 'totalNewPlayerPayMoney' ] += $value[ 'payMoney' ];
    	}
    }
    $iTotalLoginCount = count( $Arr_LoginIdList[ $iPayTime ] );
    $iTotalPayPeople = count( $Arr_PayIdList[ $iPayTime ] );
    $iConversionRate = 0 == $iTotalLoginCount ? 0 : $iTotalPayPeople / $iTotalLoginCount;
    $Arr_PaySutiation[ $iPayTime ][ 'conversionRate' ] = $iConversionRate * 100;
    $iTotalGold = $Arr_PaySutiation[ $iPayTime ][ 'totalPayMoney' ] * $iPayRate;
    $Arr_PaySutiation[ $iPayTime ][ 'totalGold' ] = $iTotalGold;
    $iTotalNewPlayerPayPeople = count( $Arr_NewPayIdList );
    $Arr_PaySutiation[ $iPayTime ][ 'totalPayPeople' ] = $iTotalPayPeople;
    $fArpu = 0 == $iTotalPayPeople ? 0 : $Arr_PaySutiation[ $iPayTime ][ 'totalPayMoney' ] / $iTotalPayPeople;
    $Arr_PaySutiation[ $iPayTime ][ 'arpu' ] = $fArpu;
    $iNewPlayerArpu = 0 == $iTotalNewPlayerPayPeople ? 0 :
        $Arr_PaySutiation[ $iPayTime ][ 'totalNewPlayerPayMoney' ] / $iTotalNewPlayerPayPeople;
    $Arr_PaySutiation[ $iPayTime ][ 'totalNewPlayerPayPeople' ] = $iTotalNewPlayerPayPeople;
    $Arr_PaySutiation[ $iPayTime ][ 'newPlayerArpu' ] = $iNewPlayerArpu;
    $fNewPlayerPayMoneyProportion = $Arr_PaySutiation[ $iPayTime ][ 'totalPayMoney' ] == 0 ?
        0 : $Arr_PaySutiation[ $iPayTime ][ 'totalNewPlayerPayMoney' ] / $Arr_PaySutiation[ $iPayTime ][ 'totalPayMoney' ];
    $Arr_PaySutiation[ $iPayTime ][ 'newPlayerPayMoneyProportion' ]= $fNewPlayerPayMoneyProportion * 100;
    $fNewPlayerPayPeopleProportion = 0 == $iTotalPayPeople ? 0 : $iTotalNewPlayerPayPeople / $iTotalPayPeople;
    $Arr_PaySutiation[ $iPayTime ][ 'newPlayerPayPeopleProportion' ] = $fNewPlayerPayPeopleProportion * 100;
    $Arr_PaySutiation[ $iPayTime ][ 'totalNewPlayerCount' ] = count( $Arr_NewRegisterIdList[ $iPayTime ] );
    $Arr_PaySutiation[ $iPayTime ][ 'totalLoginCount' ] = $iTotalLoginCount;
    
    $iPayTime += $iOneDaySeconds;
}
$iPayTime = $iStartTime;
// get the pay situation amount
$Arr_PaySutiationAmount = array();
$Arr_PaySutiationAmount[ 'totalPayMoney' ] = 0;
$Arr_PaySutiationAmount[ 'totalPayPeople' ] = 0;
$Arr_PaySutiationAmount[ 'totalArpu' ] = 0;
$Arr_PaySutiationAmount[ 'totalGold' ] = 0;
$Arr_PaySutiationAmount[ 'totalNewPlayerPayMoney' ] = 0;
$Arr_PaySutiationAmount[ 'totalNewPlayerPayPeople' ] = 0;
$Arr_PaySutiationAmount[ 'totalNewPlayerArpu' ] = 0;
$Arr_PaySutiationAmount[ 'totalNewPlayerCount' ] = 0;
$Arr_PaySutiationAmount[ 'totalLoginCount' ] = 0;
while ( $iPayTime <= $iEndTime )
{
	$Arr_PaySutiationAmount[ 'totalPayMoney' ] += $Arr_PaySutiation[ $iPayTime ][ 'totalPayMoney' ];
	$Arr_PaySutiationAmount[ 'totalPayPeople' ] += $Arr_PaySutiation[ $iPayTime ][ 'totalPayPeople' ];
	$Arr_PaySutiationAmount[ 'totalGold' ] += $Arr_PaySutiation[ $iPayTime ][ 'totalGold' ];
	$Arr_PaySutiationAmount[ 'totalNewPlayerPayMoney' ] += $Arr_PaySutiation[ $iPayTime ][ 'totalNewPlayerPayMoney' ];
	$Arr_PaySutiationAmount[ 'totalNewPlayerPayPeople' ] += $Arr_PaySutiation[ $iPayTime ][ 'totalNewPlayerPayPeople' ];
	$Arr_PaySutiationAmount[ 'totalNewPlayerCount' ] += $Arr_PaySutiation[ $iPayTime ][ 'totalNewPlayerCount' ];
	$Arr_PaySutiationAmount[ 'totalLoginCount' ] += $Arr_PaySutiation[ $iPayTime ][ 'totalLoginCount' ];
	$iPayTime += $iOneDaySeconds;
}
$Arr_PaySutiationAmount[ 'totalArpu' ] = 0 == $Arr_PaySutiationAmount[ 'totalPayPeople' ] ? 0 :
    $Arr_PaySutiationAmount[ 'totalPayMoney' ] / $Arr_PaySutiationAmount[ 'totalPayPeople' ];
$Arr_PaySutiationAmount[ 'totalNewPlayerArpu' ] = 0 == $Arr_PaySutiationAmount[ 'totalNewPlayerPayPeople' ] ? 0 :
    $Arr_PaySutiationAmount[ 'totalNewPlayerPayMoney' ] / $Arr_PaySutiationAmount[ 'totalNewPlayerPayPeople' ];
$data = array(
	'dateStart'=>$cDateStart,
	'dateEnd'=>$cDateEnd,
    'Arr_PaySutiation' => $Arr_PaySutiation,
    'Arr_PaySutiationAmount' => $Arr_PaySutiationAmount,
);

render('pay/pay_situation.tpl', $data);