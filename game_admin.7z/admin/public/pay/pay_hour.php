<?php
/**
 * 分时统计充值情况
 * @author linruirong@4399.com
 *
 */

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';


$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStartStamp = $dateStartStamp ? $dateStartStamp : strtotime(date('Y-m-d',strtotime('-6day')));
$dateEndStamp = $dateEndStamp ? $dateEndStamp : strtotime(date('Y-m-d'));

$viewType = intval($_POST['viewType']) ? intval($_POST['viewType']) : 1 ; //默认显示综合统计图
$dateStart = date('Y-m-d',$dateStartStamp);
$dateEnd =  date('Y-m-d',$dateEndStamp);

$diffDay = abs($dateStartStamp - $dateEndStamp)/86400 + 1 ;

//======== 查结果 =====
if (1==$viewType) { //查多天，只计算综合结果
	$sqlSumHour = " SELECT SUM(`payMoney`) AS totalMoney, COUNT(DISTINCT `roleId`) AS totalPerson,
					COUNT(`roleId`) AS totalPersonTime,`mHour`
					FROM t_log_pay
					WHERE `mDateTime` BETWEEN {$dateStartStamp} AND {$dateEndStamp}
					GROUP BY `mHour`
					ORDER BY `mHour` ASC ";
	$resultSumHour = fetchRowSet($sqlSumHour);

	$showType = intval($_POST['showType']) ? intval($_POST['showType']) : 1 ;
	$maxSumMoney = 0;
	$maxSumPerson = 0;
	$maxSumPersonTime = 0;
	$maxSumArpu = 0;
	$allSumTotalMoney = 0;
	$paySumHours = array();
	if (is_array($resultSumHour) && !empty($resultSumHour)) {
		for ($hour=0; $hour <= 23 ; $hour++){
			$existSum = false;
			foreach ($resultSumHour as $key => $row) {
				if ($row['mHour'] == $hour) {
					$maxSumMoney = $row['totalMoney'] > $maxSumMoney ? $row['totalMoney'] : $maxSumMoney;
					$maxSumPerson = $row['totalPerson'] > $maxSumPerson ? $row['totalPerson'] : $maxSumPerson;
					$maxSumPersonTime = $row['totalPersonTime'] > $maxSumPersonTime ? $row['totalPersonTime'] : $maxSumPersonTime;

					$allSumTotalMoney += $row['totalMoney'];
					$paySumHours[$hour]['totalMoney'] = round($row['totalMoney'],1);
					$paySumHours[$hour]['totalPerson'] = $row['totalPerson'];
					$paySumHours[$hour]['totalPersonTime'] = $row['totalPersonTime'];
					$existSum = true;
					unset($resultSumHour[$key]);
					break;
				}
			}
			if (!$existSum) {
				$paySumHours[$hour]['totalMoney'] = 0;
				$paySumHours[$hour]['totalPerson'] = 0;
				$paySumHours[$hour]['totalPersonTime'] = 0;
			}
			$paySumHours[$hour]['arpu'] = $paySumHours[$hour]['totalPerson'] > 0 ? round($paySumHours[$hour]['totalMoney']/$paySumHours[$hour]['totalPerson'],1) : 0 ;
			$paySumHours[$hour]['tip'] = "金额：{$paySumHours[$hour]['totalMoney']}，人数：{$paySumHours[$hour]['totalPerson']}，人次：{$paySumHours[$hour]['totalPersonTime']}，ARPU值：{$paySumHours[$hour]['arpu']}";
			$maxSumArpu = $paySumHours[$hour]['arpu'] > $maxSumArpu ? $paySumHours[$hour]['arpu'] : $maxSumArpu;
		}
	}
	$avgSumMoney = round($allSumTotalMoney/$diffDay/24, 2);

}else {
	$select = " SUM(`payMoney`) AS totalMoney , COUNT(DISTINCT `roleId`) AS totalPerson,
				COUNT(`roleId`) AS totalPersonTime,mDateTime,
				`mDateTime`,`mHour` ";

	$sql = " SELECT {$select}
			 FROM  t_log_pay
			 WHERE `mDateTime` BETWEEN {$dateStartStamp} AND {$dateEndStamp}
			 GROUP BY `mDateTime`,`mHour`
			 ORDER BY  `mDateTime`,`mHour` ";
	$result = fetchRowSet($sql);

	$maxMoney = 0;
	$maxPerson = 0;
	$maxPersonTime = 0;
	$maxArpu = 0;
	$allTotalMoney = 0;
	$showType = isset($_POST['showType']) ? intval($_POST['showType']) : 1 ; //默认显示“金额”视图
	$payHours = array();
	if (is_array($result) && !empty($result)) {
		$timeStamp =  $dateEndStamp >  $dateStartStamp ? $dateEndStamp : $dateStartStamp ;
		for ($day=0; $day < $diffDay; $day++){
			$date = strtotime("-{$day}day", $timeStamp);
			for ($hour=0; $hour <= 23 ; $hour++){
				$exist = false;
				foreach ($result as $key => $row) {
					if ($row['mDateTime']  == $date && $row['mHour'] == $hour) {
						$maxMoney = $row['totalMoney'] > $maxMoney ? $row['totalMoney'] : $maxMoney;
						$maxPerson = $row['totalPerson'] > $maxPerson ? $row['totalPerson'] : $maxPerson;
						$maxPersonTime = $row['totalPersonTime'] > $maxPersonTime ? $row['totalPersonTime'] : $maxPersonTime;

						$allTotalMoney += $row['totalMoney'];
						$payHours[$date][$hour]['totalMoney'] = round($row['totalMoney'],1);
						$payHours[$date][$hour]['totalPerson'] = $row['totalPerson'];
						$payHours[$date][$hour]['totalPersonTime'] = $row['totalPersonTime'];
						$exist = true;
						unset($result[$key]);
						break;
					}
				}
				if (!$exist) {
					$payHours[$date][$hour]['totalMoney'] = 0;
					$payHours[$date][$hour]['totalPerson'] = 0;
					$payHours[$date][$hour]['totalPersonTime'] = 0;
				}
				$payHours[$date][$hour]['arpu'] = $payHours[$date][$hour]['totalPerson'] > 0 ? round($payHours[$date][$hour]['totalMoney']/$payHours[$date][$hour]['totalPerson'],1) : 0 ;
				$payHours[$date][$hour]['tip'] = "金额：{$payHours[$date][$hour]['totalMoney']}，人数：{$payHours[$date][$hour]['totalPerson']}，人次：{$payHours[$date][$hour]['totalPersonTime']}，ARPU值：{$payHours[$date][$hour]['arpu']}";
				$maxArpu = $payHours[$date][$hour]['arpu'] > $maxArpu ? $payHours[$date][$hour]['arpu'] : $maxArpu;
			}
		}
	}
	$avgMoney = round($allTotalMoney/$diffDay/24, 2);
}


//======== end 查结果 =====

$arrShowType = array(9=>'全部',1=>'金额',2=>'人数',3=>'人次',4=>'ARPU值',);
$arrViewType = array(1=>'综合统计图',2=>'按天统计图');

$data = array(
	'payHours' => $payHours,
	'maxMoney' => round($maxMoney,1),
	'avgMoney' => $avgMoney,
	'allTotalMoney' => round($allTotalMoney,1),
	'maxMoney' => round($maxMoney,1),
	'maxPerson' => $maxPerson,
	'maxPersonTime' => $maxPersonTime,
	'maxArpu' => $maxArpu,

	'maxSumMoney' =>    round($maxSumMoney,1),
	'maxSumPerson' =>   $maxSumPerson,
	'maxSumPersonTime'=>$maxSumPersonTime,
	'maxSumArpu' =>     $maxSumArpu,
	'allSumTotalMoney'=>round($allSumTotalMoney,1),
	'paySumHours' =>    $paySumHours,
	'avgSumMoney' => $avgSumMoney,

	'dateStart' => $dateStart,
	'dateEnd' => $dateEnd,
	'showType'=>$showType,
	'arrShowType'=>$arrShowType,
	'viewType'=>$viewType,
	'arrViewType'=>$arrViewType,
	'dateToday'=>date('Y-m-d'),
	'datePrev'=>date('Y-m-d',strtotime('-1day',$dateStartStamp)),
	'dateNext'=>date('Y-m-d',strtotime('+1day',$dateStartStamp)),
	'dateOnline'=>date('Y-m-d',strtotime(SERVER_ONLINE_DATE)),
);
render('pay/pay_hour.tpl', &$data);



