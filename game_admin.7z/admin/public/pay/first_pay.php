<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Dec 16 04:49:14 GMT 2011
 * @desc 首充统计
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStart = $dateStartStamp ? date('Y-m-d',$dateStartStamp) : date('Y-m-d',strtotime('-1 month'));
$dateEnd = $dateEndStamp ? date('Y-m-d',$dateEndStamp) : date('Y-m-d');
$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);
$diffDay = ($dateEndStamp - $dateStartStamp)/86400;

$sqlPay   = "SELECT COUNT(DISTINCT `roleId`) AS roleCnt, SUM(payMoney) AS totalPay, mDateTime FROM t_log_pay WHERE totalTimes=1 AND mDateTime>={$dateStartStamp} AND  mDateTime<={$dateEndStamp} GROUP BY mDateTime  order by mDateTime";
$sqlLevel = "SELECT COUNT(DISTINCT `roleId`) AS roleCnt, roleLevel FROM t_log_pay WHERE  totalTimes=1 AND mDateTime>={$dateStartStamp} AND  mDateTime<={$dateEndStamp} GROUP BY roleLevel order by roleLevel";
$rsPay = fetchRowSet($sqlPay);
$rsLevel = fetchRowSet($sqlLevel);

$onlineTime = strtotime(SERVER_ONLINE_DATE);
$payData = array();
for ($i=0; $i<=$diffDay; $i++){
	$time = $dateStartStamp + $i*86400;
	$onlinDay = ($time - $onlineTime)/86400 +1;
	$payData[$time] = array('date'=>date('Y.m.d',$time), 'week'=>date('w',$time), 'onlineDay'=>$onlinDay, 'roleCnt'=>0, 'totalPay'=>0 );
}

$allPayRoleCnt = 0;
$maxPayRoleCnt = 0;
$allPayMoney = 0;
$maxPayMoney = 0;
$maxLeveRoleCnt = 0;
$allLevelRoleCnt = 0;
$maxLevelRate = 0;

foreach ($rsPay as $pay) {
	$allPayRoleCnt += $pay['roleCnt'];
	$allPayMoney += $pay['totalPay'];
	$maxPayRoleCnt = $pay['roleCnt'] > $maxPayRoleCnt ? $pay['roleCnt'] : $maxPayRoleCnt; 
	$maxPayMoney = $pay['totalPay'] > $maxPayMoney ? $pay['totalPay'] : $maxPayMoney; 
	$payData[$pay['mDateTime']]['roleCnt'] = $pay['roleCnt'];
	$payData[$pay['mDateTime']]['totalPay'] = $pay['totalPay'];
}
foreach ($rsLevel as $lv) {
	$allLevelRoleCnt += $lv['roleCnt'];
	$maxLeveRoleCnt   = $lv['roleCnt'] > $maxLeveRoleCnt ? $lv['roleCnt'] : $maxLeveRoleCnt; 
}
foreach ($rsLevel as &$lv) {
	$lv['rate'] = $allLevelRoleCnt > 0 ? round($lv['roleCnt']*100/$allLevelRoleCnt,2) : 0;
	$maxLevelRate = $lv['rate'] > $maxLevelRate ? $lv['rate'] : $maxLevelRate;
}

$data = array(
	'payData' => &$payData,
	'rsLevel' => &$rsLevel,
	'allPayRoleCnt' => &$allPayRoleCnt,
	'maxPayRoleCnt' => &$maxPayRoleCnt,
	'allPayMoney' => &$allPayMoney,
	'maxPayMoney' => &$maxPayMoney,
	'maxLeveRoleCnt' => &$maxLeveRoleCnt,
	'allLevelRoleCnt' => &$allLevelRoleCnt,
	'maxLevelRate' => &$maxLevelRate,
	'dateStart'=>$dateStart,
	'dateEnd'=>$dateEnd,
);
render('pay/first_pay.tpl',&$data);
