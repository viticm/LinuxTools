<?php
/**
 * $id chat.php
 * @author viticm<duchuan@pindian.com>
 * @todo view client logs
 * @createtime 2013-6-8 9:26:03
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp   = strtotime($_POST['dateEnd']);
$dateStart      = $dateStartStamp ? date('Y-m-d H:i:s',$dateStartStamp) : date('Y-m-d').' 00:00:00';
$dateEnd        = $dateEndStamp ? date('Y-m-d H:i:s',$dateEndStamp) : date('Y-m-d').' 23:59:59';

$dateStartStamp = strtotime($dateStart);
$dateEndStamp   = strtotime($dateEnd);
$rowPerPage     = intval($_POST['rowPerPage']);
$rowPerPage     = $rowPerPage ? $rowPerPage : LIST_PER_PAGE_RECORDS;
$page           = intval($_POST['page']);
$page           = $page > 0 ? $page : 1;
$cClientModel   = $_POST[ 'clientModel' ] ? $_POST[ 'clientModel' ] : '';

//===============start 查角色==============//
$role = $_POST['role'];
$msg = array();
if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	if (!$role['roleId']) {
		$msg[] = '找不到对应玩家';
	}
}
//===============end 查角色===============//

$where  = " where `mTime`>={$dateStartStamp} and `mTime` <= {$dateEndStamp} ";
$where .= $role['roleId'] ? " and accountName = {$role['accountName']} ":'';
$where .= '' == $cClientModel ? '' : ' AND `clientModel` = "'.$cClientModel.'"';
$where .= ' ORDER BY `mTime` ASC';
//===========查出记录数=======
$sqlCnt = " select count(*) as cnt from t_log_client {$where} ";
$rsCnt = fetchRowOne($sqlCnt);
$rowCount = $rsCnt['cnt'];
//===========================

$offset = ($page-1) * $rowPerPage;//每页开始位置
$pageCount =  ceil($rowCount/$rowPerPage);
$pageList = getPages($page, $rowCount, $rowPerPage);

//===========查出符合条件的数据=======
$sql = " select * from t_log_client {$where} limit  {$offset} , {$rowPerPage} ";
$rs = fetchRowSet($sql);
//=================================

$data = array(
	'dateStart'=>&$dateStart,
	'dateEnd'=>&$dateEnd,
	'rowPerPage'=>&$rowPerPage,
	'rowCount'=>&$rowCount,
	'page'=>&$page,
	'pageCount'=>&$pageCount,
	'pageList'=>&$pageList,
	'role' => &$role,
	'rs' => &$rs,
	'cClientModel' => &$cClientModel,
	'msg' => empty($msg) ? '' : implode('<br>',$msg),
);
render('logs/client.tpl',&$data);