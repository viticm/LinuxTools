<?php
/**
 * @author viticm<duchuangpd@gmail.com>
 * @Created  2012-12-21 14:21:38
 * @desc 玉符日志
 */
$dictTallyType = array();
$dictColorValue = array();
$dictGoods = array();

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_DICT.'/dict.php';
include_once SYSDIR_ADMIN_DICT.'/tally_type.php';
include_once SYSDIR_ADMIN_DICT.'/goods.php';

//===============start 查角色==============//
$role = $_POST['role'];
$msg = array();
if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	if (!$role['roleId']) {
		$msg[] = '找不到对应玩家';
	}
}
//===============end 查角色===============//

//===========start 处理多选================//
$allActionGet = intval($_POST['allActionGet']);
$allActionUse = intval($_POST['allActionUse']);
$allActionOther = intval($_POST['allActionOther']);
$mTypes = $_POST['mType'];
if (!$allActionGet && !$allActionUse && !$allActionOther && empty($mTypes)) {
	$allActionGet =1;
	$allActionUse =1;
	$allActionOther =1;
	$mTypes = array_keys($dictTallyType);
}
$isSelectAllAction = ($allActionGet && $allActionUse && $allActionOther) || (!$allActionGet && !$allActionUse && !$allActionOther && empty($mTypes)) ? true : false;
$strAction = !$isSelectAllAction && is_array($mTypes) && !empty($mTypes) ?  implode(',',$mTypes) : '';
//============end 处理多选=========//

//===============start 处理查询条件============//
$itemName = $_POST['itemName'];
$tmp = explode('|',$itemName);
$itemId = trim($tmp[0]) ? intval( trim($tmp[0]) ) : 0;
$dateStart = SS($_POST['dateStart']);
$dateEnd = SS($_POST['dateEnd']);
if(isPost()){
     $dateStartStamp = strtotime($dateStart);
     $dateEndStamp   = strtotime($dateEnd);
    if(!$dateStartStamp){
       $dateStart= date('Y-m-d',strtotime('-6day'));
    }
    if(!$dateEndStamp){
        $dateEnd = date('Y-m-d');
    }
}
$dateStart = $dateStart ? $dateStart : date('Y-m-d',strtotime('-6day'));
$dateEnd = $dateEnd ? $dateEnd : strftime("%Y-%m-%d",time());
$dateStartTamp = strtotime($dateStart.'0:0:0');
$dateEndTamp = strtotime($dateEnd.'23:59:59');
$dateStrToday = date('Y-m-d');
$dateStrNext = date('Y-m-d',strtotime('+1day',$dateStartTamp));
$dateStrPrev = date('Y-m-d',strtotime('-1day',$dateStartTamp));

$table = 't_log_tally';
$where = " where true ";
$where .= " and `mTime`>={$dateStartTamp} and `mTime` <= {$dateEndTamp} ";
$where .= $role['roleId'] ? " and roleId = {$role['roleId']} ":'';
$where .= $itemId ? " and itemId = {$itemId} ":'';
$where .= $strAction ? " and mType in({$strAction}) " :'';
//===============end 处理查询条件============//

//==================start 处理排序==============//
$sortType = array(
	0=>' mTime desc ',
	1=>' mTime asc ',
	2=>' tally desc ',
	3=>' tally asc ',
	4=>' bindTally desc ',
	5=>' bindTally asc ',
	6=>' roleLevel desc ',
	7=>' roleLevel asc ',
);
$sortTypeStr=array(
	0=>'时间↓',
	1=>'时间↑',
	2=>'不绑定玉符↓',
	3=>'不绑定玉符↑',
	4=>'绑定玉符↓',
	5=>'绑定玉符↑',
	6=>'角色等级↓',
	7=>'角色等级↑',
);
$orderby = intval($_POST['orderby']);
$sqlOrderBy = ' order by '.$sortType[$orderby];
//==================end 处理排序==============//


$sqlCnt = " select count(*) as cnt from {$table} {$where} ";
$rsCnt = fetchRowOne($sqlCnt);
$rowCount = intval($rsCnt['cnt']);//总记录

$rowPerPage = intval($_POST['rowPerPage']);
$rowPerPage = ( $rowPerPage >=10 && $rowPerPage <=500 ) ? $rowPerPage : LIST_PER_PAGE_RECORDS;
$pageno = intval($_POST['page']);
$pageno = $pageno > 0 ? $pageno : 1;
$pageCount = ceil($rowCount/$rowPerPage);
$offset =  $rowPerPage *($pageno-1);

$exportLimit = intval( $_POST['exportLimit'] ) ;
$exportLimit = $exportLimit ? $exportLimit : 1000;

$sqlLog = " SELECT * FROM {$table} {$where} {$sqlOrderBy} limit {$offset} , {$rowPerPage} ";
$rsLog = fetchRowSet($sqlLog);
foreach ($rsLog as &$row) {
	$row['itemName'] = $dictGoods[$row['itemId']]['name'];
    $row['color'] = $dictColorValue[$row['color']];
    $row['mType'] = $dictTallyType[$row['mType']];
}
$arrItems = &$dictGoods;
$strMsg = empty($msg) ? '' : implode('<br />', $msg);
$pageList = getPages($pageno,$rowCount,$rowPerPage);

$LogItemTypeGet = array(); //获得
$LogItemTypeUse = array(); //失去
$LogItemTypeOther = array(); //其他
foreach ($dictTallyType as $key => $val) {
	if ($key >= 10000 && $key <=19999) {
		$LogItemTypeGet[$key] = $val;
	}elseif ($key >= 20000 && $key<=29999 ){
		$LogItemTypeUse[$key] = $val;
	}else {
		$LogItemTypeOther[$key] = $val;
	}
}


$downloadHref = "";
//需要导出
if( !empty($_POST) ) {
	$needExport = $_POST['exportFlag'];
	if( $needExport == 1 ) {
		//导出数据
		$exportSql = " SELECT * FROM {$table} {$where} {$sqlOrderBy} limit {$exportLimit} ";
		$exportLog = fetchRowSet($exportSql);

		foreach ($exportLog as &$row) {
			$row['itemName'] = $dictGoods[$row['itemId']]['name'];
		    $row['color'] = $dictColorValue[$row['color']];
		    $row['mType'] = $dictTallyType[$row['mType']];
		}

		$path = LOG_DOWNLOAD_PATH;
		//$path = "/mnt/hgfs/code/game_admin/admin/admin/public/download/";
		$fileName = "silver_".time().".xls";
		$headInfo = "角色ID,账号名,角色名,玩家等级,操作类型,不绑定 玉符,绑定玉符,道具ID,道具名称,涉及道具数量或操作次数,操作时间\n";
		$ret = file_put_contents( $path.$fileName, $headInfo );
		if( FALSE  === $ret ){
			die("fail to write.$path.$fileName");
		}
		foreach( $exportLog as $tmplog ) {
			$fileMsg = $tmplog['roleId'] . ",". $tmplog['accountName'] . ",". $tmplog['roleName'] . ",". $tmplog['roleLevel'] . ",". $tmplog['mType']
						. ",". $tmplog['tally'] . ",". $tmplog['bindTally'] . ",". $tmplog['itemId'] . ",". $tmplog['itemName'] . ",". $tmplog['amount']
						. ",". date('Y-m-d H:i:s',$tmplog['mTime']) ."\n";
			$ret = file_put_contents( $path.$fileName, $fileMsg, FILE_APPEND );
			if( FALSE  === $ret ){
				die("fail to write.$path.$fileName");
			}
		}
//		$downloadHref = "http://".$_SERVER['HTTP_HOST']."/admin/public/download/".$fileName;
        $downloadHref = "http://".$_SERVER['HTTP_HOST']."/download/".$fileName;
		//删除1分钟之前的
		exec("find $path -amin +1 -name 'tally_*.xls' | xargs rm -rf {}");
	}
}


$data=array(
    'dateToday'=>$dateStrToday,
    'datePrev'=>$dateStrPrev,
    'dateNext'=>$dateStrNext,
	'dateStart'=>$dateStart,
	'dateEnd'=>$dateEnd,
	'role' => $role,
	'arrItems'=>$arrItems,
	'LogItemTypeGet'=>$LogItemTypeGet,
	'LogItemTypeUse'=>$LogItemTypeUse,
	'LogItemTypeOther'=>$LogItemTypeOther,
	'itemName'=>$itemName,
	'strMsg'=> $strMsg,
	'rowPerPage'=>$rowPerPage,
	'rowCount' => $rowCount,
	'pageCount'=>$pageCount,
	'pageList' => $pageList,
	'rsLog'=>&$rsLog,

	'mTypes' => $mTypes,
	'allActionGet'=>$allActionGet,
	'allActionUse'=>$allActionUse,
	'allActionOther'=>$allActionOther,

	'sortTypeStr'=>$sortTypeStr,
	'orderby'=>$orderby,

	//导出相关
	'needExport'=>$needExport,
	'exportLimit'=>$exportLimit,
	'downloadHref'=>$downloadHref,
);
render('logs/tally.tpl', &$data );