<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Nov 07 07:10:47 GMT 2011
 * @desc 玩家退出日志
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_DICT.'/logout_reason.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStart = $dateStartStamp ? date('Y-m-d H:i:s',$dateStartStamp) : date('Y-m-d',strtotime('-6day')).' 00:00:00';
$dateEnd = $dateEndStamp ? date('Y-m-d H:i:s',$dateEndStamp) : date('Y-m-d').' 23:59:59';

$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);

$rowPerPage = intval($_POST['rowPerPage']);
$rowPerPage = $rowPerPage ? $rowPerPage : LIST_PER_PAGE_RECORDS;
$page = intval($_POST['page']);
$page = $page > 0 ? $page : 1;

//===============start 查角色==============//
$role = $_POST['role'];
$msg = array();
if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	if (!$role['roleId']) {
		$msg[] = '找不到对应玩家';
	}
}
//===============end 查角色===============//

$where = " where `loginTime`>={$dateStartStamp} and `loginTime` <= {$dateEndStamp} ";
$where .= $role['roleId'] ? " and roleId = {$role['roleId']} ":'';

//===========查出记录数=======
$sqlCnt = " select count(*) as cnt from t_log_logout {$where} ";
$rsCnt = fetchRowOne($sqlCnt);
$rowCount = $rsCnt['cnt'];
//===========================

$offset = ($page-1) * $rowPerPage;//每页开始位置
$pageCount =  ceil($rowCount/$rowPerPage);
$pageList = getPages($page, $rowCount, $rowPerPage);

//===========查出符合条件的数据=======
$sql = " select * from t_log_logout {$where} limit  {$offset} , {$rowPerPage} ";
$rs = fetchRowSet($sql);
//=================================

foreach ($rs as &$row) {
	$row['logoutReasonText'] = $dictLogoutReason[$row['logoutReason']];
}

$data = array(
	'dateStart'=>&$dateStart,
	'dateEnd'=>&$dateEnd,
	'rowPerPage'=>&$rowPerPage,
	'rowCount'=>&$rowCount,
	'page'=>&$page,
	'pageCount'=>&$pageCount,
	'pageList'=>&$pageList,
	'role' => &$role,
	'rs' => &$rs,
	'msg' => empty($msg) ? '' : implode('<br>',$msg),
);
render('logs/logout.tpl',&$data);