<?php
/**
 * @author shuiyuandan@4399.com
 * @Created  Wed Dec 21 03:26:23 GMT 2011
 * @desc 给玩家送元宝
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_INCLUDE.'/functions.php';
include_once SYSDIR_ADMIN_INCLUDE.'/def.php';
include_once SYSDIR_ADMIN_DICT.'/goods.php';

$where = " where true ";

if( isPost() ) {
	//===============start 查角色==============//
	$role = $_POST['role'];
	
	$msg = array();
	if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
		$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
		if (!$role['roleId']) {
			$msg[] = '找不到对应玩家';
		}
	}
	//===============end 查角色===============//
	
	if( $role && $role['roleId'] ){
		$where = sprintf("%s and roleId=%d", $where, intval( $role['roleId'] ));
	}
	
	$auction = $_POST['auction'];
	//操作
	if( $auction && $auction['opType'] ){
		$where = sprintf("%s and mType=%d", $where, intval( $auction['opType'] ));
	}
	
	if( $auction && $auction['auctionId'] ){
		$where = sprintf("%s and auctionId=%d", $where, intval( $auction['auctionId'] ));
	}
	
	if( $auction && $auction['itemId'] && $dictGoods[ $auction['itemId'] ]){
		$where = sprintf("%s and itemId=%d", $where, intval( $auction['itemId'] ));
	}
	
	//时间
	if( !empty( $_POST['dateStart'] ) ) {
		$mTime = strtotime( $_POST['dateStart'] );
		$where = sprintf("%s and mTime>=%d", $where, $mTime );
	}
	
	if( !empty( $_POST['dateEnd'] ) ) {
		$mTime = strtotime(  $_POST['dateEnd'] );
		$where = sprintf("%s and mTime<=%d", $where, $mTime );
	}
}

$rowPerPage = intval($_POST['rowPerPage']);
$rowPerPage = $rowPerPage ? $rowPerPage : LIST_PER_PAGE_RECORDS;
$page = intval($_POST['page']);
$page = $page > 0 ? $page : 1;
$offset = ($page-1) * $rowPerPage;//每页开始位置

$sql = "select * from t_log_auction $where order by mTime desc limit {$offset}, {$rowPerPage}";
$rsAuctionRs = fetchRowSet( $sql );

foreach( $rsAuctionRs as &$elem ){
	$elem['mType'] = $AUCTION_OP_DIC[ intval($elem['mType']) ];
	$itemId = intval( $elem['itemId'] );
	$elem['itemId'] = $dictGoods[ $itemId ]['name'];
}

//===========查出记录数==========================================
$sqlCnt = " SELECT count(*) as cnt FROM t_log_auction $where ";
$rsCnt = fetchRowOne($sqlCnt);
$rowCount = $rsCnt['cnt'];

$pageCount =  ceil($rowCount/$rowPerPage);
$pageList = getPages($page, $rowCount, $rowPerPage);


// 生成物品串
$itemAry = array();
foreach( $dictGoods as $elemGoods ) {
    $itemAry[] = $elemGoods['id']." | ".$elemGoods['name'];
}

$data = array(
	'itemAry'=>$itemAry,
	'auctionOpDic'=>$AUCTION_OP_DIC,
	'resData' => $rsAuctionRs,
	'rowPerPage'=>$rowPerPage,
	'rowCount'=>$rowCount,
	'page'=>$page,
	'pageCount'=>$pageCount,
	'pageList'=>$pageList,
	'role'=>$role,
	'auction'=>$auction,
	'dateStart'=>$_POST['dateStart'],
	'dateEnd'=>$_POST['dateEnd'],
);

render('act/auction_history_list.tpl',&$data);
