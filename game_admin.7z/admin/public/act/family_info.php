<?php
/**
 * @author shuiyuandan@4399.com
 * @Created  Wed Dec 21 03:26:23 GMT 2011
 * @desc 给玩家送元宝
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_INCLUDE.'/functions.php';

$rowPerPage = intval($_POST['rowPerPage']);
$rowPerPage = $rowPerPage ? $rowPerPage : LIST_PER_PAGE_RECORDS;
$page = intval($_POST['page']);
$page = $page > 0 ? $page : 1;
$offset = ($page-1) * $rowPerPage;//每页开始位置

$sql = "select * from GUILD_TBL order by guild_contribution desc limit {$offset}, {$rowPerPage} ";

$rsFamily = GFetchRowSet( $sql );

//===========查出记录数=======
$sqlCnt = " SELECT count(*) as cnt FROM GUILD_TBL";
$rsCnt = GFetchRowOne($sqlCnt);
$rowCount = $rsCnt['cnt'];

$pageCount =  ceil($rowCount/$rowPerPage);
$pageList = getPages($page, $rowCount, $rowPerPage);

//附加后台数据库的相应数据
foreach( $rsFamily as &$elem ) {
	//未登陆天数
	$offDays = sprintf( "%.1f", ( $now - intval($elem['last_login_time']) ) / 86400 );
	$elem['offDays'] = $offDays > 1 ? $offDays-1 : 0;
	
	//最近充值时间
	$sql = "select mTime,payMoney from t_log_pay where roleId=".$elem['id']." order by mTime desc limit 1";
	$rs = fetchRowOne($sql);
	$elem['lastPayTime'] = $rs['mTime'];
	//最近充值额
	$elem['lastPayMoney'] = $rs['payMoney'];
	
	//总充值额
	$sql = "select sum(payMoney) as totalPay from t_log_pay where roleId=".$elem['id'];
	$rs = fetchRowOne($sql);
	$elem['totalPay'] = $rs['totalPay'];
}

$data = array(
	'resData' => $rsJjc,
	'rowPerPage'=>$rowPerPage,
	'rowCount'=>$rowCount,
	'page'=>$page,
	'pageCount'=>$pageCount,
	'pageList'=>$pageList,
);

render('act/jjc_rank_info.tpl',&$data);
