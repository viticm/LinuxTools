<?php
/**
 * @author shuiyuandan@4399.com
 * @Created  Wed Dec 21 03:26:23 GMT 2011
 * @desc 给玩家送元宝
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_INCLUDE.'/functions.php';
include_once SYSDIR_ADMIN_DICT.'/battle_def.php';

//获取参数
$dateStart = SS($_POST['dateStart']);
$dateEnd = SS($_POST['dateEnd']);
$registerDateStart = SS($_POST['registerDateStart']);
$registerDateEnd   = SS($_POST['registerDateEnd']);
$loginDateStart = SS($_POST['loginDateStart']);
$loginDateEnd   = SS($_POST['loginDateEnd']);
$dateStart = $dateStart ? $dateStart :  date('Y-m-d H:i:s',strtotime('-1day'));
$dateEnd = $dateEnd ? $dateEnd : date("Y-m-d H:i:s");
$registerDateStart = $registerDateStart ? $registerDateStart : date('Y-m-d 00:00:00', strtotime('-2day'));
$registerDateEnd   = $registerDateEnd ? $registerDateEnd : $dateStart;
$loginDateStart = $loginDateStart ? $loginDateStart : $dateStart;
$loginDateEnd   = $loginDateEnd ? $loginDateEnd : $dateEnd;

$tickStart = microtime_float();

$serverOnlineStamp = strtotime(SERVER_ONLINE_DATE);
$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);
$registerDateStartStamp = strtotime($registerDateStart);
$registerDateEndStamp = strtotime($registerDateEnd);
$loginDateStartStamp = strtotime($loginDateStart);
$loginDateEndStamp = strtotime($loginDateEnd);

$SILVER_PRODUCE_MTYPE   = 50028;
$GOLD_PRODUCE_MTYPE     = 10013;
$ACT_NAME               = "秘境寻宝";
$TBL_NOW                = "t_log_act";
$ACT_MTYPE              = 3;
$STAGE_ID               = 10102;

$actWhere       = " mTime>=$dateStartStamp and mTime<=$dateEndStamp and mType=$ACT_MTYPE";
$silverWhere    = " mTime>=$dateStartStamp and mTime<=$dateEndStamp and mType=$SILVER_PRODUCE_MTYPE"; 
$goldWhere      = " mTime>=$dateStartStamp and mTime<=$dateEndStamp and mType=$GOLD_PRODUCE_MTYPE"; 

$stageWhere     = " mTime>=$dateStartStamp and mTime<=$dateEndStamp and stageId=$STAGE_ID"; 
$registerWhere  = " select roleId from t_log_register where mTime>=$registerDateStartStamp and mTime<=$registerDateEndStamp ";
$loginWhere     = " select roleId from t_log_login where mTime>=$loginDateStartStamp and mTime<=$loginDateEndStamp "; 

//总参与人数
$sql = "select count(distinct(roleId)) as totalNum from $TBL_NOW where $actWhere and roleId in ($registerWhere) and roleId in ($loginWhere)";
//echo "总参与人数".$sql."<br>";
$rs = fetchRowOne( $sql );
$totalNum = intval( $rs['totalNum'] );

//总参与次数
$sql = "select count(*) as totalNum from $TBL_NOW where $actWhere and roleId in ($registerWhere) and roleId in ($loginWhere)";
//echo "总参与次数".$sql."<br>";
$rs = fetchRowOne( $sql );
$totalTimeNum = intval( $rs['totalNum'] );

//满足条件人数。 条件等级满足要求
$sql = "select count(distinct(roleId)) as totalNum from t_log_stage where "
      ." $stageWhere and roleId in ($registerWhere) and roleId in ($loginWhere)";
//echo "满足条件人数:".$sql."<br>";
$matchRs = fetchRowOne( $sql );
$matchNum = 0;
if( !empty( $matchRs ) ){
    $matchNum = intval( $matchRs['totalNum'] );
}

//参与度计算， 参与人数/满足条件人数
$participateRate = 0;
if( $matchNum != 0 ){
    $participateRate = number_format( $totalNum / $matchNum, 2 )*100;
}

//参与次数比例
$sql = "select distinct(roleId),count(*) as ct from $TBL_NOW where $actWhere and roleId in ($registerWhere) and roleId in ($loginWhere) group by roleId order by ct desc";
//echo "参与次数比例:".$sql."<br>";
$timesRs = fetchRowSet( $sql );
$timeDenominator = count( $timesRs );
$timeAry = array();
foreach( $timesRs as $elem ){
    $timeCt = intval( $elem['ct'] );
    if( empty($timeAry[$timeCt]) ){
        $timeAry[$timeCt] = 1;
    }else{
        $timeAry[$timeCt]++;
    }
}

$timeRate = array();
foreach( $timeAry as $key=>$elem ){
    if( $totalTimeNum != 0 ){
        $timeRate[ intval($key) ] = array("val"=>$elem, "rate"=>number_format(intval( $elem ) / $timeDenominator * 100, 2 ) );
    }else{
        $timeRate[ intval($key) ] = array("val"=>0, "rate"=>0 );
    }
}
// timeRate => { 次数： 所占比例 }

//铜钱产出
$sql = "select sum( silver ) as totalSilver from t_log_silver where $silverWhere and roleId in ($registerWhere) and roleId in ($loginWhere)";
//echo "铜钱产出".$sql."<br>";
$rs = fetchRowOne( $sql );
$totalSilver = intval( $rs['totalSilver'] );
$totalSilverStr = number_format( intval( $rs['totalSilver'] ), 2 );

//平均每人
$silverPerRole = 0;
if($totalNum){
    $silverPerRole = number_format( $totalSilver / $totalNum, 2 );
}
//平均每次
$silverPerTime = 0;
if($totalNum){
    $silverPerTime = number_format( $totalSilver / $totalTimeNum, 2 );
}

//元宝产出
$sql = "select sum( gold+bindGold ) as totalGold from t_log_gold where $goldWhere and roleId in ($registerWhere) and roleId in ($loginWhere)";
//echo "元宝产出".$sql."<br>";

$rs = fetchRowOne( $sql );
$totalGold = intval( $rs['totalGold'] ) ;
$totalGoldStr = number_format( intval( $rs['totalGold'] ), 2 );

//平均每人
$goldPerRole = 0;
if($totalNum){
    $goldPerRole = $totalGold / $totalNum;
}
//平均每次
$goldPerTime = 0;
if($totalNum){
    $goldPerTime = $totalGold / $totalTimeNum;
}


$tickDiff = number_format( microtime_float() - $tickStart, 4 );

$data = array(
    'dateStart' => &$dateStart,
    'dateEnd' => &$dateEnd,
    'prevDate' =>date('Y-m-d H:i:s', $dateStartStamp-86400),
    'nextDate' =>date('Y-m-d H:i:s', $dateStartStamp+86400),
    'registerDateStart'=>$registerDateStart,
    'registerDateEnd'=>$registerDateEnd,
    'loginDateStart'=>$loginDateStart,
    'loginDateEnd'=>$loginDateEnd,
    'serverOnlineDate' =>SERVER_ONLINE_DATE.' 00:00:00',
    'todayStart' =>date('Y-m-d 00:00:00'),
    'todayEnd' =>date('Y-m-d H:i:s'),
    
    'totalNum' => $totalNum,
    'totalTimeNum'=>$totalTimeNum,
    'matchNum'=>$matchNum,
    'participateRate'=>$participateRate,
    
    'timeRate'=>$timeRate,

    'totalSilver'=>$totalSilverStr,
    'silverPerRole'=>$silverPerRole,
    'silverPerTime'=>$silverPerTime,
    'totalGold'=>$totalGoldStr,
    'goldPerRole'=>$goldPerRole,
    'goldPerTime'=>$goldPerTime,


    'tickDiff'=>$tickDiff,
    'actName'=>$ACT_NAME,
);

render('act/magic_summary.tpl',&$data);
