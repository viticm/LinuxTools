<?php
/**
 * @author shuiyuandan@4399.com
 * @Created  Wed Dec 21 03:26:23 GMT 2011
 * @desc 给玩家送元宝
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_INCLUDE.'/functions.php';
include_once SYSDIR_ADMIN_INCLUDE.'/def.php';
include_once SYSDIR_ADMIN_DICT.'/goods.php';

$where = " where true ";

if( isPost() ) {
	//===============start 查角色==============//
	$role = $_POST['role'];
	
	$msg = array();
	if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
		$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
		if (!$role['roleId']) {
			$msg[] = '找不到对应玩家';
		}
	}
	//===============end 查角色===============//
	
	if( $role && $role['roleId'] ){
		$where = sprintf("%s and player_id=%d", $where, intval( $role['roleId'] ));
	}
	
	$auction = $_POST['auction'];

	if( $auction && $auction['auctionId'] ){
		$where = sprintf("%s and auction_id=%d", $where, intval( $auction['auctionId'] ));
	}

	if( $auction && $auction['itemId'] ){
		$where = sprintf("%s and item_text like '%%,%d,%%'", $where, intval( $auction['itemId'] ));
	}
	
	//时间
	if( !empty( $_POST['dateStart'] ) ) {
		$mTime = strtotime( $_POST['dateStart'] );
		$where = sprintf("%s and start_time>=%d", $where, $mTime );
	}
	
	if( !empty( $_POST['dateEnd'] ) ) {
		$mTime = strtotime(  $_POST['dateEnd'] );
		$where = sprintf("%s and start_time<=%d", $where, $mTime );
	}
}

$rowPerPage = intval($_POST['rowPerPage']);
$rowPerPage = $rowPerPage ? $rowPerPage : LIST_PER_PAGE_RECORDS;
$page = intval($_POST['page']);
$page = $page > 0 ? $page : 1;
$offset = ($page-1) * $rowPerPage;//每页开始位置

$sql = "select a.name,a.account,b.* from PLAYER_TBL a, MARKET_TBL b $where and a.id=b.player_id order by start_time desc limit {$offset}, {$rowPerPage}";
$rsAuctionRs = GFetchRowSet( $sql );

foreach( $rsAuctionRs as &$elem ){
	//物品串eg: 2,1006,10,0,1209788332,1
	$itemText = $elem['item_text'];
	$resAry = split( ",", $itemText );
	$itemId = intval( $resAry[1] );
	$elem['itemId'] = $dictGoods[ $itemId ]['name'];
	$elem['itemNum'] = intval( $resAry[2] );
	$elem['total_time'] = intval( $elem['total_time'] / 3600 )."小时";
}

//===========查出记录数==========================================
$sqlCnt = " SELECT count(*) as cnt FROM MARKET_TBL $where ";
$rsCnt = GFetchRowOne($sqlCnt);
$rowCount = $rsCnt['cnt'];

$pageCount =  ceil($rowCount/$rowPerPage);
$pageList = getPages($page, $rowCount, $rowPerPage);


// 生成物品串
$itemAry = array();
foreach( $dictGoods as $elemGoods ) {
    $itemAry[] = $elemGoods['id']." | ".$elemGoods['name'];
}

$data = array(
	'itemAry'=>$itemAry,
	'auctionOpDic'=>$AUCTION_OP_DIC,
	'resData' => $rsAuctionRs,
	'rowPerPage'=>$rowPerPage,
	'rowCount'=>$rowCount,
	'page'=>$page,
	'pageCount'=>$pageCount,
	'pageList'=>$pageList,
	'role'=>$role,
	'auction'=>$auction,
	'dateStart'=>$_POST['dateStart'],
	'dateEnd'=>$_POST['dateEnd'],
);

render('act/auction_online_list.tpl',&$data);
