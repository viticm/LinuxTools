<?php
/**
 * @author shuiyuandan@4399.com
 * @Created  Wed Dec 21 03:26:23 GMT 2011
 * @desc 发送系统邮件，赠送
 */
$dictGoods = array();
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';
include_once SYSDIR_ADMIN_DICT.'/goods.php';
include_once SYSDIR_ADMIN_DICT.'/dict.php';
include_once SYSDIR_ADMIN_DICT.'/def.php';

$gold   = 0;
$silver = 0;
$repu   = 0;
$itemName= "";
$title= "";
$content= "";
$pidList= "";
$itemId = null;
$itemNum = 0;
$iSpirit = 0;
$iCrystal = 0;

//限制宏
$MAX_ITEM_COUNT = 3;
$PID_COUNT      = 20;
$CONTENT_MAX    = 240;
$TITLE_MAX      = 100;

//区分全服和pid列表
$DEF_PIDLIST = 1;
$DEF_ALLPLAYER = 2;
$msg = array();

if( $_POST ){
    $gold   = intval( $_POST['gold'] );
    $silver = intval( $_POST['silver'] );
    $repu   = intval( $_POST['repu'] );
    $itemName= $_POST['itemName'];
    $title= $_POST['title'];
    $content= $_POST['content'];
    $pidList= $_POST['pidList'];
    $itemId = intval( $_POST['itemId'] );
    $itemNum = intval( $_POST['itemNum'] );
    $bindType = intval( $_POST['bindType'] );
    $iSpirit = intval( $_POST['spirit'] );
    $iCrystal = intval( $_POST['crystal'] );
    $iPidType = intval( $_POST[ 'playerlist' ] );
    // 参数检查
    if( $gold <= 0 ) $gold = 0;
    if( $silver <= 0 ) $silver = 0;
    if( $repu <= 0 ) $repu = 0;
    if ( $iSpirit <= 0 ) $iSpirit = 0;
    if ( $iCrystal <= 0 ) $iCrystal = 0;
    if( strlen(trim($content))>$CONTENT_MAX || strlen(trim($content))<=0 ){
        $msg[] = "错误: 邮件内容大小应该是0-$CONTENT_MAX";
    }
    if( strlen(trim($title))>$TITLE_MAX || strlen(trim($title))<=0 ){
        $msg[] = "错误: 邮件标题应该是0-$TITLE_MAX";
    }

    $itemCount = 0;
    if( $gold > 0 ) {
        $itemCount++;
    }
    if( $repu > 0 ) {
        $itemCount++;
    }
    if( $itemId && $dictGoods[$itemId] && $itemNum>0  ) {
        $itemCount++;
    }   
    
    // 物品个数限制
    if( $itemCount > $MAX_ITEM_COUNT ) {
        $msg[] = "错误: 最多可以放3种物品，元宝、声望、物品，分别算一个物品,铜钱、战魂、玄晶不算在其中.";
    }

    // 玩家ID列表限制
    $pidAry = explode( "\r\n", $pidList );
    if( count($pidAry) > $PID_COUNT ) {
        $msg[] = "错误: 一次最多发送给20个玩家";
    }

    // 玩家ID不能有重复, 且所有id必须在数据库中都存在
    $uniqAry = array();
    foreach( $pidAry as $pid ) {
        if( !empty( $uniqAry[$pid] ) ) {
            $msg[] = "错误: pid:$pid 重复！";
            break;
        }
        if( empty($pid) ){
        	continue;
        }
        $uniqAry[$pid] = 1;
        $sql = "select * from PLAYER_TBL where id=$pid;";
        $rs = GFetchRowSet($sql);
        if( count($rs) == 0 ){
            $msg[] = "错误: pid:$pid 不存在";
        }
    }

    // 成功
    if( count($msg) == 0 ) {
        //拼玩家ID列表      
        $pidAryStr = empty($pidList) ? '' : implode(',', $pidAry);
        if ( $DEF_ALLPLAYER == $iPidType )
        {
        	$pidAryStr = 'allplayer';
        }
        //接物品串
        $itemStr = "".$itemCount.";";
        if( $gold > 0 ) {
        	if($bindType == TYPE_BIND){
        		$itemStr .= "7002,$gold;";	
        	} else if ( $bindType == TYPE_UNBIND ) {
        		$itemStr .= "7002,$gold;";	
        	}
        }
        if( $repu > 0 ) { $itemStr .= "7003,$repu;"; }
        if( $itemId && $dictGoods[$itemId] && $itemNum>0 ) { $itemStr .= "$itemId,$itemNum;";}
        //if( $itemId && $dictGoods[$itemId] ) { $itemStr .= "$itemId,$itemNum;";}


        $detailLog = "PID列表: $pidAryStr; 铜钱: $silver; 元宝: $gold; 声望: $repu; 物品: $itemName,$itemNum;战魂：$iSpirit; 玄晶：$iCrystal;";
        $api = new ServerApi();
        $result = $api->sendBatchMail( $pidAryStr, $silver, $itemStr, $title, $content, $iSpirit, $iCrystal );
        if (1==$result['result']) {
            $msg[] = "【".date("Y-m-d H:i:s",time()).'】:系统邮件发送成功!';
            AdminLog::writeLog( AdminLog::LOG_TYPE_SEND_MAIL, $detailLog );
        }else {
            $msg[] = '发送失败!原因:'.$result['errorMsg'];
        }
    }
}

// 生成物品串
$itemAry = array();
foreach( $dictGoods as $elem ) {
    $itemAry[] = $elem['id']." | ".$elem['name'];
}

$strMsg = empty($msg) ? '' : implode('<br />', $msg);

$data = array(
    'gold'=>$gold,
    'silver'=>$silver,
    'repu'=>$repu,
    'spirit' => $iSpirit,
    'crystal' => $iCrystal,
    'itemName'=>$itemName,
    'itemNum'=>$itemNum,
    'title'=>$title,
    'pidList'=>$pidList,
    'itemId'=>$itemId,
    'content'=>$content,
    'itemAry'=>$itemAry,
    'TYPE_BIND'=>intval(TYPE_BIND),
    'TYPE_UNBIND'=>intval(TYPE_UNBIND),
    'strMsg'=>$strMsg,
    'DEF_PIDLIST' => $DEF_PIDLIST,
    'DEF_ALLPLAYER' => $DEF_ALLPLAYER,
);
render('player/send_sys_mail.tpl',&$data);
