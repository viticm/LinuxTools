<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Dec 16 08:59:08 GMT 2011
 * @desc 玩家状态查看 方便查看单个玩家的相关信息
 */
$dictJobs = array();
$dictStrength = array();
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_DICT.'/job.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_DICT.'/goods.php';
include_once SYSDIR_ADMIN_DICT.'/strength.php';
include_once SYSDIR_ADMIN_DICT.'/soul.php';

$arrSex = array(
        0 => '女',
        1 => '男',
);
$action = $_GET['action'];
$role = $_POST['role'];
$stones = array();
$itemsOrd = array();
//$api = new PlayerApi();

//支持Get
if( $_GET ) {
        if( $_GET['roleId'] ) {
                $role['roleId'] = intval( $_GET['roleId'] );
        }else if( $_GET['accountName'] ) {
                $role['accountName'] = SS( $_GET['accountName'] );
        }else if( $_GET['roleName'] ) {
                $role['roleName'] = SS( $_GET['roleName'] );
        }
}

if ('search'==$action) {
        $role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
        if (!$role['roleId']) {
                $msg[] = '找不到对应玩家';
        }
}else{
        $api = new ServerApi();
        if ('setPlayerOffLine'==$action) {
                $result = $api->setPlayerOffLine($role['roleId']);
                if (1==$result['result']) {
                        $msg[] = "操作成功！玩家{$role['roleName']}，已经被踢下线。";
                }else {
                        $msg[] = "操作失败！原因：{$result['errorMsg']} ";
                }
        }elseif('sendPlayerToPeaceVillage'==$action) {
                $result = $api->sendPlayerToPeaceVillage($role['roleId']);
                if (1==$result['result']) {
                        $msg[] = "操作成功！玩家{$role['roleName']}，已经被送回新手村。";
                }else {
                        $msg[] = "操作失败！原因：{$result['errorMsg']} ";
                }
        }elseif('setPlayerShopOffLine'==$action) {
                $result = $api->setPlayerShopOffLine($role['roleId']);
                if (1==$result['result']) {
                        $msg[] = "操作成功！玩家{$role['roleName']}的摊位，已经被踢下线。";
                }else {
                        $msg[] = "操作失败！原因：{$result['errorMsg']} ";
                }
        }
}

if($role['roleId']){
        //=====查询帐号及角色基本信息========//
        $sqlRoleInfo = " select * from PLAYER_TBL where `id`={$role['roleId']} ";
        $roleInfo = GFetchRowOne($sqlRoleInfo);
        $roleInfo['sexText'] = $arrSex[$roleInfo['sex']];
        $roleInfo['jobText'] = $dictJobs[$roleInfo['job']];
        //=====end 查询帐号及角色基本信息========//

        //=========玩家竞技场=============//
        $sqlRankInfo = "select rank from ATHLETIC_TBL where `id`={$role['roleId']} ";
        $res = GFetchRowOne( $sqlRankInfo );
        $roleInfo['rank'] = empty($res) ? 0: $res['rank'];

        //=========玩家在线情况=============//
        $online = array();
        $online['onlineStatus'] = $roleInfo['last_login_time'] > $roleInfo['last_logout_time'] ? 1 : 2; // 1=在线， 2=不在线
        $sqlOnline = " select sum(onlineTime) as totalOnlineTime from t_log_logout  where roleId={$role['roleId']} ";
        $rsOnline = fetchRowOne($sqlOnline);
        $online['totalOnlineTimeText'] = convertSecondToChinese($rsOnline['totalOnlineTime']);
        $startTime = strtotime(date('Y-m-d',strtotime('-6day')));
        $sqlSevenDayOnline = "SELECT SUM(onlineTime) AS online, logoutDate FROM t_log_logout WHERE roleId={$role['roleId']} and logoutTime>={$startTime} Group by logoutDate ";
        $rsSevenDayOnline = fetchRowSet($sqlSevenDayOnline);
        $online['seven'] = array();
        for ($i=0;$i<7; $i++){
                $time = $i*86400+$startTime;
                $date = date('Y-m-d',$time);
                $online['seven'][$time]= 0;
                foreach ($rsSevenDayOnline as $row) {
                        if (isset($online['seven'][$row['logoutDate']])) {
                                $online['seven'][$row['logoutDate']]= convertSecondToChinese($row['online']);
                        }
                }
        }
        $sevenOnlineTime = 0; //总时间不能放入循环中，不然会一直递增
        foreach ($rsSevenDayOnline as $row) 
        {
            $sevenOnlineTime += $row['online'];
        }
        $online['sevenOnlineTimeText'] = convertSecondToChinese($sevenOnlineTime);
        //=========end 玩家在线情况=============//

        //=========货币信息=============//
        $sqlPay = " select sum(payMoney) as totalPay,sum(payGold) as totalPayGold from t_log_pay where roleId={$role['roleId']} ";
        $rsPay = fetchRowOne($sqlPay);
        $pay['totalPay'] = ( $rsPay['totalPay'] != '' ? $rsPay['totalPay'] : 0 );
        $pay['totalPayGold'] = ( $rsPay['totalPayGold'] != '' ? $rsPay['totalPayGold'] : 0 );
        $pay['gold'] = $roleInfo['gold'];
        $pay['bindGold'] = $roleInfo['bind_gold'];
        $pay['silver'] = $roleInfo['silver'];
        $pay['bindSilver'] = $roleInfo['bind_silver'];
        //=========end 货币信息=============//


        //=========背包信息=============//
    $sqlBag = "select * from BAG_TBL where id={$role['roleId']} "; 
        $rsBag = GFetchRowOne($sqlBag);
    $itemStr = $rsBag['item_list'];
    $itemAry = explode(";", $itemStr );
    foreach( $itemAry as $item ) {
        if( strpos( $item, "," ) === FALSE ){
            continue;
        }
        $oitems[] = parseItemStr( $item );
    }
    //=======家族信息====================================//
    $sql = "select guild_name from GUILD_TBL where guild_id=".$roleInfo['guild_id'];
    $rs = GFetchRowOne( $sql );
    if( !empty( $rs ) ){
        $roleInfo['guild_id'] = $rs['guild_name'];
    } 

        //===============伙伴信息==============//
        $sqlPartner = " select * from PARTNER_TBL where player_id={$role['roleId']} ";
        $rsPartner = GFetchRowSet($sqlPartner);
        $partner = array();
        foreach ($rsPartner as $row) {
        //============装备信息==============//
        $equipStr = $row['equip_list'];
        $equipAry = explode(";", $equipStr );
        $equipObjs = array();
        foreach( $equipAry as $equip ) {
            if( strpos( $equip, "," ) === FALSE ) {
                continue;
            }
            $obj = parseEquipStr( $equip );
            $tmpId = intval( $obj['strength'] );
            $obj['strength'] = $dictStrength[ $tmpId ]['name'];
            $equipObjs[] = $obj;
        }
        $row['equipObjs'] = $equipObjs;
        //=============经脉信息==============//
        $soulStr = $row['soul_list'];
        $soulAry = explode(";", $soulStr );
        $soulObjs = array();
        foreach( $soulAry as $soul ) {
            if( strpos( $soul, "," ) === FALSE ) {
                continue;
            }
            $obj =  parseSoulStr( $soul );
            $soulObjs[] = $obj;
        }
        $row['soulObjs'] = $soulObjs;

        $partner[] = $row; //暂时不作细化处理
        }
        //===============end 伙伴信息==============//
}
$strMsg = empty($msg) ? '' : implode('<br />', $msg);
$data = array(
        'roleInfo'=>&$roleInfo,
        'online'=>&$online,
        'pay'=>&$pay,
                'role'=>$role,
                'partner'=>&$partner,
                'oitems'=>$oitems,
                'strMsg' => $strMsg,
);
render('player/player_status_view.tpl', &$data);

/*
* 将秒数，转换成中文表达方法，比如： 2分14秒，  3小时5分56秒
*/
function convertSecondToChinese($time)
{
        if ($time<=60)
        return $time.'秒';
        else if ($time<=3600)
        return floor($time/60).'分'. ($time % 60) . '秒';
        else if ($time<=86400)
        return floor($time/3600).'时'. floor(($time % 3600)/60). '分'. ($time % 60) . '秒';
        else
        return floor($time/86400).'天'. floor(($time % 86400)/3600). '时'. floor(($time % 3600)/60). '分'. ($time % 60) . '秒';
}