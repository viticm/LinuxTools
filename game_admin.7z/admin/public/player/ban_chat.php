<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Dec 20 06:41:11 GMT 2011
 * @desc 封禁IP
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';

$action = $_GET['action'];
$role = $_POST['role'];
$api = new ServerApi();
$msg = array();
if ($role) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	if (!$role['roleId']) {
		$msg[] = '找不到相应玩家';
	}
}
if ('search'==$action) {
	$minutes = intval($_POST['minutes']) ? intval($_POST['minutes']) : 30 ;
} elseif ('doBan'==$action) {
	$minutes = intval($_POST['minutes']);
	$reason = SS($_POST['reason']);
	if ($minutes <=0 ) { $msg[] = '请填写禁言时长(0＜禁言时长≤999999)'; }
	if ($minutes > 999999 ) { $msg[] = '请填写禁言时长(0≤禁言时长≤999999)'; }
	if (!$role['accountName'] ) { $msg[] = '请填写禁言帐号'; }
	if (empty($msg)) {
		$endBanTime = time() + $minutes * 60; //结束封禁的时间
		$result = $api->banChat($role['accountName'],$endBanTime,$reason);
		if (1==$result['result']) {
			$msg[] = '禁言成功！';
			AdminLog::writeLog(AdminLog::LOG_TYPE_BAN_CHAT,$reason, $role['accountName']);
		}else {
			$msg[] = '禁言失败！原因：'.$result['errorMsg'];
		}
	}
}elseif ('doUnban' == $action) {
	$accountName = SS($_GET['accountName']);
	if (!$accountName) {
		$msg[] = '帐号名不能为空！';
	}else {
		$result = $api->unBanChat($accountName);
		if (1==$result['result']) {
			$msg[] = '解除禁言成功！';
			AdminLog::writeLog(AdminLog::LOG_TYPE_UNBAN_CHAT, '', $accountName);
		}else {
			$msg[] = '解除禁言失败！原因：'.$result['errorMsg'];
		}
	}
}
$banList = array();
$ret = $api->getBanChatList();
if (1 != $ret['result']){
	$msg[] = $ret['errorMsg'];
}else {
	if (!empty($ret['data']) && is_array($ret['data'])) {
		foreach ($ret['data'] as &$row) {
			$row['endTime'] = date('Y-m-d H:i',$row['endTime']);
		}
		$banList = $ret['data'];
	}
}
$data = array(
	'role'=>$role,
	'minutes'=>$minutes,
	'channels'=>$channels,
	'banList' => $banList,
	'msg'=>empty($msg) ? '' : implode('<br />',$msg) ,
);
render('player/ban_chat.tpl',$data);
