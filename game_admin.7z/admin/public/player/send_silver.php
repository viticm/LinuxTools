<?php
/**
 * @author linruirong@4399.com
 * @Created  Wed Dec 21 03:26:06 GMT 2011
 * @desc 给玩家送铜钱
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';
include_once SYSDIR_ADMIN_INCLUDE.'/def.php';

$action = $_GET['action'];
$arrBind = array(1=>'绑定',2=>'不绑定');
$role = $_POST['role'];
$bindType = intval($_POST['bindType']); 
$bindType = 1==$bindType ? 1 : 2 ; //默认不绑定

//现在暂时没有绑定的，故都认为是未绑定的
$binType = TYPE_UNBIND;
if ('search'==$action) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
}
if (!$role['roleId'] && isPost()) {
	$msg[] = '找不到对应玩家';
}else{
	if ('doSendSilver' == $action) {
		$reason = SS($_POST['reason']);
		$silverNum = intval($_POST['silverNum']);
		if (!$silverNum) {
			$msg[] = '请填写赠送数量!';
		}
		if ($silverNum>1000000) {
			$msg[] = '最多只能送100锭!';
		}
		if (''==$reason) {
			$msg[] = '请填写赠送原因!';
		}
		if (empty($msg)) {
			$api = new ServerApi();
			//$result = $api->sendSilver($role['roleId'],$silverNum,$bindType,$reason);
			$result = $api->sendMoney($role['roleId'], TYPE_MONEY_SILVER,$silverNum,$bindType,$reason);
			if (1==$result['result']) {
				$msg[] = '赠送成功!';
				AdminLog::writeLog(AdminLog::LOG_TYPE_SEND_SILVER, $reason, $role['accountName'], $silverNum);
			}else {
				$msg[] = '赠送失败!原因:'.$result['errorMsg'];
			}
		}
	}
}

$strMsg = empty($msg) ? '' : implode('<br />', $msg);

$arrSendSilverReason = array(
	'1'=>'代理申请铜钱',
	'2'=>'内部申请铜钱',
	'3'=>'盗号的问题，补偿铜钱',
	'4'=>'充值没有到账，补发铜钱',
	'5'=>'帐号出现异常或BUG，跟铜钱购买有关的补偿',
	'6'=>'提交游戏建议，奖励铜钱',
	'7'=>'提交游戏BUG，奖励铜钱',
	'8'=>'配合GM测试，奖励铜钱',
	'9'=>'测试需要铜钱',
);
$data = array(
	'role'=>$role,
	'arrBind'=>$arrBind,
	'bindType'=>$bindType,
	'strMsg'=>$strMsg,
	'arrSendSilverReason'=>&$arrSendSilverReason,
);
render('player/send_silver.tpl',&$data);