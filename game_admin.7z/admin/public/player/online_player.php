<?php
/**
 * @author linruirong@4399.com
 * @Created  Wed Dec 07 08:10:40 GMT 2011
 * @desc 用于直接登录玩家的帐号，查看异常。或模拟平台登录流程。
 */

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$sql = " SELECT `id`, `name`, `account`, `level`, gold, last_logout_ip,last_login_time
		 FROM PLAYER_TBL WHERE last_login_time>last_logout_time ";
$rs = GFetchRowSet($sql);

$ips = array();
foreach ($rs as $row) {
	if ($row['last_logout_ip']) {
		$ips[$row['last_logout_ip']]['roleNames'] .= $row['name'].'，';
		if ($ips[$row['last_logout_ip']]['cnt'] >= 5  && $ips[$row['last_logout_ip']]['cnt']%5==0) {
			$ips[$row['last_logout_ip']]['accountNames'] .= '<br />'.$row['account'].'，';
		}else {
			$ips[$row['last_logout_ip']]['accountNames'] .= $row['account'].'，';
		}
		$ips[$row['last_logout_ip']]['cnt'] +=1;
	}
}
foreach ($rs as &$r) {
	$r['onlineMin'] = round((time()-$r['last_login_time'])/60); 
}
$diffIpCnt = count($ips);
$diffRoleCnt = count($rs);
$data = array(
	'accounts'=>&$rs,
	'ips' => &$ips,
	'diffRoleCnt' => &$diffRoleCnt,
	'diffIpCnt' => &$diffIpCnt,
);
render('player/online_player.tpl', $data);
