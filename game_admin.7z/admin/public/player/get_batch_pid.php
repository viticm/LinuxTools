<?php
/**
 * @author shuiyuandan@4399.com
 * @Created  Sat Dec 17 03:32:52 GMT 2011
 * @desc db 批量获取玩家的id
 */

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';

$type = intval( $_POST['type'] );
$listval = $_POST['listval'];

if($_POST) {
    if(strlen(trim($listval)) == 0 ) {
        $msg[] = "请输入查询值";
    }

    $delim = "\r\n";

    $pidlist = "";
    $valAry = explode( $delim, $listval );
    trimArray( $valAry );
    if( $type == 1 )
    {
        foreach( $valAry as $elem ) {
            $elem = SS($elem);
            $sql = "SELECT id from PLAYER_TBL where name='".$elem."' limit 1";
            $rs = GFetchRowSet($sql);
            if( count($rs) == 1 )
            {
                $pidlist .= $rs[0]['id']."\r\n";
            }else
            {
                $msg[] = "角色 $elem 未找到!";
            }
        }
    }else if( $type == 2 ){
        foreach( $valAry as $elem ) {
            $elem = SS($elem);
            if( strlen($elem) == 0 )
                continue;
            $sql = "SELECT id from PLAYER_TBL where account='".$elem."'";
            $rs = GFetchRowSet($sql);
            if( count($rs) == 1 ) {
                $pidlist .= $rs[0]['id']."\r\n";
            } else {
                $msg[] = "账号 $elem 未找到!";
            }
        }
    }
}

$data = array(
    'listval' => $listval,
    'pidlist' => $pidlist,
    'type' => $type,
    'msg' => empty($msg)? '' : implode('<br />', $msg),
);
render('player/get_batch_pid.tpl',$data);
