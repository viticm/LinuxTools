<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Dec 20 06:41:11 GMT 2011
 * @desc 封禁IP
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';

$api = new ServerApi();
$action = $_GET['action'];
$action = $action ? $action : 'list';
if ('doBan'==$action){
	$ip = SS($_POST['ip']);
	$banHour = intval($_POST['banHour']);
	$endTime = 99999==$banHour ? 2147483647 : time()+ $banHour*3600; //如果是永久封禁，则过期时间设到最大（int32最大）。
	$reason = $_POST['reason'];
	
	if (!$ip || !$reason) {
		$msg[] = 'ip和封禁原因都不能为空！';
	}
	if (empty($msg) && !preg_match('/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/',$ip)) {
		$msg[] = 'IP地址格式不正确';
	}
	if (empty($msg)) {
		$ret = $api->banIp($ip,$endTime, $reason);
	}
	if (1==$ret['result']) {
		$msg[] = "{$ip} 已经被封禁！";
		AdminLog::writeLog(AdminLog::LOG_TYPE_BAN_IP, $ip.':'.$reason);
	}else {
		$msg[] = $ret['errorMsg'];
	}
}elseif ('doUnBan' == $action){
	$ip = SS($_GET['ip']);
	if (!$ip) {
		$msg[] = '帐号名不能为空！';
	}else {
		$ret = $api->unBanIp($ip);
		AdminLog::writeLog(AdminLog::LOG_TYPE_UNBAN_IP, $ip);
	}
	if (1==$ret['result']) {
		$msg[] = "{$ip} 已经被解封！";
	}else {
		$msg[] = $ret['errorMsg'];
	}
}

$list = array();
$ret = $api->getBanIpList();
if (1 != $ret['result']){
	$msg[] = $ret['errorMsg'];
}else {
	if (!empty($ret['data']) && is_array($ret['data'])) {
		foreach ($ret['data'] as &$row) {
			$row['endTime'] = date('Y-m-d H:i',$row['endTime']);
		}
		$list = $ret['data'];
	}
}
$arrReason = array(
	'涉及盗号',
	'存在违规操作',
	'散布虚假信息，造成不良影响',
	'在游戏中假冒GM或其他客户服务人员',
	'使用第三方软件进行游戏，破坏游戏平衡',
	'使用违反命名规则之角色名称进行注册',
	'利用游戏提供的功能进行非法实物交易',
	'利用系统的BUG、漏洞为自己及他人牟利',
	'不断吵闹、重复发言、不断打广告、恶意刷屏',
	'辱骂、人身攻击其他玩家，妨碍他人正常游戏',
);
$arrBanHour = array(
	72    =>'限制72小时',
	24*7  =>'限制一个星期',
	24*31 =>'限制一个月',
	24    =>'限制24小时',
	12    =>'限制12小时',
	6     =>'限制6小时',
	3     =>'限制3小时',
	1     =>'限制1小时',
	99999 =>'永久封禁',
);
$data = array(
	'list' => &$list,
	'ip' => &$ip,
	'banHour' => &$banHour,
	'reason' => &$reason,
	'arrReason' => &$arrReason,
	'arrBanHour' => &$arrBanHour,
	'msg' => empty($msg)? '' : implode('<br />', $msg),
);
render('player/ban_ip.tpl',$data);