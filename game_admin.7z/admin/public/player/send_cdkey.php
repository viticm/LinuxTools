<?php
/**
 * game admin website
 * @link duchuanpd@gmail.com
 * @copyright Copyright (c) 2012-2013 Gzpd.(www.gzpindian.com)
 * @license none
 * @desc 发送CDKEY
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';
include_once SYSDIR_ADMIN_INCLUDE.'/def.php';

$arrGroup = array(1=>'普通玩家',2=>'付费玩家');

$iGroupType = intval($_POST['iGroupType']); 
$iGroupType = $iGroupType ? $iGroupType : TYPE_CDKEY_NORMAL ; //默认普通玩家

if ( isPost() ) {
	if ('doSendCDKEY' == $_GET[ 'action' ]) {
		$api = new ServerApi();
		//$result = $api->sendSilver($role['roleId'],$silverNum,$bindType,$reason);
		$result = $api->sendCdkey($iGroupType);
		if (1==$result['result']) {
			$msg[] = '操作成功!';
			AdminLog::writeLog(AdminLog::LOG_TYPE_SEND_CDKEY, $iGroupType );
		}else {
			$msg[] = '操作失败!原因:'.$result['errorMsg'];
		}
	}	
	
}

$strMsg = empty($msg) ? '' : implode('<br />', $msg);

$data = array(
	'arrGroup'=>$arrGroup,
	'iGroupType'=>$iGroupType,
	'strMsg'=>$strMsg,
);
render('player/send_cdkey.tpl',&$data);