<?php
/**
 * @author linruirong@4399.com
 * @Created  Wed Dec 07 08:10:40 GMT 2011
 * @desc 用于直接登录玩家的帐号，查看异常。或模拟平台登录流程。
 */

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';

define('GAMER_SERVER_START_URL',GAME3W_URL.'start.php');

$prefix = 'acname_';
$action = $_GET['action'];
$role = $_POST['role'];
if ('search'==$action) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	if (!$role['roleId']) {
		$msg[] = '找不到对应玩家';
	}
}
if ('login'==$action) {
	if ($role['accountName']) {
		$log = new AdminLog();
		$log->writeLog(AdminLog::LOG_TYPE_LOGIN_PLAYER_ACCOUNT, '', $role['accountName'] );
		
		$account = urlencode($role['accountName']);
		$tstamp = time();
		$fcm = 1 ;
		$fromAdmin = 1;
		$ticket = md5($role['accountName'].$tstamp.$fcm.$fromAdmin.PLATFORM_LOGIN_KEY);
		$url = GAMER_SERVER_START_URL."?account={$account}&tstamp={$tstamp}&fcm={$fcm}&from_admin={$fromAdmin}&ticket={$ticket}";
		header("location:{$url}");
	}else {
		$msg[] = '错误!帐号名不能为空!';
	}
}
if ('imitate'==$action) {
	$account = trim($_POST['account']);
	if (0 !== strpos($account,$prefix)) {
		$msg[] = "错误!模拟平台登录的帐号必须以 {$prefix} 为前缀!";
	}else {
		$accountEncode = urlencode($account);
		$tstamp = time();
		$fcm = 1 ;
		$fromAdmin = 1;
		$ticket = md5($account.$tstamp.$fcm.$fromAdmin.PLATFORM_LOGIN_KEY);
		$url = GAMER_SERVER_START_URL."?account={$accountEncode}&tstamp={$tstamp}&fcm={$fcm}&from_admin={$fromAdmin}&ticket={$ticket}";
		header("location:{$url}");
	}
}

$strMsg = empty($msg) ? '' : implode('<br />', $msg);
$data = array(
	'role'=>$role,
	'strMsg' => $strMsg,
	'action'=>$action,
	'herf'=>$herf,
	'prefix'=>$prefix,
);
render('player/login_player_account.tpl', $data);
