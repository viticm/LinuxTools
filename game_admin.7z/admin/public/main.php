<?php
include_once '../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE."/global.php";

$data = array('SERVER_NAME'=>SERVER_NAME);
render("main.tpl",$data);