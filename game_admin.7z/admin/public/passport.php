<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Oct 31 02:48:29 GMT 2011
 * @desc 此用于与登录授权系统对接
 */

include_once '../protected/config/config.php';
session_start();
$time =  $_POST['time'];
$serverName = $_POST['serverName'];
$userInfo = $_POST['userInfo'];
$ticket = $_POST['ticket'];
$key = md5(GATEWAY_SYSTEM_AUTH_KEY.$time.$serverName.$userInfo);

// 登录授权结果 1=成功, 2=超时, 3=参数不全 , 4=ticket错误 
if ( abs(time()-$time) > 60) { //登录超时
	$result = 2;
}elseif (!$ticket||!$time||!$serverName||!$userInfo){
	$result = 3;
}elseif($ticket != $key) {
	$result = 4;
}else {
	$result = 1;
	$userInfo = base64_decode(base64_decode($_POST['userInfo']));
	$userInfo = json_decode($userInfo, true);
	$_SESSION[SESSION_KEY]['sessionLoginServers'][$serverName] = $serverName;
	$_SESSION[SESSION_KEY]['user'] = $userInfo;
}

$action = 'changeToGameAdmin';
$ticket = md5(GATEWAY_SYSTEM_AUTH_KEY.$action.$time.$serverName.$result);
$url = GATEWAY_SYSTEM_URL."passport.php?action={$action}&time={$time}&serverName={$serverName}&result={$result}&ticket={$ticket}";
header("Location:{$url}");
die();