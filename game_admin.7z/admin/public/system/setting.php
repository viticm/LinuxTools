<?php
/**
 * @author linruirong@4399.com
 * @Created  Wed Dec 07 09:21:16 GMT 2011
 * @desc 用于配置游戏入口 flash的那些参数
 */

require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';

define('GAMER_SERVER_SET_CLIENT_CONF_URL', GAME3W_URL.'api/set_server_conf.php'); //设置游戏前端入口参数
define('GAMER_SERVER_GET_CLIENT_CONF_URL', GAME3W_URL.'api/get_server_conf.php'); //获取游戏前端入口参数
$timestamp = time();
$key = md5($timestamp.GAME3W_AUTH_KEY);

if (isPost()) {
	$conf = $_POST['conf'];
	$encodeConf = urlencode( base64_encode(json_encode($conf)) );
	
	$params = 'key='.$key.'&timestamp='.$timestamp.'&data='.$encodeConf."&gamenum=".GAME_NO."&servernum=".SERVER_NAME;
	$result = curlPost(GAMER_SERVER_SET_CLIENT_CONF_URL,$params);
	$result = json_decode($result,true);
	if (!$result || 1 != $result['result']) 
	{
		$result['errorMsg'] = $result['errorMsg'] ? $result['errorMsg'] : '同步数据出错:可能无法连接游戏服务器!';
		$errormsg[] = $result['errorMsg'];
	}
	else
	{
		$log = new AdminLog();
		$log->writeLog(AdminLog::LOG_TYPE_SET_CLIENT_VARS);
		$errormsg[] = '保存成功！';
	}
}

$params = "?timestamp={$timestamp}&key={$key}&gamenum=".GAME_NO."&servernum=".SERVER_NAME;
$getJsonClientConf = @file_get_contents(GAMER_SERVER_GET_CLIENT_CONF_URL.$params);

$result = json_decode($getJsonClientConf,true);

if (1!=$result['result']) 
{
	$result['errorMsg'] = $result['errorMsg'] ? $result['errorMsg'] : '获取数据出错:可能无法连接游戏服务器!';
	$errormsg[] = $result['errorMsg'];
}
else
{
	$sucessmsg[] = $result[ 'errorMsg' ];
}


/**Modify Start 2012-11-8 By viticm**/
/**修改了所需的参数**/
$data=array(
	'conf'=>$result['data'],
	'errorMsg'=>empty($errormsg) ? '' : implode('<br />',$errormsg),
    'sucessMsg' => empty($sucessmsg) ? '' : implode('<br />',$sucessmsg),
    'GAME_NO' => GAME_NO,
	'AGENT_ID'=>AGENT_ID,
	'AGENT_NAME'=>AGENT_NAME,
	'SERVER_ID'=>SERVER_ID,
	'SERVER_NAME'=>SERVER_NAME,
    'DB_ADMIN_HOST' => DB_HOST,
    'DB_ADMIN_USER' => DB_USER,
    'DB_ADMIN_PASSWORD' => DB_PASSWD,
    'DB_ADMIN_NAME' => DB_NAME,
    'DB_GAME_HOST' => DB_GAME_HOST,
    'DB_GAME_USER' => DB_GAME_USER,
    'DB_GAME_PASSWORD' => DB_GAME_PASSWD,
    'DB_GAME_NAME' => DB_GAME_DB_NAME,
    'SYS_LOG_DIR' => SYSDIR_GAME_LOG,
    'SYS_GAME_LOG_DIR' => SYSDIR_GAME_LOG.'logs',
    'SYS_LOG_FILE' => SYSDIR_GAME_LOG.'fstx_game_www.log',
    'ADMIN_GAME_AUTH_KEY' => GAME3W_AUTH_KEY,
    'GAME_SERVER_API_HOST' => SERVER_SOCKET_HOST,
    'GAME_SERVER_API_PORT' => SERVER_SOCKET_PORT,
    'APPLY_SERVER_URL' => GAME3W_URL,
);
/**Modify End 2012-11-8 By viticm**/
render('system/setting.tpl',$data);