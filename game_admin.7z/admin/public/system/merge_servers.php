<?php
/**
 * @desc 合服工具
 * $id merge_servers.php
 * @copyright ©2012 pindian
 * mynote: 全部的缩进使用4个空格，这是一个好习惯（在方法体内开头使用4个空格，后面自动缩进的也是4个空格）
 */
require_once ( '../../protected/config/config.php' );
require_once ( SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php' );
include_once ( SYSDIR_ADMIN_CLASS.'/admin_log.php' );
require_once ( SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'my_global.php' );
define( 'GET_MERGE_API_URL', GATEWAY_SYSTEM_URL.'api/merge_servers_log_api.php' ); //获取合服信息api
define( 'BACKUP_DB_DIR', SYSDIR_ADMIN_PUBLIC.DIRECTORY_SEPARATOR.'download'.DIRECTORY_SEPARATOR.'backupdb' );
$cAction = GetUrlParam( 'action' );

switch ( $cAction )
{
    case 'main':
        main();
        break;
    case 'copyTable':
        copyTable();
        break;
    case 'getTableRecords':
        getTableRecords();
        break;
    case 'addMergeLog':
        addMergeLog();
        break;
    case 'backupDb':
        backupDb();
        break;
    case 'getRollbackInfo':
        getRollbackInfo() ;
        break ;
    case 'runRollback':
        runRollback() ;
        break ;
    case 'truncateDefaultTables':
    	truncateAllDefaultTables() ;
    	break ;
    case 'clearRoleData':
    	clearRoleData() ;
    	break ;
    default:
        main();
}

/**
 * @desc 获取表记录数量，给ajax使用
 * @param void
 * @return void
 */
function getTableRecords()
{
    checkCopyTable();
    $Arr_Result = array();
    $Arr_Result[ 'ErrorCode' ] = 1;
    $Arr_Result[ 'ErrorDesc' ] = '';
    $Arr_Result[ 'records' ] = 0;
    $Arr_Result[ 'tableName' ] = '';
    $cDbType = GetUrlParam( 'dbType' );
    $iTableId = GetUrlParam( 'tableId' );
    $Arr_SrcDbConfig = array();
    $Arr_SrcDbConfig[ 'host' ] = 'admin' == $cDbType ? DB_HOST : DB_GAME_HOST;
    $Arr_SrcDbConfig[ 'user' ] = 'admin' == $cDbType ? DB_USER : DB_GAME_USER;
    $Arr_SrcDbConfig[ 'password' ] = 'admin' == $cDbType ? DB_PASSWD : DB_GAME_PASSWD;
    $Arr_SrcDbConfig[ 'dbname' ] = 'admin' == $cDbType ? DB_NAME : DB_GAME_DB_NAME;
    $OBJ_SrcDb = new MergeServer( $Arr_SrcDbConfig );
    $Arr_Table = $OBJ_SrcDb->getAllTables();
    $cTableName = $Arr_Table[ $iTableId ];
    if( !isset( $cDbType ) || !isset( $iTableId ) )
    {
        $Arr_Result[ 'ErrorCode' ] = 2;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '缺少参数' );
        SprintJsonStrAndExit( $Arr_Result );
    }
    if( false === $OBJ_SrcDb->bConnect )
    {
        $Arr_Result[ 'ErrorCode' ] = 3;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '数据库连接失败' );
        SprintJsonStrAndExit( $Arr_Result );
    }

    //get records
    if( !empty( $cTableName ) )
    {
        $Records = $OBJ_SrcDb->getRecordsOfTable( $cTableName );
        if ( false === $Records )
        {
            $Arr_Result[ 'ErrorCode' ] = 5;
            $Arr_Result[ 'ErrorDesc' ] = urlencode( '查询失败' );
        }
        else
        {
            $Arr_Result[ 'records' ] = $Records;
            $Arr_Result[ 'tableName' ] = $cTableName;
        }
    }
    else
    {
        $Arr_Result[ 'ErrorCode' ] = 4;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( "表ID[{$iTableId}]的表不存在于源服务器中" );
    }
    unset( $OBJ_SrcDb );
    print_r( json_encode( $Arr_Result ) );
}

/**
 * @desc 记录合区日志
 * @param void
 * @return void
 */
function addMergeLog()
{
    checkCopyTable();
    $Arr_Result = array();
    $Arr_Result[ 'ErrorCode' ] = 1;
    $Arr_Result[ 'ErrorDesc' ] = '';
    $iTimeStamp = time();
    $cCheckKey = md5( $iTimeStamp.GATEWAY_SYSTEM_AUTH_KEY );
    $iDstServerId = GetUrlParam( 'dstServerId' );
    if( !isset( $iDstServerId ) )
    {
        $Arr_Result[ 'ErrorCode' ] = 2;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '缺少参数' );
        SprintJsonStrAndExit( $Arr_Result );
    }
    $OBJ_Log = new AdminLog();
    $OBJ_Log->writeLog( AdminLog::LOG_TYPE_MERGE_SERVER, '源服务器：'.SERVER_ID.' 目标服务器：'.$iDstServerId );
    $Arr_MergeServerLog = array();
    $Arr_MergeServerLog[ 'serverId' ] = SERVER_ID;
    $Arr_MergeServerLog[ 'agentId' ] = AGENT_ID;
    $Arr_MergeServerLog[ 'mergeTo' ] = $iDstServerId;
    $Arr_MergeServerLog[ 'mergeTime' ] = time();
    $cMergeServerLog = base64_encode( json_encode( $Arr_MergeServerLog ) );
    $cAddMergeServerLogParams = 'action=addlog&mergeLog='.$cMergeServerLog.'&key='.$cCheckKey.'&timeStamp='.$iTimeStamp;
    $Arr_Result = json_decode( urldecode( curlPost( GET_MERGE_API_URL, $cAddMergeServerLogParams ) ), true );
    if ( !$Arr_Result || 1 != $Arr_Result['ErrorCode'])
    {
        $Arr_Result['ErrorDesc'] = $Arr_Result['ErrorDesc'] ? $Arr_Result['ErrorDesc'] : '添加合区日志失败!';
    }
    print_r( json_encode( $Arr_Result ) );
}

/**
 * @desc 复制表方法，给ajax使用
 * @param void
 * @return void
 */
function copyTable()
{
    checkCopyTable();
    /** 因为数据量太大，每张表需要截取出一些数据出来然后再导入 **/
    $Arr_Result = array();
    $Arr_Result[ 'ErrorCode' ] = 1;
    $Arr_Result[ 'ErrorDesc' ] = '';
    $iDstServerId = GetUrlParam( 'dstServerId' );
    $cDbType = GetUrlParam( 'dbType' );
    $iOffsetStart = GetUrlParam( 'offsetStart' );
    $iRecords = GetUrlParam( 'records' );
    $iTableId = GetUrlParam( 'tableId' );
    $Arr_CanUseDbType = array( 'admin', 'game' );
    if( !isset( $cDbType ) || !isset( $iTableId ) || !isset( $iOffsetStart ) || !isset( $iRecords ) || !isset( $iDstServerId ) )
    {
        $Arr_Result[ 'ErrorCode' ] = 2;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '缺少参数' );
    }
    else
    {
        if( !in_array( $cDbType, $Arr_CanUseDbType ) )
        {
            $Arr_Result[ 'ErrorCode' ] = 3;
            $Arr_Result[ 'ErrorDesc' ] = urlencode( '数据库类型不存在：just can use: admin or game' );
        }
        else
        {
            $Arr_Result = copyTableRun( $cDbType, $iDstServerId, $iTableId, $iOffsetStart, $iRecords );
        }

    }
    print_r( json_encode( $Arr_Result ) );
}
/**
 *
 * @desc 执行复制数据方法
 * @param string $cDbType
 * @param int $iDstServerId
 * @param string $cTableName
 * @param int $iOffsetStart
 * @param int $iRecords
 * @return void
 */
function copyTableRun( $cDbType, $iDstServerId, $iTableId, $iOffsetStart, $iRecords )
{
    checkCopyTable();
    $iTimeStamp = time();
    $cCheckKey = md5( $iTimeStamp.GATEWAY_SYSTEM_AUTH_KEY );
    $Arr_Result = array();
    $Arr_Result[ 'ErrorCode' ] = 1;
    $Arr_Result[ 'ErrorDesc' ] = '';

    $Arr_SrcDbConfig = array();
    $Arr_SrcDbConfig[ 'host' ] = 'admin' == $cDbType ? DB_HOST : DB_GAME_HOST;
    $Arr_SrcDbConfig[ 'user' ] = 'admin' == $cDbType ? DB_USER : DB_GAME_USER;
    $Arr_SrcDbConfig[ 'password' ] = 'admin' == $cDbType ? DB_PASSWD : DB_GAME_PASSWD;
    $Arr_SrcDbConfig[ 'dbname' ] = 'admin' == $cDbType ? DB_NAME : DB_GAME_DB_NAME;
    $OBJ_SrcDb = new MergeServer( $Arr_SrcDbConfig );
    $Arr_Table = $OBJ_SrcDb->getAllTables();
    $cTableName = $Arr_Table[ $iTableId ];

    if( !empty( $cTableName ) )
    {
        $cGetDstServerConfParams = '?action=getserverconf&key='.$cCheckKey.'&timeStamp='.$iTimeStamp."&serverId=".$iDstServerId."&agentId=".AGENT_ID;
        $cGetDstServerConfResult = urldecode( @file_get_contents( GET_MERGE_API_URL.$cGetDstServerConfParams ) );
        $Arr_ResultConf = json_decode( $cGetDstServerConfResult,true );

        if ( !$Arr_ResultConf || 1 != $Arr_ResultConf['ErrorCode'])
        {
            $Arr_Result[ 'ErrorCode' ] = 5;
            $Arr_Result[ 'ErrorDesc' ] = $Arr_ResultConf['ErrorDesc'] ? $Arr_ResultConf['ErrorDesc'] : urlencode( '获取目标服务器信息失败!' );
        }
        else
        {
            $Arr_SrcData = array();
            $Arr_SrcData = $OBJ_SrcDb->getItemOfTable( $cTableName, $iOffsetStart, $iRecords );
            $Arr_SrcData = checkCopyTableData( $cDbType, $cTableName, $Arr_SrcData ) ;
            $Arr_ServerConf = $Arr_ResultConf[ 'server' ];
            $Arr_DstDbConfig = array();
            $Arr_DstDbConfig[ 'host' ] = 'admin'== $cDbType ? $Arr_ServerConf[ 'dbHost' ] : $Arr_ServerConf[ 'dbGameHost' ];
            $Arr_DstDbConfig[ 'user' ] = 'admin' == $cDbType ? $Arr_ServerConf[ 'dbUser' ] : $Arr_ServerConf[ 'dbGameUser' ];
            $Arr_DstDbConfig[ 'password' ] = 'admin' == $cDbType ? $Arr_ServerConf[ 'dbPasswd' ] : $Arr_ServerConf[ 'dbGamePasswd' ];
            $Arr_DstDbConfig[ 'dbname' ] = 'admin' == $cDbType ? $Arr_ServerConf[ 'dbName' ] : $Arr_ServerConf[ 'dbGameDbName' ];
            $OBJ_DstDb = new MergeServer( $Arr_DstDbConfig );
            if( false === $OBJ_DstDb->bConnect )
            {
                $Arr_Result[ 'ErrorCode' ] = 6;
                $Arr_Result[ 'ErrorDesc' ] = urlencode( '目标数据库连接失败' );
            }
            else
            {
                $cRollBackDir = LOG_DOWNLOAD_PATH.DIRECTORY_SEPARATOR.'rollback' ;
                $cRollBackDir = 'admin' == $cDbType ? '' : $cRollBackDir ;
                $cTableKey    = '' ;
                $Arr_AdminRollbackSpecailKey = array() ;
                $Arr_GameRollbackSpecailKey  = array() ;
                require( SYSDIR_ADMIN_DICT.DIRECTORY_SEPARATOR.'merge_server.php' ) ;
                $cTableKey     = 'admin'== $cDbType ? $Arr_AdminRollbackSpecailKey[ $cTableName ] : $Arr_GameRollbackSpecailKey[ $cTableName ] ;
                $cTableKey     = NULL == $cTableKey ? 'id' : $cTableKey ;
                $bFirstRecords = false ;

                $bFirstRecords = 0 == $iOffsetStart ? true : $bFirstRecords ;

                $Arr_RollbackInfo                    = array() ;
                $Arr_RollbackInfo[ 'agentName' ]     = AGENT_NAME ;
                $Arr_RollbackInfo[ 'srcServerId' ]   = SERVER_ID ;
                $Arr_RollbackInfo[ 'dstServerId' ]   = $iDstServerId ;
                $szRollbackInfoJson  = json_encode( $Arr_RollbackInfo ) ;

                $bInsertData   = $OBJ_DstDb->addItemsToTableByMultiArray( $cTableName, $Arr_SrcData, $cRollBackDir,
                    $szRollbackInfoJson, $cTableKey, $bFirstRecords );
                if( false === $bInsertData )
                {
                    $Arr_Result[ 'ErrorCode' ] = 7;
                    $Arr_Result[ 'ErrorDesc' ] = urlencode( '表【'.$cTableName.'】复制数据失败' );
                }
            }
        }
    }
    else
    {
        $Arr_Result[ 'ErrorCode' ] = 4;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( "表ID[{$iTableId}]的表不存在于源服务器中" );
    }
    return $Arr_Result;
}

/**
 * backup db for server
 * @param void
 * @return void
 * @access public
 * @uses for url ajax backup db
 */
function backupDb()
{
    $nBackupServerId = GetUrlParam( 'serverId' );
    $Arr_Result = array();
    $Arr_Result[ 'ErrorCode' ] = 1;
    $Arr_Result[ 'ErrorDesc' ] = '';
    $iTimeStamp = time();
    $cCheckKey = md5( $iTimeStamp.GATEWAY_SYSTEM_AUTH_KEY );
    $Arr_AdminDB     = array();
    $Arr_GameDB      = array();
    if( 0 == $nBackupServerId )
    {
       // backup self
       $Arr_AdminDB[ 'host' ]     = DB_HOST;
       $Arr_AdminDB[ 'user' ]     = DB_USER;
       $Arr_AdminDB[ 'password' ] = DB_PASSWD;
       $Arr_AdminDB[ 'dbname' ]   = DB_NAME;
       $Arr_GameDB[ 'host' ]      = DB_GAME_HOST;
       $Arr_GameDB[ 'user' ]      = DB_GAME_USER;
       $Arr_GameDB[ 'password' ]  = DB_GAME_PASSWD;
       $Arr_GameDB[ 'dbname' ]    = DB_GAME_DB_NAME;
    }
    else
    {
        // backup db for dst server
        $cGetDstServerConfParams = '?action=getserverconf&key='.$cCheckKey.'&timeStamp='.$iTimeStamp."&serverId=".$nBackupServerId."&agentId=".AGENT_ID;
        $cGetDstServerConfResult = urldecode( @file_get_contents( GET_MERGE_API_URL.$cGetDstServerConfParams ) );
        $Arr_ResultConf = json_decode( $cGetDstServerConfResult,true );

        if ( !$Arr_ResultConf || 1 != $Arr_ResultConf['ErrorCode'])
        {
            $Arr_Result[ 'ErrorCode' ] = 2;
            $Arr_Result[ 'ErrorDesc' ] = $Arr_ResultConf['ErrorDesc'] ? $Arr_ResultConf['ErrorDesc'] : urlencode( '获取目标服务器信息失败!' );
            SprintJsonStrAndExit( $Arr_Result );
        }
        else
        {
            $Arr_ServerConf            = $Arr_ResultConf[ 'server' ];
            $Arr_AdminDB[ 'host' ]     = $Arr_ServerConf[ 'dbHost' ];
            $Arr_AdminDB[ 'user' ]     = $Arr_ServerConf[ 'dbUser' ];
            $Arr_AdminDB[ 'password' ] = $Arr_ServerConf[ 'dbPasswd' ];
            $Arr_AdminDB[ 'dbname' ]   = $Arr_ServerConf[ 'dbName' ];
            $Arr_GameDB[ 'host' ]      = $Arr_ServerConf[ 'dbGameHost' ];
            $Arr_GameDB[ 'user' ]      = $Arr_ServerConf[ 'dbGameUser' ];
            $Arr_GameDB[ 'password' ]  = $Arr_ServerConf[ 'dbGamePasswd' ];
            $Arr_GameDB[ 'dbname' ]    = $Arr_ServerConf[ 'dbGameDbName' ];
        }
    }

    $OBJ_AdminDB = new MergeServer( $Arr_AdminDB );
    if( false === $OBJ_AdminDB->bConnect )
    {
        $Arr_Result[ 'ErrorCode' ] = 3;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '连接后台数据库失败' );
        SprintJsonStrAndExit( $Arr_Result );
    }
    $OBJ_GameDB = new MergeServer( $Arr_GameDB );
    if( false === $OBJ_GameDB->bConnect )
    {
        $Arr_Result[ 'ErrorCode' ] = 4;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '连接游戏数据库失败' );
        SprintJsonStrAndExit( $Arr_Result );
    }
    $cCurrentServerNumber    = GetUrlParam( 'currentServerName' );
    $cBackupPath             = BACKUP_DB_DIR.DIRECTORY_SEPARATOR.$cCurrentServerNumber;
    if( false === $OBJ_AdminDB->dumpLinuxDb( $cBackupPath ) )
    {
        $Arr_Result[ 'ErrorCode' ] = 5;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '后台数据库备份失败' );
        SprintJsonStrAndExit( $Arr_Result );
    }
    if( false === $OBJ_GameDB->dumpLinuxDb( $cBackupPath ) )
    {
        $Arr_Result[ 'ErrorCode' ] = 6;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '游戏数据库备份失败' );
        SprintJsonStrAndExit( $Arr_Result );
    }
    print_r( json_encode( $Arr_Result ) );
}


/**
 * @desc 默认主方法
 * @param void
 * @return void
 */
function main()
{
    $cAction = 'main';
    $Arr_AdminDefaultNotMergeTable = array();
    $Arr_GameDefaultNotMergeTable = array();
    $Arr_ClearRoleDataTable = array() ;
    require_once ( SYSDIR_ADMIN_DICT.DIRECTORY_SEPARATOR.'merge_server.php' );
    $iTimeStamp = time();
    $cCheckKey = md5( $iTimeStamp.GATEWAY_SYSTEM_AUTH_KEY );
    $cGetAllNotMergeServersParams = "?action=getserversid&timeStamp={$iTimeStamp}&key={$cCheckKey}&agentId=".AGENT_ID;
    $cAllNotMergeServers = urldecode( @file_get_contents( GET_MERGE_API_URL.$cGetAllNotMergeServersParams ) );
    $Arr_Result = json_decode( $cAllNotMergeServers,true );

    if ( 1!=$Arr_Result['ErrorCode'] )
    {
        $Arr_Result['ErrorDesc'] = $Arr_Result['ErrorDesc'] ? $Arr_Result['ErrorDesc'] : '获取数据出错:可能无法连接游戏服务器!';
        $errormsg[] = $Arr_Result['ErrorDesc'];
    }
    else
    {
        '' == $Arr_Result[ 'ErrorDesc' ] ? $sucessmsg = '' : $sucessmsg[] = $Arr_Result[ 'ErrorDesc' ];
    }

    //get all not merge servers id
    $Arr_NotMergeServersId = array();
    $Arr_NotMergeServersId = $Arr_Result[ 'servers' ];

    if( count( array_intersect( $Arr_NotMergeServersId, array( intval( SERVER_ID ) ) ) ) > 0 )
    {
        $iSelfMerged = 0;
        //get all can merge servers id
        $Arr_DstCanMergeServer = array();
        $Arr_DstCanMergeServer = array_diff( $Arr_NotMergeServersId, array( intval( SERVER_ID ) ) );

        $Arr_AdminTable = GetUrlParam( 'adminTable' );
        $iAllAdminTables = intval( GetUrlParam( 'allAdminTables' ) );
        $Arr_GameTable = GetUrlParam( 'gameTable' );
        $iAllGameTables = intval( GetUrlParam( 'allGameTables' ) );
        $Arr_AdminTable = array();

        $Arr_SrcAdminDbConfig = array();
        $Arr_SrcAdminDbConfig[ 'host' ] = DB_HOST;
        $Arr_SrcAdminDbConfig[ 'user' ] = DB_USER;
        $Arr_SrcAdminDbConfig[ 'password' ] = DB_PASSWD;
        $Arr_SrcAdminDbConfig[ 'dbname' ] = DB_NAME;
        $OBJ_SrcAdminDb = new MergeServer( $Arr_SrcAdminDbConfig );
        $Arr_AdminTable = $OBJ_SrcAdminDb->getAllTables();

        $Arr_SrcGameDbConfig = array();
        $Arr_SrcGameDbConfig[ 'host' ] = DB_GAME_HOST;
        $Arr_SrcGameDbConfig[ 'user' ] = DB_GAME_USER;
        $Arr_SrcGameDbConfig[ 'password' ] = DB_GAME_PASSWD;
        $Arr_SrcGameDbConfig[ 'dbname' ] = DB_GAME_DB_NAME;
        $OBJ_SrcGameDb = new MergeServer( $Arr_SrcGameDbConfig );

        $Arr_GameTable = $OBJ_SrcGameDb->getAllTables();
        if (!$iAllAdminTables && empty( $iAllAdminTables ) && !$iAllGameTables)
        {
            $iAllAdminTables =1;
            $iAllGameTables = 1;
            //默认合区的表
            $Arr_AdminTableName = array_keys( array_diff( $Arr_AdminTable, $Arr_AdminDefaultNotMergeTable ) );
            $Arr_GameTableName = array_keys( array_diff( $Arr_GameTable, $Arr_GameDefaultNotMergeTable ) );
        }
        //开始合区，数据量太大会卡死
        if ( isPost() )
        {
            $Arr_AdminTableName = GetUrlParam( 'Arr_AdminTableName' );
            $Arr_GameTableName = GetUrlParam( 'Arr_GameTableName' );
            $iDstServerId = GetUrlParam( 'dstServerId' );
            $cGetDstServerConfParams = '?action=getserverconf&key='.$cCheckKey.'&timeStamp='.$iTimeStamp."&serverId=".$iDstServerId."&agentId=".AGENT_ID;
            $cGetDstServerConfResult = urldecode( @file_get_contents( GET_MERGE_API_URL.$cGetDstServerConfParams ) );
            $Arr_Result = json_decode( $cGetDstServerConfResult,true );

            if ( !$Arr_Result || 1 != $Arr_Result['ErrorCode'])
            {
                $Arr_Result['ErrorDesc'] = $Arr_Result['ErrorDesc'] ? $Arr_Result['ErrorDesc'] : '获取目标服务器信息失败!';
                $errormsg[] = $Arr_Result['ErrorDesc'];
            }
            else
            {
                $Arr_ServerConf = $Arr_Result[ 'server' ];
                $Arr_DstAdminDbConfig = array();
                $Arr_DstAdminDbConfig[ 'host' ] = $Arr_ServerConf[ 'dbHost' ];
                $Arr_DstAdminDbConfig[ 'user' ] = $Arr_ServerConf[ 'dbUser' ];
                $Arr_DstAdminDbConfig[ 'password' ] = $Arr_ServerConf[ 'dbPasswd' ];
                $Arr_DstAdminDbConfig[ 'dbname' ] = $Arr_ServerConf[ 'dbName' ];

                $Arr_DstGameDbConfig = array();
                $Arr_DstGameDbConfig[ 'host' ] = $Arr_ServerConf[ 'dbGameHost' ];
                $Arr_DstGameDbConfig[ 'user' ] = $Arr_ServerConf[ 'dbGameUser' ];
                $Arr_DstGameDbConfig[ 'password' ] = $Arr_ServerConf[ 'dbGamePasswd' ];
                $Arr_DstGameDbConfig[ 'dbname' ] = $Arr_ServerConf[ 'dbGameDbName' ];
                if( $Arr_DstAdminDbConfig[ 'host' ] == $Arr_SrcAdminDbConfig[ 'host' ] && $Arr_DstAdminDbConfig[ 'user' ] == $Arr_SrcAdminDbConfig[ 'user' ] )
                {
                    $errormsg[] = '对不起，目标连接后台数据库的用户和地址与源服务器相同，无法合区，请修改后继续';
                }

                if( $Arr_DstGameDbConfig[ 'host' ] == $Arr_SrcGameDbConfig[ 'host' ] && $Arr_DstGameDbConfig[ 'user' ] == $Arr_SrcGameDbConfig[ 'user' ] )
                {
                    $errormsg[] = '对不起，目标连接游戏数据库的用户和地址与源服务器相同，无法合区，请修改后继续';
                }

                $OBJ_DstAdminDb = new MergeServer( $Arr_DstAdminDbConfig );
                $OBJ_DstGameDb = new MergeServer( $Arr_DstGameDbConfig );
                if( false === $OBJ_DstAdminDb->bConnect ) $errormsg[] = '目标服务器后台数据库连接失败';
                if( false === $OBJ_DstGameDb->bConnect ) $errormsg[] = '目标服务器游戏数据库连接失败';

                if( !isset( $errormsg ) ) //not hava error then will run merge servers
                {
                    foreach ( $Arr_AdminTableName as $key => $cTableNameKey )
                    {
                        $cTableName = $Arr_AdminTable[ $cTableNameKey ];
                        $bMergeTable = $OBJ_DstAdminDb->addItemsToTableByMultiArray( $cTableName, $OBJ_SrcAdminDb->getAllItemOfTable( $cTableName ) );
                        if( 5 < $key ) break;
                        false === $bMergeTable ? $errormsg[] = '后台数据库：'.$cTableName.' 合并失败' : $sucessmsg[] = '后台数据库：'.$cTableName.' 合并成功';
                    }
                    foreach ( $Arr_GameTableName as $key => $cTableNameKey )
                    {
                        $cTableName = $Arr_GameTable[ $cTableNameKey ];
                        $bMergeTable = $OBJ_DstGameDb->addItemsToTableByMultiArray( $cTableName, $OBJ_SrcGameDb->getAllItemOfTable( $cTableName ) );
                        if( 2 < $key ) break;
                        false === $bMergeTable ? $errormsg[] = '游戏数据库：'.$cTableName.' 合并失败' : $sucessmsg[] = '游戏数据库：'.$cTableName.' 合并成功';
                    }
                    $OBJ_Log = new AdminLog();
                    $OBJ_Log->writeLog( AdminLog::LOG_TYPE_MERGE_SERVER, '源服务器：'.SERVER_ID.' 目标服务器：'.$iDstServerId );
                    $Arr_MergeServerLog = array();
                    $Arr_MergeServerLog[ 'serverId' ] = SERVER_ID;
                    $Arr_MergeServerLog[ 'agentId' ] = AGENT_ID;
                    $Arr_MergeServerLog[ 'mergeTo' ] = $iDstServerId;
                    $Arr_MergeServerLog[ 'mergeTime' ] = time();
                    $cMergeServerLog = base64_encode( json_encode( $Arr_MergeServerLog ) );
                    $cAddMergeServerLogParams = 'action=addlog&mergeLog='.$cMergeServerLog.'&key='.$cCheckKey.'&timeStamp='.$iTimeStamp;
                    $Arr_Result = json_decode( urldecode( curlPost( GET_MERGE_API_URL, $cAddMergeServerLogParams ) ), true );
                    if ( !$Arr_Result || 1 != $Arr_Result['ErrorCode'])
                    {
                        $Arr_Result['ErrorDesc'] = $Arr_Result['ErrorDesc'] ? $Arr_Result['ErrorDesc'] : '获取目标服务器信息失败!';
                        $errormsg[] = $Arr_Result['ErrorDesc'];
                    }
                    $sucessmsg[] = '执行成功！';
                }
            }
        }
        // -- backup msg
        $cCurrentServerNumber   = GetUrlParam( 'currentServerName' );
        $Arr_BackupSuccessMsg   = array();
        $Arr_BackupErrorMsg     = array();
        if( !file_exists( BACKUP_DB_DIR ) )
        {
            $bMkdirResult = @mkdir( BACKUP_DB_DIR, 0777 );
            if( !$bMkdirResult )
            {
                $Arr_BackupErrorMsg[] = '创建数据库备份目录<strong>'.BACKUP_DB_DIR.'</strong>失败';
            }
            else
            {
                $Arr_BackupErrorMsg[] = '当前服务器<strong>'.$cCurrentServerNumber.'</strong>未备份';
            }
        }
        else
        {
            if ( ! file_exists( BACKUP_DB_DIR.DIRECTORY_SEPARATOR.$cCurrentServerNumber ) )
            {
                $bMkdirResult = @mkdir( BACKUP_DB_DIR.DIRECTORY_SEPARATOR.$cCurrentServerNumber, 0777 );
                if( !$bMkdirResult )
                {
                    $Arr_BackupErrorMsg[] = '创建数据库备份目录<strong>'.BACKUP_DB_DIR.DIRECTORY_SEPARATOR.$cCurrentServerNumber.'</strong>失败';
                }
                else
                {
                    $Arr_BackupErrorMsg[] = '当前服务器<strong>'.$cCurrentServerNumber.'</strong>未备份';
                }
            }
            else
            {
                if ( !file_exists( BACKUP_DB_DIR.DIRECTORY_SEPARATOR.$cCurrentServerNumber.DIRECTORY_SEPARATOR.DB_NAME.'.sql' ) )
                {
                    $Arr_BackupErrorMsg[] = '当前服务器'.$cCurrentServerNumber.'数据库<strong>' .DB_NAME. '</strong>未备份';
                }
                else
                {
                    $iDbBackupTime = filectime( BACKUP_DB_DIR.DIRECTORY_SEPARATOR.$cCurrentServerNumber.DIRECTORY_SEPARATOR.DB_NAME.'.sql' ) ;
                    $Arr_BackupSuccessMsg[] = '当前服务器'.$cCurrentServerNumber.'数据库<strong>' .DB_NAME.
                        '</strong>已备份 --备份时间：' .date( 'Y-m-d H:i:s', $iDbBackupTime );
                }
                if ( !file_exists( BACKUP_DB_DIR.DIRECTORY_SEPARATOR.$cCurrentServerNumber.DIRECTORY_SEPARATOR.DB_GAME_DB_NAME.'.sql' ) )
                {
                    $Arr_BackupErrorMsg[] = '当前服务器'.$cCurrentServerNumber.'数据库<strong>' .DB_GAME_DB_NAME. '</strong>未备份';
                }
                else
                {
                    $iDbBackupTime = filectime( BACKUP_DB_DIR.DIRECTORY_SEPARATOR.$cCurrentServerNumber.DIRECTORY_SEPARATOR.DB_GAME_DB_NAME.'.sql' ) ;
                    $Arr_BackupSuccessMsg[] = '当前服务器'.$cCurrentServerNumber.'数据库<strong>' .DB_GAME_DB_NAME.
                        '</strong>已备份 --备份时间：' .date( 'Y-m-d H:i:s', $iDbBackupTime );
                }
            }
        }
    }
    else
    {
        $iSelfMerged = 1;
        $iTimeStamp = time();
        $cCheckKey = md5( $iTimeStamp.GATEWAY_SYSTEM_AUTH_KEY );
        $cGetMergeLogParams = "?action=getlog&timeStamp={$iTimeStamp}&key={$cCheckKey}&agentId=".AGENT_ID."&serverId=".SERVER_ID;
        $cMergeLog = urldecode( @file_get_contents( GET_MERGE_API_URL.$cGetMergeLogParams ) );

        $Arr_Result = json_decode( $cMergeLog,true );
        $Arr_MergeLog = $Arr_Result[ 'mergeLog' ];
        if ( 1 != $Arr_Result['ErrorCode'] )
        {
            $Arr_Result['ErrorDesc'] = $Arr_Result['ErrorDesc'] ? $Arr_Result['ErrorDesc'] : '获取数据出错:可能无法连接游戏服务器!';
            $errormsg[] = $Arr_Result['ErrorDesc'];
        }
        else
        {
            '' == $Arr_Result[ 'ErrorDesc' ] ? $sucessmsg = '' : $sucessmsg[] = $Arr_Result[ 'ErrorDesc' ];
        }
    }


    $data=array(
        'errorMsg'=>empty($errormsg) ? '' : implode('<br />',$errormsg),
        'sucessMsg' => empty($sucessmsg) ? '' : implode('<br />',$sucessmsg),
        'backupSuccessMsg' => empty( $Arr_BackupSuccessMsg ) ? '' : implode( '<br />', $Arr_BackupSuccessMsg ),
        'backupErrorMsg' => empty( $Arr_BackupErrorMsg ) ? '' : implode( '<br />', $Arr_BackupErrorMsg ),
        'GAME_NO' => GAME_NO,
        'AGENT_ID'=>AGENT_ID,
        'AGENT_NAME'=>AGENT_NAME,
        'SERVER_ID'=>SERVER_ID,
        'SERVER_NAME'=>SERVER_NAME,
        'Arr_AdminTable' => $Arr_AdminTable,
        'Arr_AdminTableName' => $Arr_AdminTableName,
        'iAllAdminTables' => $iAllAdminTables,
        'Arr_GameTable' => $Arr_GameTable,
        'Arr_GameTableName' => $Arr_GameTableName,
        'iAllGameTables' => $iAllGameTables,
        'Arr_DstCanMergeServer' => $Arr_DstCanMergeServer,
        'iSelfMerged' => $iSelfMerged,
        'Arr_MergeLog' => $Arr_MergeLog,
    	'szClearRoleDataTable' => '"'. implode( '","', $Arr_ClearRoleDataTable ). '"',
    );
    render('system/merge_servers.tpl',$data);
}

/**
 * @param void
 * @return void
 * @uses 检查拷贝数据表的正确性
 */
function checkCopyTable()
{
    $iTimeStamp = time();
    $cCheckKey = md5( $iTimeStamp.GATEWAY_SYSTEM_AUTH_KEY );
    $cGetAllNotMergeServersParams = "?action=getserversid&timeStamp={$iTimeStamp}&key={$cCheckKey}&agentId=".AGENT_ID;
    $cAllNotMergeServers = urldecode( @file_get_contents( GET_MERGE_API_URL.$cGetAllNotMergeServersParams ) );
    $Arr_Result = json_decode( $cAllNotMergeServers, true );

    if ( 1 != $Arr_Result['ErrorCode'] )
    {
        $Arr_Result['ErrorDesc'] = $Arr_Result['ErrorDesc'] ? $Arr_Result['ErrorDesc'] : urlencode( '获取数据出错:可能无法连接游戏服务器!' );
        SprintJsonStrAndExit( $Arr_Result );
    }

    //get all not merge servers id
    $Arr_NotMergeServersId = array();
    $Arr_NotMergeServersId = $Arr_Result[ 'servers' ];
    if( count( array_intersect( $Arr_NotMergeServersId, array( intval( SERVER_ID ) ) ) ) == 0 )
    {
        $cGetMergeLogParams = "?action=getlog&timeStamp={$iTimeStamp}&key={$cCheckKey}&agentId=".AGENT_ID."&serverId=".SERVER_ID;
        $cMergeLog = urldecode( @file_get_contents( GET_MERGE_API_URL.$cGetMergeLogParams ) );

        $Arr_Result = json_decode( $cMergeLog, true );
        $Arr_MergeLog = $Arr_Result[ 'mergeLog' ];
        if ( 1 != $Arr_Result['ErrorCode'] )
        {
            $Arr_Result['ErrorDesc'] = $Arr_Result['ErrorDesc'] ? urlencode( $Arr_Result['ErrorDesc'] ) : urlencode( '获取数据出错:可能无法连接游戏服务器!' );
            SprintJsonStrAndExit( $Arr_Result );
        }
        $Arr_Result['ErrorCode'] = 10;
        $Arr_Result['ErrorDesc'] = urlencode( '对不起，该区已合并到'.AGENT_NAME.'s'.$Arr_MergeLog[ 'mergeTo' ] );
        SprintJsonStrAndExit( $Arr_Result );
    }
}

/**
 * @param string $cDbType
 * @param string $cTableName
 * @param array  $Arr_Data
 * @return array
 */
function checkCopyTableData( $cDbType, $cTableName, $Arr_Data )
{
    $Arr_NotMergeField = array() ;
    $Arr_AdminDefaultNotMergeTableField = array() ;
    $Arr_GameDefaultNotMergeTableField  = array() ;
    require( SYSDIR_ADMIN_DICT.DIRECTORY_SEPARATOR.'merge_server.php' ) ;
    switch ( $cDbType )
    {
        case 'admin':
            $Arr_NotMergeField = $Arr_AdminDefaultNotMergeTableField[ $cTableName ] ;
            break ;
        case 'game':
            $Arr_NotMergeField = $Arr_GameDefaultNotMergeTableField[ $cTableName ] ;
            break ;
        default:
            $Arr_NotMergeField = array() ;
    }

    if ( 0 < count( $Arr_NotMergeField ) ) // reset the data
    {
        foreach ( $Arr_Data as $key => &$val )
        {
            foreach ( $val as $szFieldName => $mData )
            {
                if ( in_array( $szFieldName, $Arr_NotMergeField ) )
                {
                    unset( $val[ $szFieldName ] ) ;
                }
            }
        }
    }
    return $Arr_Data ;
}

/**
 * get the rollback info 获得回滚信息，输出JSON字符串，内容包括：源区、目标区、回滚记录数
 * @param void
 * @return void
 */
function getRollbackInfo()
{
    checkCopyTable() ;
    $Arr_Result = array() ;
    $Arr_Result[ 'ErrorCode' ] = 1 ;
    $Arr_Result[ 'ErrorDesc' ] = '' ;
    $szRollbackFileName = AGENT_NAME. 's'. SERVER_ID. '.txt' ;
    $szRollbackFilePath = LOG_DOWNLOAD_PATH.DIRECTORY_SEPARATOR. 'rollback' .DIRECTORY_SEPARATOR.$szRollbackFileName ;
    if ( !file_exists( $szRollbackFilePath ) )
    {
        $Arr_Result[ 'ErrorCode' ] = 20 ;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '服务器数据回滚文件【' .$szRollbackFileName. '】不存在' ) ;
        SprintJsonStrAndExit( $Arr_Result ) ;
    }
    $Arr_RollbackInfo = array() ;
    $Arr_RollbackInfo = json_decode( exec( 'sed -n "1p" ' .$szRollbackFilePath ), true ) ;
    $Arr_Result[ 'srcServerId' ] = $Arr_RollbackInfo[ 'srcServerId' ] ;
    $Arr_Result[ 'dstServerId' ] = $Arr_RollbackInfo[ 'dstServerId' ] ;
    $Arr_Result[ 'rollbackRecords' ] = exec( 'wc -l ' .$szRollbackFilePath. ' | awk \'{print $1}\'' ) - 1 ;
    print_r( json_encode( $Arr_Result ) ) ;
}

/**
 * run the rollback for server
 * @param void
 * @return void
 */
function runRollback()
{
    $cAction = 'runRollback' ;
    checkCopyTable() ;
    $Arr_Result = array() ;
    $Arr_Result[ 'ErrorCode' ] = 1 ;
    $Arr_Result[ 'ErrorDesc' ] = '' ;
    $iOnceRollbackRecords = GetUrlParam( 'onceRollbackRecords' ) ;
    $szRollbackFileName = AGENT_NAME. 's'. SERVER_ID. '.txt' ;
    if ( empty( $iOnceRollbackRecords ) )
    {
        $Arr_Result[ 'ErrorCode' ] = 25 ;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '参数丢失' ) ;
        SprintJsonStrAndExit( $Arr_Result ) ;
    }

    $szRollbackFilePath = LOG_DOWNLOAD_PATH.DIRECTORY_SEPARATOR. 'rollback' .DIRECTORY_SEPARATOR.$szRollbackFileName ;
    if ( !file_exists( $szRollbackFilePath ) )
    {
        $Arr_Result[ 'ErrorCode' ] = 20 ;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '服务器数据回滚文件【' .$szRollbackFileName. '】不存在' ) ;
        SprintJsonStrAndExit( $Arr_Result ) ;
    }

    $iRollbackRecords = exec( 'wc -l ' .$szRollbackFilePath. ' | awk \'{print $1}\'' ) ;
    if( 1 >= $iRollbackRecords )
    {
        $Arr_Result[ 'ErrorCode' ] = 21 ;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '回滚文件数据不足，无法回滚' ) ;
        SprintJsonStrAndExit( $Arr_Result ) ;
    }

    $iCurNeedRollbackRecords = 1 < $iRollbackRecords - $iOnceRollbackRecords ? $iOnceRollbackRecords : $iRollbackRecords - 1 ;
    $Arr_RollbackInfo = array() ;
    $Arr_RollbackInfo = json_decode( exec( 'sed -n "1p" ' .$szRollbackFilePath ), true ) ;
    $iDstServerId     = $Arr_RollbackInfo[ 'dstServerId' ] ;

    // connect the dst server
    $iTimeStamp = time();
    $cCheckKey = md5( $iTimeStamp.GATEWAY_SYSTEM_AUTH_KEY ) ;
    $cGetDstServerConfParams = '?action=getserverconf&key='.$cCheckKey.'&timeStamp='.$iTimeStamp."&serverId=".$iDstServerId."&agentId=".AGENT_ID ;
    $cGetDstServerConfResult = urldecode( @file_get_contents( GET_MERGE_API_URL.$cGetDstServerConfParams ) ) ;
    $Arr_ResultConf = json_decode( $cGetDstServerConfResult,true );

    if ( !$Arr_ResultConf || 1 != $Arr_ResultConf[ 'ErrorCode' ])
    {
        $Arr_Result[ 'ErrorCode' ] = 22 ;
        $Arr_Result[ 'ErrorDesc' ] = $Arr_ResultConf[ 'ErrorDesc' ] ? $Arr_ResultConf[ 'ErrorDesc' ] : urlencode( '获取目标服务器信息失败!' ) ;
    }
    else
    {
        $Arr_SrcData = array();
        $Arr_ServerConf = $Arr_ResultConf[ 'server' ] ;
        $Arr_DstDbConfig = array();
        $Arr_DstDbConfig[ 'host' ]        = $Arr_ServerConf[ 'dbGameHost' ] ;
        $Arr_DstDbConfig[ 'user' ]        = $Arr_ServerConf[ 'dbGameUser' ] ;
        $Arr_DstDbConfig[ 'password' ]    = $Arr_ServerConf[ 'dbGamePasswd' ] ;
        $Arr_DstDbConfig[ 'dbname' ]      = $Arr_ServerConf[ 'dbGameDbName' ] ;
        $OBJ_DstDb = new MergeServer( $Arr_DstDbConfig );
        if( false === $OBJ_DstDb->bConnect )
        {
            $Arr_Result[ 'ErrorCode' ] = 23;
            $Arr_Result[ 'ErrorDesc' ] = urlencode( '目标数据库连接失败' );
        }
        else
        {
            $bRollback = $OBJ_DstDb->rollbackDbData( $szRollbackFilePath, $iCurNeedRollbackRecords ) ;
            if ( false === $bRollback )
            {
                $Arr_Result[ 'ErrorCode' ] = 24 ;
                $Arr_Result[ 'ErrorDesc' ] = urlencode( '回滚数据失败' ) ;
            }
        }
    }
    print_r( json_encode( $Arr_Result ) ) ;
}

/**
 * truncate all need truncate tables for servers
 * @param void
 * @return void
 */
function truncateAllDefaultTables()
{
	$cAction = 'truncateDefaultTables' ;
    checkCopyTable() ;
    $Arr_Result = array() ;
    $Arr_Result[ 'ErrorCode' ] = 1 ;
    $Arr_Result[ 'ErrorDesc' ] = '' ;
    $iClearServer = intval( GetUrlParam( 'clearServer' ) ) ; // 0 then clear all servers( src and dst )
    $iDstServerId = intval( GetUrlParam( 'dstServerId' ) ) ;
    if ( ( 0 != $iClearServer && empty( $iClearServer ) ) || empty( $iDstServerId ) )
    {
        $Arr_Result[ 'ErrorCode' ] = 21 ;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '参数丢失' ) ;
        SprintJsonStrAndExit( $Arr_Result ) ;
    }
    $Arr_GameDefaultTruncateTable = array() ;
    require( SYSDIR_ADMIN_DICT.DIRECTORY_SEPARATOR.'merge_server.php' ) ;
    $bResult = true ;
    if ( 0 == $iClearServer || 1 == $iClearServer ) // srouce server
    {
        // connectd db
        $Arr_SrcDbConfig = array();
        $Arr_SrcDbConfig[ 'host' ]        = DB_GAME_HOST ;
        $Arr_SrcDbConfig[ 'user' ]        = DB_GAME_USER ;
        $Arr_SrcDbConfig[ 'password' ]    = DB_GAME_PASSWD ;
        $Arr_SrcDbConfig[ 'dbname' ]      = DB_GAME_DB_NAME ;
        $OBJ_SrcDb = new MergeServer( $Arr_SrcDbConfig ) ;
        foreach ( $Arr_GameDefaultTruncateTable as $k => $szTableName )
        {
            $bResult = $OBJ_SrcDb->truncateTable( $szTableName ) ;
            if ( false === $bResult )
            {
                $Arr_Result[ 'ErrorCode' ] = 22 ;
                $Arr_Result[ 'ErrorDesc' ] = urlencode( '源服务器清理清空表[' .$szTableName. ']发生错误' ) ;
                SprintJsonStrAndExit( $Arr_Result ) ;
            }
        }
    }

    if( 0 == $iClearServer || 2 == $iClearServer )
    {
        // connect the dst server
        $iTimeStamp = time();
        $cCheckKey = md5( $iTimeStamp.GATEWAY_SYSTEM_AUTH_KEY ) ;
        $cGetDstServerConfParams = '?action=getserverconf&key='.$cCheckKey.'&timeStamp='.$iTimeStamp."&serverId=".$iDstServerId."&agentId=".AGENT_ID ;
        $cGetDstServerConfResult = urldecode( @file_get_contents( GET_MERGE_API_URL.$cGetDstServerConfParams ) ) ;
        $Arr_ResultConf = json_decode( $cGetDstServerConfResult, true ) ;

        if ( !$Arr_ResultConf || 1 != $Arr_ResultConf[ 'ErrorCode' ])
        {
            $Arr_Result[ 'ErrorCode' ] = 23 ;
            $Arr_Result[ 'ErrorDesc' ] = $Arr_ResultConf[ 'ErrorDesc' ] ? $Arr_ResultConf[ 'ErrorDesc' ] : urlencode( '获取目标服务器信息失败!' ) ;
        }
        else
        {
            $Arr_SrcData = array();
            $Arr_ServerConf = $Arr_ResultConf[ 'server' ] ;
            $Arr_DstDbConfig = array();
            $Arr_DstDbConfig[ 'host' ]        = $Arr_ServerConf[ 'dbGameHost' ] ;
            $Arr_DstDbConfig[ 'user' ]        = $Arr_ServerConf[ 'dbGameUser' ] ;
            $Arr_DstDbConfig[ 'password' ]    = $Arr_ServerConf[ 'dbGamePasswd' ] ;
            $Arr_DstDbConfig[ 'dbname' ]      = $Arr_ServerConf[ 'dbGameDbName' ] ;
            $OBJ_DstDb = new MergeServer( $Arr_DstDbConfig );
            if( false === $OBJ_DstDb->bConnect )
            {
                $Arr_Result[ 'ErrorCode' ] = 24 ;
                $Arr_Result[ 'ErrorDesc' ] = urlencode( '目标数据库连接失败' ) ;
            }
            else
            {
                foreach ( $Arr_GameDefaultTruncateTable as $k => $szTableName )
                {
                    $bResult = $OBJ_DstDb->truncateTable( $szTableName ) ;
                    if ( false === $bResult )
                    {
                        $Arr_Result[ 'ErrorCode' ] = 25 ;
                        $Arr_Result[ 'ErrorDesc' ] = urlencode( '目标服务器清空表[' .$szTableName. ']时发生错误' ) ;
                        SprintJsonStrAndExit( $Arr_Result ) ;
                    }
                }
            }
        }
    }
    print_r( json_encode( $Arr_Result ) ) ;
}

/**
 * clear the role data where enough the conditions
 * @param void
 * @return void
 */
function clearRoleData()
{
	$cAction = 'clearRoleData' ;
    checkCopyTable() ;
    $Arr_Result = array() ;
    $Arr_Result[ 'ErrorCode' ] = 1 ;
    $Arr_Result[ 'ErrorDesc' ] = '' ;
    $iDstServerId    = intval( GetUrlParam( 'dstServerId' ) ) ; // if self then this value will be 0
    $szTableName     = GetUrlParam( 'tableName' ) ;
    $iMinRoleLevel   = intval( GetUrlParam( 'minRoleLevel' ) ) ;
    $bNotClearVip    = 1 == GetUrlParam( 'notClearVip' ) ? true : false ;
    $iMaxNotLoginDay = intval( GetUrlParam( 'maxNotLoginDay' ) ) ;
    if ( ( 0 != $iDstServerId && empty( $iDstServerId ) ) || empty( $iMinRoleLevel ) || empty( $iMaxNotLoginDay ) )
    {
        $Arr_Result[ 'ErrorCode' ] = 21 ;
        $Arr_Result[ 'ErrorDesc' ] = urlencode( '参数丢失' ) ;
        SprintJsonStrAndExit( $Arr_Result ) ;
    }
    $Arr_ClearRoleDataTableSpecialKey = array() ;
    $Arr_ClearCompletedDoSql          = array() ;
    require( SYSDIR_ADMIN_DICT.DIRECTORY_SEPARATOR.'merge_server.php' ) ;
    $bResult = true ;
    if ( 0 == $iDstServerId ) // srouce server
    {
        // connectd db
        $Arr_SrcDbConfig = array();
        $Arr_SrcDbConfig[ 'host' ]        = DB_GAME_HOST ;
        $Arr_SrcDbConfig[ 'user' ]        = DB_GAME_USER ;
        $Arr_SrcDbConfig[ 'password' ]    = DB_GAME_PASSWD ;
        $Arr_SrcDbConfig[ 'dbname' ]      = DB_GAME_DB_NAME ;
        $OBJ_SrcDb = new MergeServer( $Arr_SrcDbConfig ) ;
        $szRoleId = array_key_exists( $szTableName, $Arr_ClearRoleDataTableSpecialKey ) ?
            $Arr_ClearRoleDataTableSpecialKey[ $szTableName ] : 'id' ;
        if ( !$OBJ_SrcDb->clearRoleData( $szTableName, $szRoleId, $iMinRoleLevel, $bNotClearVip, $iMaxNotLoginDay ) )
        {
            $Arr_Result[ 'ErrorCode' ] = 22 ;
            $Arr_Result[ 'ErrorDesc' ] = urlencode( '清理源服务器数据表[' .$szTableName. ']时发生错误' ) ;
            SprintJsonStrAndExit( $Arr_Result ) ;
        }
        if( 'PLAYER_TBL' == $szTableName )
        {
        	foreach ( $Arr_ClearCompletedDoSql as $k => $sql_str )
        	{
        		$OBJ_SrcDb->query( $sql_str ) ;
        	}
        }
    }
    else
    {
        // connect the dst server
        $iTimeStamp = time();
        $cCheckKey = md5( $iTimeStamp.GATEWAY_SYSTEM_AUTH_KEY ) ;
        $cGetDstServerConfParams = '?action=getserverconf&key='.$cCheckKey.'&timeStamp='.$iTimeStamp."&serverId=".$iDstServerId."&agentId=".AGENT_ID ;
        $cGetDstServerConfResult = urldecode( @file_get_contents( GET_MERGE_API_URL.$cGetDstServerConfParams ) ) ;
        $Arr_ResultConf = json_decode( $cGetDstServerConfResult, true ) ;

        if ( !$Arr_ResultConf || 1 != $Arr_ResultConf[ 'ErrorCode' ])
        {
            $Arr_Result[ 'ErrorCode' ] = 23 ;
            $Arr_Result[ 'ErrorDesc' ] = $Arr_ResultConf[ 'ErrorDesc' ] ? $Arr_ResultConf[ 'ErrorDesc' ] : urlencode( '获取目标服务器信息失败!' ) ;
        }
        else
        {
            $Arr_SrcData = array();
            $Arr_ServerConf = $Arr_ResultConf[ 'server' ] ;
            $Arr_DstDbConfig = array();
            $Arr_DstDbConfig[ 'host' ]        = $Arr_ServerConf[ 'dbGameHost' ] ;
            $Arr_DstDbConfig[ 'user' ]        = $Arr_ServerConf[ 'dbGameUser' ] ;
            $Arr_DstDbConfig[ 'password' ]    = $Arr_ServerConf[ 'dbGamePasswd' ] ;
            $Arr_DstDbConfig[ 'dbname' ]      = $Arr_ServerConf[ 'dbGameDbName' ] ;
            $OBJ_DstDb = new MergeServer( $Arr_DstDbConfig );
            if( false === $OBJ_DstDb->bConnect )
            {
                $Arr_Result[ 'ErrorCode' ] = 24 ;
                $Arr_Result[ 'ErrorDesc' ] = urlencode( '目标数据库连接失败' ) ;
            }
            else
            {
                $szRoleId = array_key_exists( $szTableName, $Arr_ClearRoleDataTableSpecialKey ) ?
                    $Arr_ClearRoleDataTableSpecialKey[ $szTableName ] : 'id' ;
                if ( !$OBJ_DstDb->clearRoleData( $szTableName, $szRoleId, $iMinRoleLevel, $bNotClearVip, $iMaxNotLoginDay ) )
                {
                    $Arr_Result[ 'ErrorCode' ] = 25 ;
                    $Arr_Result[ 'ErrorDesc' ] = urlencode( '清理目标服务器数据表[' .$szTableName. ']时发生错误' ) ;
                    SprintJsonStrAndExit( $Arr_Result ) ;
                }
                if( 'PLAYER_TBL' == $szTableName )
                {
                	foreach ( $Arr_ClearCompletedDoSql as $k => $sql_str )
                	{
                	    $OBJ_DstDb->query( $sql_str ) ;
                	}
                }
            }
        }
    }
    print_r( json_encode( $Arr_Result ) ) ;
}