<?php
/**
 * @author shuiyuandan@4399.com
 * @Created  Wed Dec 21 03:26:23 GMT 2011
 * @desc 给玩家送元宝
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';
include_once SYSDIR_ADMIN_INCLUDE.'/functions.php';

$interval = $_POST['interval'];
$times = $_POST['times'];
$content = $_POST['content'];

//公告条数
$CONTENT_MAX_COUNT = 10;
//前端的分隔符
$CONTENT_DELIMITER = "\r\n";
//游戏服务器所需的分隔符
$SERVER_DELIMITER = " ";

if( isPost() )
{
    $msg = array();
    
    if( !$interval || !intval( $interval ) ) {
        $msg[] = "请填写间隔";
    }
    if( !$times || !intval( $times ) ) {
        $msg[] = "请填写次数";
    }
    
    if( !$content ) {
        $msg[] = "请填写公告内容";
    }else{
    	trimString( $content );
    	$conAry = explode($CONTENT_DELIMITER, $content);
    	trimArray( $conAry );
    	if( count($conAry)>$CONTENT_MAX_COUNT ){
    		$msg[] = "公告超限，最多".$CONTENT_MAX_COUNT."条";
    	}
    }
    

    
    
    if ( empty( $msg ) ) {
    	$contentStr = implode($SERVER_DELIMITER,$conAry);
        $detailLog = "次数: $times;间隔: $interval秒; 内容: $contentStr";
        $api = new ServerApi();
        $result = $api->sendAnnounce( $interval, $times, $contentStr );
        if (1==$result['result']) {
            $msg[] = '系统公告发送成功!';
            AdminLog::writeLog(AdminLog::LOG_TYPE_SEND_ANNOUNCE, $detailLog );
        }else {
            $msg[] = '发送失败!原因:'.$result['errorMsg'];
        }
    }
}

$strMsg = empty($msg) ? '' : implode('<br />', $msg);

$data = array(
    'interval'=>$interval,
    'times'=>$times,
    'content'=>$content,
    'strMsg'=>$strMsg,
);
render('system/sys_announce.tpl',&$data);
