<?php
/**
 * @author shuiyuandan@4399.com
 * @Created  Wed Dec 21 03:26:23 GMT 2011
 * @desc 给玩家送元宝
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/server_api.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';
include_once SYSDIR_ADMIN_INCLUDE.'/functions.php';

$content_len_limit = 260;

$action = $_GET['action'];

if( isPost() )
{
	
	$msg = array();
	
	if($action == "add"){
		
		$interval = $_POST['interval'];
		$start_time = trim( $_POST['start_time'] );
		$end_time = trim( $_POST['end_time'] );
		$content = trim( $_POST['content'] );
		$link    = trim( $_POST['link'] );
		
		if( empty($link) ) {
			$link = "";
		}
	
	    if( !$interval || !intval( $interval ) ) {
	        $msg[] = "请填写间隔";
	    }
	    if( strlen( $start_time ) <= 0 or strlen( $end_time ) <= 0 ) {
	        $msg[] = "日期格式不正确";
	    }else
	    {
			list($year,$month,$left) = explode("-", $_POST['start_time']);
			list($day,$left) = explode(" ", $left);
			list($hour,$minute,$sec) = explode(":", $left);    
			$start_tick = mktime($hour, $minute, $sec, $month, $day, $year);	
			
			list($year,$month,$left) = explode("-", $_POST['end_time']);
			list($day,$left) = explode(" ", $left);
			list($hour,$minute,$sec) = explode(":", $left);    
			$end_tick = mktime($hour, $minute, $sec, $month, $day, $year);	
	    }
	    
	    if( $start_tick >= $end_tick ) {
	    	$msg[] = "日期格式不正确";
	    }
	    
	    if( !$content || strlen( $content ) > $content_len_limit ) {
	        $msg[] = "公告内容超出限制";
	    }
		
		if( $link && strlen( $link ) > $content_len_limit ) {
	        $msg[] = "链接内容非法";
	    }
	
		if( empty( $msg ) ) {
			$api = new ServerApi();
			$result = $api->addLoopAn( $start_tick, $end_tick, $interval, $content, $link );
			if (1==$result['result']) {
	            $msg[] = '循环公告添加成功!';
	            $detailLog = "startTime:".$start_time."=>".$end_time."; interval: ".$interval." content: ".$content." link: ".$link;
	            AdminLog::writeLog(AdminLog::LOG_TYPE_LOOP_AN_ADD, $detailLog );
	        }else {
	            $msg[] = '发送失败!原因:'.$result['errorMsg'];
	        }
	    }
	}// if action equal add
}

if( $_GET && $action == "del" ) {
	$id = $_GET['id'];
	$api = new ServerApi();
	$result = $api->delLoopAn( $id );
	if (1==$result['result']) {
        $msg[] = '循环公告删除成功!';
        $detailLog = "删除公告 id: ".$id;
        AdminLog::writeLog(AdminLog::LOG_TYPE_LOOP_AN_DEL, $detailLog );
    }else {
        $msg[] = '发送失败!原因:'.$result['errorMsg'];
    }
}

//组装公告列表
if( empty($api) ) $api = new ServerApi();
$ret = $api->getLoopAnList();
if (!empty($ret['data']) && is_array($ret['data'])) {
	$list = $ret['data'];
}

$strMsg = empty($msg) ? '' : implode('<br />', $msg);

$data = array(
    'start_time'=>$start_time,
    'end_time'=>$end_time,
    'interval'=>$interval,
    'link'=>$link,
    'content'=>$content,
    'strMsg'=>$strMsg,
    'list' => &$list,
);
render('system/sys_loop_announce.tpl',&$data);
