<?php
/**
 * @author linruirong@4399.com
 * @Created  Thu Dec 08 02:46:28 GMT 2011
 * @desc 用于发送GM指令
 */
require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';
include_once SYSDIR_ADMIN_CLASS.'/socket_client.php';

$msg = array();
if (isPost()) {
	$params = trim(stripslashes($_POST['params']));
	if (!$params) {
		$msg[] = '参数不能为空！';
	}else {
		$socketData = array(
			'cmd' => $params,
		);
		$socket = new SocketClient();
		$ret = $socket->rpc(SOCKET_GM_CMD,$socketData);
		if (1 == $ret['result']) {
			$msg[] = '操作成功！描述：'.$ret['data'];
		}else {
			$msg[] = '操作失败！原因：'.$ret['errorMsg'];
		}
	}
}
$data = array(
	'strMsg' => empty($msg) ? '' : implode('<br />',$msg),
	'params'=>$params,
	'ret'=>json_encode($ret),
);
render('system/gm_order.tpl',$data);
