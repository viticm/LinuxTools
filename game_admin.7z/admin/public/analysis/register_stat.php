<?php
/**
 * @author linruirong@4399.com
 * @Created  Thu Dec 15 13:50:45 GMT 2011
 * @desc 注册数据统计
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$dateStart = SS($_POST['dateStart']);
$dateEnd = SS($_POST['dateEnd']);
$dateStart = $dateStart ? $dateStart : date('Y-m-d',strtotime('-1month'));
$dateEnd = $dateEnd ? $dateEnd : date("Y-m-d");
$dateStartTamp = strtotime($dateStart);
$dateEndTamp = strtotime($dateEnd);

$sqlReg    = "SELECT COUNT(DISTINCT roleId) AS roleCnt,mYear, mMonth, mDate,mHour FROM t_log_register where mDateTime>={$dateStartTamp} and mDateTime<={$dateEndTamp} GROUP BY mYear, mMonth, mDate,mHour WITH ROLLUP" ;
$sqlAccess = "SELECT COUNT(DISTINCT accountName) AS accountCnt,mYear, mMonth, mDate,mHour FROM t_log_access where mDateTime>={$dateStartTamp} and mDateTime<={$dateEndTamp}  GROUP BY mYear, mMonth, mDate,mHour WITH ROLLUP" ;
$rsReg = fetchRowSet($sqlReg);
$rsAccess  = fetchRowSet($sqlAccess);

$result = array();
foreach ($rsAccess as $a) {
	$key = $a['mYear'].$a['mMonth'].$a['mDate'].$a['mHour'];
	$key = $key ? $key : 'all';
	$result[$key]['mYear']  = $a['mYear'];
	$result[$key]['mMonth'] = $a['mMonth'];
	$result[$key]['mDate']  = $a['mDate'];
	$result[$key]['mHour']  = $a['mHour'];
	$result[$key]['access'] = $a['accountCnt'];
}
foreach ($rsReg as $r) {
	$key = $r['mYear'].$r['mMonth'].$r['mDate'].$r['mHour'];
	$key = $key ? $key : 'all';
	if ($result[$key]) {
		$result[$key]['mYear']  = $r['mYear'];
		$result[$key]['mMonth'] = $r['mMonth'];
		$result[$key]['mDate']  = $r['mDate'];
		$result[$key]['mHour']  = $r['mHour'];
		$result[$key]['reg']    = $r['roleCnt'];
		$result[$key]['lostRate']    = $result[$key]['access'] > 0 ? round(($result[$key]['access']-$r['roleCnt'])*100/$result[$key]['access'],2) : 0;
	}
}

$data = array(
	'dateStart' => &$dateStart,
	'dateEnd' => &$dateEnd,
	'result' => &$result,
);
render('analysis/register_stat.tpl',$data);