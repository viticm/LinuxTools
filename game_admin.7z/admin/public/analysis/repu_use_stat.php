<?php
/**
 * $Id repu_use_stat.php
 * @uses to view the repu use status
 * @author viticm<dhuchuanpd@gmail.com>
 * @date 2013-6-25
 */
// this anslysis does not make sense
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_DICT.'/dict.php';
include_once SYSDIR_ADMIN_DICT.'/repu_type.php';
include_once SYSDIR_ADMIN_DICT.'/goods.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStart = $dateStartStamp ? date('Y-m-d',$dateStartStamp) : date('Y-m-d',strtotime('-6day'));
$dateEnd = $dateEndStamp ? date('Y-m-d',$dateEndStamp) : date('Y-m-d');
$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);

//===============start 查角色==============//
$role = $_POST['role'];
$msg = array();
if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	if (!$role['roleId']) {
		$msg[] = '找不到对应玩家';
	}
}
//===============end 查角色===============//

$where  = " where `mDateTime`>={$dateStartStamp} and `mDateTime` <= {$dateEndStamp} ";
$where .= $role['roleId'] ? " and roleId = {$role['roleId']} ":'';

//===========查出符合条件的数据=======
$sql = " select `mType` , sum(`amount`) as repu, 0 as bindRepu,  count(*) as cnt, sum(`amount`) as totalAmount
         from t_log_repu {$where}  group by `mType` ";
$rs = fetchRowSet($sql);
//=================================

$consume = array(); //系统获得(玩家失去)
$get = array(); //系统失去(玩家获得)
$circulateConsume = array(); //(玩家交易失去)
$circulateGet = array();//(玩家交易获得)
$consumeRepu = 0;
$consumeBindRepu = 0;
$consumeAllRepu = 0;
$getRepu = 0;
$getBindRepu = 0;
$getAllRepu = 0;
$circulateConsumeRepu = 0;
$circulateConsumeBindRepu = 0;
$circulateConsumeAllRepu = 0;
$circulateGetRepu = 0;
$circulateGetBindRepu = 0;
$circulateGetAllRepu = 0;

foreach ( $rs as &$row )
{
	if (!$dictRepuType[$row['mType']]) {
		continue;
	}
	$row['sumRepu'] =  $row['repu']+$row['bindRepu'];
	$row['mTypeText'] = $dictRepuType[$row['mType']];
	if ($row['mType']>=10000 && $row['mType']<=19999 ) {
		$get[] = $row;
		$getRepu += $row['repu'];
		$getBindRepu += $row['bindRepu'];
		$getAllRepu += $row['sumRepu'] ;
	}elseif ($row['mType']>=20000 && $row['mType']<=29999 ) {
		$consume[] = $row;
		$consumeRepu += $row['repu'];
		$consumeBindRepu += $row['bindRepu'];
		$consumeAllRepu += $row['sumRepu'] ;
	}elseif ($row['mType']>=70000 && $row['mType']<=79999 ) {
		$circulateConsume[] = $row;
		$circulateConsumeRepu = +$row['repu'];
		$circulateConsumeBindRepu += $row['bindRepu'];
		$circulateConsumeAllRepu += $row['sumRepu'] ;
	}elseif ($row['mType']>=80000 && $row['mType']<=89999 ) {
		$circulateGet[] = $row;
		$circulateGetRepu += $row['repu'];
		$circulateGetBindRepu += $row['bindRepu'];
		$circulateGetAllRepu += $row['sumRepu'] ;
	}
}

foreach ( $consume as &$consumeRow )
{
	$consumeRow['sumRepuRate'] =  $consumeAllRepu > 0 ? round($consumeRow['sumRepu'] * 100 / $consumeAllRepu,2) :0 ;
	$consumeRow['repuRate']    =  $consumeRepu > 0 ? round($consumeRow['repu'] * 100 / $consumeRepu,2) :0 ;
	$consumeRow['bindRepuRate']  =  $consumeBindRepu > 0 ? round($consumeRow['bindRepu'] * 100 / $consumeBindRepu,2) :0 ;
}

foreach ( $get as &$getRow )
{
	$getRow['sumRepuRate'] =  $getAllRepu > 0 ? round($getRow['sumRepu'] * 100 / $getAllRepu,2) :0 ;
	$getRow['repuRate']    =  $getRepu > 0 ? round($getRow['repu'] * 100 / $getRepu,2) :0 ;
	$getRow['bindRepuRate']  =  $getBindRepu > 0 ? round($getRow['bindRepu'] * 100 / $getBindRepu,2) :0 ;
}

foreach ( $circulateConsume as &$circulateConsumeRow )
{
	$circulateConsumeRow['sumRepuRate'] =  $circulateConsumeAllRepu > 0 ? round($circulateConsumeRow['sumRepu'] * 100 / $circulateConsumeAllRepu,2) :0 ;
	$circulateConsumeRow['repuRate']    =  $circulateConsumeRepu > 0 ? round($circulateConsumeRow['repu'] * 100 / $circulateConsumeRepu,2) :0 ;
	$circulateConsumeRow['bindRepuRate']  =  $circulateConsumeBindRepu > 0 ? round($circulateConsumeRow['bindRepu'] * 100 / $circulateConsumeBindRepu,2) :0 ;
}

foreach ($circulateGet as &$circulateGetRow)
{
	$circulateGetRow['sumRepuRate'] =  $circulateGetAllRepu > 0 ? round($circulateGetRow['sumRepu'] * 100 / $circulateGetAllRepu,2) :0 ;
	$circulateGetRow['repuRate']    =  $circulateGetRepu > 0 ? round($circulateGetRow['repu'] * 100 / $circulateGetRepu,2) :0 ;
	$circulateGetRow['bindRepuRate']  =  $circulateGetBindRepu > 0 ? round($circulateGetRow['bindRepu'] * 100 / $circulateGetBindRepu,2) :0 ;
}

$data = array(
	'dateStart'                      => &$dateStart                    ,
	'dateEnd'                        => &$dateEnd                      ,
	'role'                           => &$role                         ,
	'consume'                        => &$consume                      ,
	'get'                            => &$get                          ,
	'circulateConsume'               => &$circulateConsume             ,
	'circulateGet'                   => &$circulateGet                 ,
	'consumeRepu'                    => &$consumeRepu                  ,
	'consumeBindRepu'                => &$consumeBindRepu              ,
	'consumeAllRepu'                 => &$consumeAllRepu               ,
	'getRepu'                        => &$getRepu                      ,
	'getBindRepu'                    => &$getBindRepu                  ,
	'getAllRepu'                     => &$getAllRepu                   ,
	'circulateConsumeRepu'           => &$circulateConsumeRepu         ,
	'circulateConsumeBindRepu'       => &$circulateConsumeBindRepu     ,
	'circulateConsumeAllRepu'        => &$circulateConsumeAllRepu      ,
	'circulateGetRepu'               => &$circulateGetRepu             ,
	'circulateGetBindRepu'           => &$circulateGetBindRepu         ,
	'circulateGetAllRepu'            => &$circulateGetAllRepu          ,
	'msg'                            => empty( $msg ) ? '' : implode( '<br>', $msg ) ,
);
render('analysis/repu_use_stat.tpl',&$data);
