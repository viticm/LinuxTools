<?php

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$GAME_MIN_LEVEL = 1;
$GAME_MAX_LEVEL = 250;
$minGuideStep = intval( $_POST['minGuideStep'] );
$maxGuideStep = intval( $_POST['maxGuideStep'] );
$minGuideStep = $minGuideStep && $minGuideStep >= $GAME_MIN_LEVEL ? $minGuideStep : $GAME_MIN_LEVEL ;
$maxGuideStep = $maxGuideStep && $maxGuideStep <= $GAME_MAX_LEVEL ? $maxGuideStep : $GAME_MAX_LEVEL ;

$szPlayerTbl = 'PLAYER_TBL';

$szSqlGuideCount =" SELECT `guide_step` AS `step`, COUNT( `id` ) AS `roleCnt`  FROM {$szPlayerTbl}
    WHERE ( `guide_step` >= {$minGuideStep} AND `guide_step` <= {$maxGuideStep} ) OR `guide_step` = 10000
    GROUP BY `guide_step`"; // 10000 is the special step

$Arr_GuideCount = GFetchRowSet( $szSqlGuideCount );

$Arr_Result = array();
for( $i = $minGuideStep; $i <= $maxGuideStep; $i ++ )
{
    $Arr_Result[ $i ] = 0;
}
$iMaxCount = 0;

foreach ( $Arr_GuideCount as &$row) {
	$Arr_Result[ $row[ 'step' ] ] = $row[ 'roleCnt' ];
	$iMaxCount = $row[ 'roleCnt' ] > $iMaxCount ? $row[ 'roleCnt' ] : $iMaxCount;
}

$data = array(
	'arrResult'=> $Arr_Result,
	'maxCnt'=> $iMaxCount,
	'minGuideStep' => $minGuideStep,
	'maxGuideStep' => $maxGuideStep,
);
render('analysis/player_guide_step.tpl',$data);
exit();
