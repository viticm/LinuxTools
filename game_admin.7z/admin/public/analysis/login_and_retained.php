<?php
/**
 * game admin website
 * @link duchuanpd@gmail.com
 * @copyright Copyright (c) 2012-2013 Gzpd.(www.gzpindian.com)
 * @license none
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$iServerOnlineTime = strtotime(SERVER_ONLINE_DATE);
$iYestoday = strtotime(date('Y-m-d',strtotime('-1day')));

$iTmpStartTime = strtotime($_POST['dateStart']);
$iTmpEndTime = strtotime($_POST['dateEnd']);
$iStartTime = $iTmpStartTime ? $iTmpStartTime  : strtotime(date('Y-m-d',strtotime('-7day')));
$iStartTime = $iStartTime <= $iServerOnlineTime ? $iServerOnlineTime : $iStartTime;
$iEndTime = !$iTmpEndTime || $iTmpEndTime > $iYestoday ? $iYestoday : $iTmpEndTime;
$iEndTime = $iEndTime < $iStartTime ? $iStartTime : $iEndTime;
$cDateStart = date( 'Y-m-d', $iStartTime );
$cDateEnd = date( 'Y-m-d', $iEndTime );
$iOneDaySeconds = 24 * 60 * 60;

//login and retained count will be expand over one day
$iEndTime += $iOneDaySeconds;

$Arr_Login = array();
//find all login count user in the interval date
$cSqlStr = '';
$cSqlStr .= "SELECT DISTINCT `roleId`, `loginDate`  from `t_log_logout` where `loginDate` >= {$iStartTime} and `loginDate` <= {$iEndTime}
					GROUP BY `loginDate`,`roleId` ORDER BY `loginDate` ASC";
$Arr_Login = fetchRowSet( $cSqlStr );
//find all new login from the date
$Arr_NewLogin = array();
$cSqlStr = '';
$cSqlStr .= 'SELECT DISTINCT `roleId`, `mDateTime` as `loginDate` from `t_log_register`';
$cSqlStr .= ' where `mDateTime` >= '.$iStartTime.' and `mDateTime` <= '.$iEndTime;
$cSqlStr .= ' GROUP BY `loginDate`,`roleId` ORDER BY `loginDate` ASC';

$Arr_NewLogin = fetchRowSet( $cSqlStr );

//get the all login id list and new login id list
$iLoginTime = $iStartTime;
$Arr_LoginIdList = array();
$Arr_NewLoginIdList = array();
while( $iLoginTime <= $iEndTime )
{
	$Arr_LoginIdList[ $iLoginTime ] = array();
	$Arr_NewLoginIdList[ $iLoginTime ] = array();
	foreach ( $Arr_Login as $key => $value )
	{
		if ( $iLoginTime == $value[ 'loginDate' ] )
		{
			array_push( $Arr_LoginIdList[ $iLoginTime ] , $value[ 'roleId' ] );
		}
	}
	foreach ( $Arr_NewLogin as $key => $value )
	{
		if ( $iLoginTime == $value[ 'loginDate' ] )
		{
			array_push( $Arr_NewLoginIdList[ $iLoginTime ], $value[ 'roleId' ] );
		}
	}
	$iLoginTime += $iOneDaySeconds;
}

//get login and retained array
// the result will reset the time to post
$iEndTime -= $iOneDaySeconds;
$Arr_LoginAndRetained = array();
$iLoginTime = $iStartTime;
while( $iLoginTime <= $iEndTime )
{
	$Arr_LoginAndRetained[ $iLoginTime ] = array();
	$Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ] = count( $Arr_LoginIdList[ $iLoginTime ] );
	$Arr_LoginAndRetained[ $iLoginTime ][ 'newLoginCount' ] = count( $Arr_NewLoginIdList[ $iLoginTime ] ) ;
	$iOneDayNewRetained = 0;
	if ( true === is_array( $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds ] ) )
	    $iOneDayNewRetained = count( array_intersect( $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds ], $Arr_NewLoginIdList[ $iLoginTime  ] ) );
	$Arr_LoginAndRetained[ $iLoginTime ][ 'oneDayNewRetained' ] = $iOneDayNewRetained;
	$fOneDayRetainedProportion = $Arr_LoginAndRetained[ $iLoginTime ][ 'newLoginCount' ] == 0 ? 0 : $iOneDayNewRetained /
	    $Arr_LoginAndRetained[ $iLoginTime ][ 'newLoginCount' ];
	$Arr_LoginAndRetained[ $iLoginTime ][ 'oneDayNewRetainedProportion' ] = $fOneDayRetainedProportion * 100;

	//get the 1、3、7 retained and proportion
	$iOneDayRetained = 0;
	if ( true === is_array( $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds ] ) )
	    $iOneDayRetained = count( array_intersect( $Arr_LoginIdList[ $iLoginTime ], $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds ] ) );
	$Arr_LoginAndRetained[ $iLoginTime ][ 'oneDayRetained' ] = $iOneDayRetained;
	$fOneDayRetainedProportion = 0 == $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ] ?
	    0 : $iOneDayRetained / $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ];
	$Arr_LoginAndRetained[ $iLoginTime ][ 'oneDayRetainedProportion' ] = $fOneDayRetainedProportion * 100;

	$iThreeDayRetained = 0;
	if ( true == is_array( $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds * 3 ] ) )
	    $iThreeDayRetained = count( array_intersect( $Arr_LoginIdList[ $iLoginTime ], $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds * 3 ] ) );
	$Arr_LoginAndRetained[ $iLoginTime ][ 'threeDayRetained' ] = $iThreeDayRetained;
	$fThreeDayRetainedProportion = 0 == $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ] ?
	    0 : $iThreeDayRetained / $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ];
	$Arr_LoginAndRetained[ $iLoginTime ][ 'threeDayRetainedProportion' ] = $fThreeDayRetainedProportion * 100;

	$iSevenDayRetained = 0;
    if ( true == is_array( $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds * 7 ] ) )
	    $iSevenDayRetained = count( array_intersect( $Arr_LoginIdList[ $iLoginTime ], $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds * 7 ] ) );
	$Arr_LoginAndRetained[ $iLoginTime ][ 'sevenDayRetained' ] = $iSevenDayRetained;
	$fSevenDayRetainedProportion = 0 == $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ] ?
	    0 : $iSevenDayRetained / $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ];
	$Arr_LoginAndRetained[ $iLoginTime ][ 'sevenDayRetainedProportion' ] = $fSevenDayRetainedProportion * 100;

	/*add one day seconds*/
	$iLoginTime += $iOneDaySeconds;
}
//reset yesterday retained
$Arr_LoginAndRetained[ $iYestoday ][ 'oneDayNewRetained' ] = 0;
$Arr_LoginAndRetained[ $iYestoday ][ 'oneDayNewRetainedProportion' ] = 0 * 100;
$Arr_LoginAndRetained[ $iYestoday ][ 'oneDayRetained' ] = 0;
$Arr_LoginAndRetained[ $iYestoday ][ 'oneDayRetainedProportion' ] = 0 * 100;

$Arr_LoginAndRetainedAmount = array();
$Arr_LoginAndRetainedAmount[ 'totalLogin' ] = 0;
$Arr_LoginAndRetainedAmount[ 'totalNewLogin' ] = 0;
$Arr_LoginAndRetainedAmount[ 'totalNewLoginRetained' ] = 0;
$Arr_LoginAndRetainedAmount[ 'totalOneDayRetained' ] = 0;
$Arr_LoginAndRetainedAmount[ 'totalThreeDayRetained' ] = 0;
$Arr_LoginAndRetainedAmount[ 'totalSevenDayRetained' ] = 0;
$iLoginTime = $iStartTime;
while( $iLoginTime <= $iEndTime )
{
	$Arr_LoginAndRetainedAmount[ 'totalLogin' ] += $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ];
	$Arr_LoginAndRetainedAmount[ 'totalNewLogin' ] += $Arr_LoginAndRetained[ $iLoginTime ][ 'newLoginCount' ];
	$Arr_LoginAndRetainedAmount[ 'totalNewLoginRetained' ] += $Arr_LoginAndRetained[ $iLoginTime ][ 'oneDayNewRetained' ];
	$Arr_LoginAndRetainedAmount[ 'totalOneDayRetained' ] += $Arr_LoginAndRetained[ $iLoginTime ][ 'oneDayRetained' ];
	$Arr_LoginAndRetainedAmount[ 'totalThreeDayRetained' ] += $Arr_LoginAndRetained[ $iLoginTime ][ 'threeDayRetained' ];
	$Arr_LoginAndRetainedAmount[ 'totalSevenDayRetained' ] += $Arr_LoginAndRetained[ $iLoginTime ][ 'sevenDayRetained' ];
	/*add one day seconds*/
	$iLoginTime += $iOneDaySeconds;
}

$data = array(
	'dateStart'=>$cDateStart,
	'dateEnd'=>$cDateEnd,
    'Arr_LoginAndRetainedAmount' => $Arr_LoginAndRetainedAmount,
    'Arr_LoginAndRetained' => $Arr_LoginAndRetained,
);

render('analysis/login_and_retained.tpl', $data);