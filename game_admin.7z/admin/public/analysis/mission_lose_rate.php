<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Dec 06 07:13:08 GMT 2011
 * @desc 任务流失率统计
 */

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';

$minLevel = intval($_POST['minLevel']);
$maxLevel = intval($_POST['maxLevel']);
$arrMissionType = array('all'=>'全部',0=>'主线',1=>'支线');

//===============start 处理查询条件============//
$dateStartTime = strtotime($_POST['dateStart']) ? strtotime($_POST['dateStart']) : strtotime('-15day');
$dateEndTime = strtotime($_POST['dateEnd']) ? strtotime($_POST['dateEnd']) : strtotime(date('Y-m-d'));
$dateEndTime +=86399;
$dateStart= date('Y-m-d',$dateStartTime);
$dateEnd = date('Y-m-d',$dateEndTime);

$table = 't_log_mission';
$missionType = ''===$_POST['missionType'] || null===$_POST['missionType'] || 'all'===$_POST['missionType'] ? 'all' : intval($_POST['missionType']);

$where = " where `mTime`>={$dateStartTime} and `mTime` <= {$dateEndTime} ";
$where .= 'all' !== $missionType ? " AND missionType={$missionType} " : ' AND missionType<3 ';
$where .= !empty($minLevel) && !empty($maxLevel)?" AND roleLevel >= {$minLevel} AND roleLevel <= {$maxLevel} " :'';

//===============end 处理查询条件============//

$sqlLog = " SELECT COUNT(*) AS `cnt`, `status`, missionId, missionName, missionType FROM  (
				SELECT roleId, missionId, missionName, missionType, MAX(`status`) AS `status` 
				FROM {$table} 
				{$where}
				GROUP BY missionId,roleId
				order by missionId
			) AS tmp GROUP BY missionId, `status`  ";
$rsLog = fetchRowSet($sqlLog);
//echo $sqlLog;

$arrResult = array();
foreach ($rsLog as &$row) {
	$id = $row['missionId'];
	if (!$arrResult[$id]) {
		$arrResult[$id]=array(
			'missionId'=>$row['missionId'],
			'missionName'=>$row['missionName'],
			'missionType'=>$arrMissionType[$row['missionType']],
			'accept'=>0,
			'finish'=>0,
			'getPrize'=>0,
			'cancle'=>0,
			'total'=>0,
		);
	}
	$arrResult[$id]['total'] += $row['cnt'];
	//status 枚举 参见dict.php $dictMissionStatus
	switch ($row['status']) {
		case 1:
			$arrResult[$id]['accept'] = $row['cnt'];
			break;
		case 2:
			$arrResult[$id]['finish'] = $row['cnt'];
			break;
		case 3:
			$arrResult[$id]['getPrize'] = $row['cnt'];
			break;
		case 4:
			$arrResult[$id]['cancle'] = $row['cnt'];
			break;
	}
}
$i=0;
foreach ($arrResult as &$row) {
	$row['index'] = $i;
	$row['cancleRate'] = 0;
	if ($row['total']) {
		$row['acceptRate'] = round($row['accept']*100/$row['total'],2);
		$row['finishRate'] = round($row['finish']*100/$row['total'],2);
		$row['getPrizeRate'] = round($row['getPrize']*100/$row['total'],2);
		$row['cancleRate'] = round($row['cancle']*100/$row['total'],2);
	}else {
		$row['acceptRate'] = 0;
		$row['finishRate'] = 0;
		$row['getPrizeRate'] = 0;
		$row['cancleRate'] = 0;
	}
	$i++;
}
$data=array(
    'minLevel'=>$minLevel,
    'maxLevel'=>$maxLevel,
	'dateStart'=>$dateStart,
	'dateEnd'=>$dateEnd,
	'arrResult'=>&$arrResult,
	'arrMissionType'=>$arrMissionType,
	'missionType'=>$missionType,
);
render('analysis/mission_lose_rate.tpl',$data);
