<?php
/**
 * $Id spirit_use_stat.php
 * @uses to view the spirit use status
 * @author viticm<dhuchuanpd@gmail.com>
 * @date 2013-6-25
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_DICT.'/dict.php';
include_once SYSDIR_ADMIN_DICT.'/spirit_type.php';
include_once SYSDIR_ADMIN_DICT.'/goods.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStart = $dateStartStamp ? date('Y-m-d',$dateStartStamp) : date('Y-m-d',strtotime('-6day'));
$dateEnd = $dateEndStamp ? date('Y-m-d',$dateEndStamp) : date('Y-m-d');
$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);

//===============start 查角色==============//
$role = $_POST['role'];
$msg = array();
if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	if (!$role['roleId']) {
		$msg[] = '找不到对应玩家';
	}
}
//===============end 查角色===============//

$where  = " where `mDateTime`>={$dateStartStamp} and `mDateTime` <= {$dateEndStamp} ";
$where .= $role['roleId'] ? " and roleId = {$role['roleId']} ":'';

//===========查出符合条件的数据=======
$sql = " select `mType` , sum(`spirit`) as spirit, sum(`bindSpirit`) as bindSpirit,  count(*) as cnt, sum(`amount`) as totalAmount
         from t_log_spirit {$where}  group by `mType` ";
$rs = fetchRowSet($sql);
//=================================

$consume = array(); //系统获得(玩家失去)
$get = array(); //系统失去(玩家获得)
$circulateConsume = array(); //(玩家交易失去)
$circulateGet = array();//(玩家交易获得)
$consumeSpirit = 0;
$consumeBindSpirit = 0;
$consumeAllSpirit = 0;
$getSpirit = 0;
$getBindSpirit = 0;
$getAllSpirit = 0;
$circulateConsumeSpirit = 0;
$circulateConsumeBindSpirit = 0;
$circulateConsumeAllSpirit = 0;
$circulateGetSpirit = 0;
$circulateGetBindSpirit = 0;
$circulateGetAllSpirit = 0;

foreach ( $rs as &$row )
{
	if (!$dictSpiritType[$row['mType']]) {
		continue;
	}
	$row['sumSpirit'] =  $row['spirit']+$row['bindSpirit'];
	$row['mTypeText'] = $dictSpiritType[$row['mType']];
	if ($row['mType']>=10000 && $row['mType']<=19999 ) {
		$get[] = $row;
		$getSpirit += $row['spirit'];
		$getBindSpirit += $row['bindSpirit'];
		$getAllSpirit += $row['sumSpirit'] ;
	}elseif ($row['mType']>=20000 && $row['mType']<=29999 ) {
		$consume[] = $row;
		$consumeSpirit += $row['spirit'];
		$consumeBindSpirit += $row['bindSpirit'];
		$consumeAllSpirit += $row['sumSpirit'] ;
	}elseif ($row['mType']>=70000 && $row['mType']<=79999 ) {
		$circulateConsume[] = $row;
		$circulateConsumeSpirit = +$row['spirit'];
		$circulateConsumeBindSpirit += $row['bindSpirit'];
		$circulateConsumeAllSpirit += $row['sumSpirit'] ;
	}elseif ($row['mType']>=80000 && $row['mType']<=89999 ) {
		$circulateGet[] = $row;
		$circulateGetSpirit += $row['spirit'];
		$circulateGetBindSpirit += $row['bindSpirit'];
		$circulateGetAllSpirit += $row['sumSpirit'] ;
	}
}

foreach ( $consume as &$consumeRow )
{
	$consumeRow['sumSpiritRate'] =  $consumeAllSpirit > 0 ? round($consumeRow['sumSpirit'] * 100 / $consumeAllSpirit,2) :0 ;
	$consumeRow['spiritRate']    =  $consumeSpirit > 0 ? round($consumeRow['spirit'] * 100 / $consumeSpirit,2) :0 ;
	$consumeRow['bindSpiritRate']  =  $consumeBindSpirit > 0 ? round($consumeRow['bindSpirit'] * 100 / $consumeBindSpirit,2) :0 ;
}

foreach ( $get as &$getRow )
{
	$getRow['sumSpiritRate'] =  $getAllSpirit > 0 ? round($getRow['sumSpirit'] * 100 / $getAllSpirit,2) :0 ;
	$getRow['spiritRate']    =  $getSpirit > 0 ? round($getRow['spirit'] * 100 / $getSpirit,2) :0 ;
	$getRow['bindSpiritRate']  =  $getBindSpirit > 0 ? round($getRow['bindSpirit'] * 100 / $getBindSpirit,2) :0 ;
}

foreach ( $circulateConsume as &$circulateConsumeRow )
{
	$circulateConsumeRow['sumSpiritRate'] =  $circulateConsumeAllSpirit > 0 ? round($circulateConsumeRow['sumSpirit'] * 100 / $circulateConsumeAllSpirit,2) :0 ;
	$circulateConsumeRow['spiritRate']    =  $circulateConsumeSpirit > 0 ? round($circulateConsumeRow['spirit'] * 100 / $circulateConsumeSpirit,2) :0 ;
	$circulateConsumeRow['bindSpiritRate']  =  $circulateConsumeBindSpirit > 0 ? round($circulateConsumeRow['bindSpirit'] * 100 / $circulateConsumeBindSpirit,2) :0 ;
}

foreach ($circulateGet as &$circulateGetRow)
{
	$circulateGetRow['sumSpiritRate'] =  $circulateGetAllSpirit > 0 ? round($circulateGetRow['sumSpirit'] * 100 / $circulateGetAllSpirit,2) :0 ;
	$circulateGetRow['spiritRate']    =  $circulateGetSpirit > 0 ? round($circulateGetRow['spirit'] * 100 / $circulateGetSpirit,2) :0 ;
	$circulateGetRow['bindSpiritRate']  =  $circulateGetBindSpirit > 0 ? round($circulateGetRow['bindSpirit'] * 100 / $circulateGetBindSpirit,2) :0 ;
}

$data = array(
	'dateStart'                     => &$dateStart                   ,
	'dateEnd'                       => &$dateEnd                     ,
	'role'                          => &$role                        ,
	'consume'                       => &$consume                     ,
	'get'                           => &$get                         ,
	'circulateConsume'              => &$circulateConsume            ,
	'circulateGet'                  => &$circulateGet                ,
	'consumeSpirit'                 => &$consumeSpirit               ,
	'consumeBindSpirit'             => &$consumeBindSpirit           ,
	'consumeAllSpirit'              => &$consumeAllSpirit            ,
	'getSpirit'                     => &$getSpirit                   ,
	'getBindSpirit'                 => &$getBindSpirit               ,
	'getAllSpirit'                  => &$getAllSpirit                ,
	'circulateConsumeSpirit'        => &$circulateConsumeSpirit      ,
	'circulateConsumeBindSpirit'    => &$circulateConsumeBindSpirit  ,
	'circulateConsumeAllSpirit'     => &$circulateConsumeAllSpirit   ,
	'circulateGetSpirit'            => &$circulateGetSpirit          ,
	'circulateGetBindSpirit'        => &$circulateGetBindSpirit      ,
	'circulateGetAllSpirit'         => &$circulateGetAllSpirit       ,
	'msg'                           => empty( $msg ) ? '' : implode( '<br>', $msg ) ,
);
render('analysis/spirit_use_stat.tpl',&$data);
