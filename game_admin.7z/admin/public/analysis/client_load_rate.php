<?php
/**
 * @author linruirong@4399.com
 * @Created  Sat Dec 31 06:14:07 GMT 2011
 * @desc 客户端加载进度流失统计
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$searchType = intval($_POST['searchType']);
$searchType = $searchType ? $searchType : 1;
$arrStep = array(
    1 => '进入加载(GameLoader)页面',
    2 => '连接服务器io失败',
    3 => '连接服务器security失败',
    4 => '进入排队',
    5 => '进入创建角色界面',
    6 => '进入场景',
);
if(isPost()){
	$startTime = strtotime($_POST['startTime']);
	$endTime = strtotime($_POST['endTime']);
}
$startTime = $startTime ? $startTime : strtotime(date('Y-m-d',strtotime('-7day')));
$endTime = $endTime ? $endTime : strtotime(date('Y-m-d',time()));
$sql = " SELECT COUNT(logId) AS cnt , step, mDateTime FROM (
			SELECT logId, MAX(step) AS step, mDateTime FROM t_log_client_load WHERE mDateTime BETWEEN {$startTime} AND {$endTime} GROUP BY logId, mDateTime 
		 ) AS tmp GROUP BY step, mDateTime ";
$rs = fetchRowSet($sql);
$result = array();
for ($time=$startTime; $time<=$endTime; $time+=86400){
	$result[$time]=array(
		'step_0'  =>0,
		'step_1'  =>0,
		'step_2'  =>0,
		'step_3'  =>0,
		'step_4'  =>0,
		'step_5'  =>0,
		'step_6'  =>0,
		'total'   =>0,
		'lostRate'=>0,
		'date'    =>date('Y-m-d',$time),
		'week'    =>date('w',$time),
	);
}
foreach ($rs as $row) {
	if ($result[$row['mDateTime']] && $row['step']>=0 && $row['step'] <=6 ) {
		$result[$row['mDateTime']]['step_'.intval($row['step'])] = $row['cnt'];
		$result[$row['mDateTime']]['total'] += $row['cnt'];
	}
}
foreach ($result as &$r) {
	$r['lostRate'] = $r['total'] > 0 ? round($r['step_6'] *100 / $r['total'],2) : 0;
}

$data=array(
    'result'=> &$result,
    'startTime'=>date('Y-m-d',$startTime),
    'endTime'=>date('Y-m-d',$endTime),
);
render('analysis/client_load_rate.tpl',$data);