<?php
/**
 * $Id crystal_use_stat.php
 * @uses to view the crystal use status
 * @author viticm<dhuchuanpd@gmail.com>
 * @date 2013-6-25
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_DICT.'/dict.php';
include_once SYSDIR_ADMIN_DICT.'/crystal_type.php';
include_once SYSDIR_ADMIN_DICT.'/goods.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStart = $dateStartStamp ? date('Y-m-d',$dateStartStamp) : date('Y-m-d',strtotime('-6day'));
$dateEnd = $dateEndStamp ? date('Y-m-d',$dateEndStamp) : date('Y-m-d');
$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);

//===============start 查角色==============//
$role = $_POST['role'];
$msg = array();
if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	if (!$role['roleId']) {
		$msg[] = '找不到对应玩家';
	}
}
//===============end 查角色===============//

$where  = " where `mDateTime`>={$dateStartStamp} and `mDateTime` <= {$dateEndStamp} ";
$where .= $role['roleId'] ? " and roleId = {$role['roleId']} ":'';

//===========查出符合条件的数据=======
$sql = " select `mType` , sum(`crystal`) as crystal, sum(`bindCrystal`) as bindCrystal,  count(*) as cnt, sum(`amount`) as totalAmount
         from t_log_crystal {$where}  group by `mType` ";
$rs = fetchRowSet($sql);
//=================================

$consume = array(); //系统获得(玩家失去)
$get = array(); //系统失去(玩家获得)
$circulateConsume = array(); //(玩家交易失去)
$circulateGet = array();//(玩家交易获得)
$consumeCrystal = 0;
$consumeBindCrystal = 0;
$consumeAllCrystal = 0;
$getCrystal = 0;
$getBindCrystal = 0;
$getAllCrystal = 0;
$circulateConsumeCrystal = 0;
$circulateConsumeBindCrystal = 0;
$circulateConsumeAllCrystal = 0;
$circulateGetCrystal = 0;
$circulateGetBindCrystal = 0;
$circulateGetAllCrystal = 0;

foreach ( $rs as &$row )
{
	if (!$dictCrystalType[$row['mType']]) {
		continue;
	}
	$row['sumCrystal'] =  $row['crystal']+$row['bindCrystal'];
	$row['mTypeText'] = $dictCrystalType[$row['mType']];
	if ($row['mType']>=10000 && $row['mType']<=19999 ) {
		$get[] = $row;
		$getCrystal += $row['crystal'];
		$getBindCrystal += $row['bindCrystal'];
		$getAllCrystal += $row['sumCrystal'] ;
	}elseif ($row['mType']>=20000 && $row['mType']<=29999 ) {
		$consume[] = $row;
		$consumeCrystal += $row['crystal'];
		$consumeBindCrystal += $row['bindCrystal'];
		$consumeAllCrystal += $row['sumCrystal'] ;
	}elseif ($row['mType']>=70000 && $row['mType']<=79999 ) {
		$circulateConsume[] = $row;
		$circulateConsumeCrystal = +$row['crystal'];
		$circulateConsumeBindCrystal += $row['bindCrystal'];
		$circulateConsumeAllCrystal += $row['sumCrystal'] ;
	}elseif ($row['mType']>=80000 && $row['mType']<=89999 ) {
		$circulateGet[] = $row;
		$circulateGetCrystal += $row['crystal'];
		$circulateGetBindCrystal += $row['bindCrystal'];
		$circulateGetAllCrystal += $row['sumCrystal'] ;
	}
}

foreach ( $consume as &$consumeRow )
{
	$consumeRow['sumCrystalRate'] =  $consumeAllCrystal > 0 ? round($consumeRow['sumCrystal'] * 100 / $consumeAllCrystal,2) :0 ;
	$consumeRow['crystalRate']    =  $consumeCrystal > 0 ? round($consumeRow['crystal'] * 100 / $consumeCrystal,2) :0 ;
	$consumeRow['bindCrystalRate']  =  $consumeBindCrystal > 0 ? round($consumeRow['bindCrystal'] * 100 / $consumeBindCrystal,2) :0 ;
}

foreach ( $get as &$getRow )
{
	$getRow['sumCrystalRate'] =  $getAllCrystal > 0 ? round($getRow['sumCrystal'] * 100 / $getAllCrystal,2) :0 ;
	$getRow['crystalRate']    =  $getCrystal > 0 ? round($getRow['crystal'] * 100 / $getCrystal,2) :0 ;
	$getRow['bindCrystalRate']  =  $getBindCrystal > 0 ? round($getRow['bindCrystal'] * 100 / $getBindCrystal,2) :0 ;
}

foreach ( $circulateConsume as &$circulateConsumeRow )
{
	$circulateConsumeRow['sumCrystalRate'] =  $circulateConsumeAllCrystal > 0 ? round($circulateConsumeRow['sumCrystal'] * 100 / $circulateConsumeAllCrystal,2) :0 ;
	$circulateConsumeRow['crystalRate']    =  $circulateConsumeCrystal > 0 ? round($circulateConsumeRow['crystal'] * 100 / $circulateConsumeCrystal,2) :0 ;
	$circulateConsumeRow['bindCrystalRate']  =  $circulateConsumeBindCrystal > 0 ? round($circulateConsumeRow['bindCrystal'] * 100 / $circulateConsumeBindCrystal,2) :0 ;
}

foreach ($circulateGet as &$circulateGetRow)
{
	$circulateGetRow['sumCrystalRate'] =  $circulateGetAllCrystal > 0 ? round($circulateGetRow['sumCrystal'] * 100 / $circulateGetAllCrystal,2) :0 ;
	$circulateGetRow['crystalRate']    =  $circulateGetCrystal > 0 ? round($circulateGetRow['crystal'] * 100 / $circulateGetCrystal,2) :0 ;
	$circulateGetRow['bindCrystalRate']  =  $circulateGetBindCrystal > 0 ? round($circulateGetRow['bindCrystal'] * 100 / $circulateGetBindCrystal,2) :0 ;
}

$data = array(
	'dateStart'                      => &$dateStart                    ,
	'dateEnd'                        => &$dateEnd                      ,
	'role'                           => &$role                         ,
	'consume'                        => &$consume                      ,
	'get'                            => &$get                          ,
	'circulateConsume'               => &$circulateConsume             ,
	'circulateGet'                   => &$circulateGet                 ,
	'consumeCrystal'                 => &$consumeCrystal               ,
	'consumeBindCrystal'             => &$consumeBindCrystal           ,
	'consumeAllCrystal'              => &$consumeAllCrystal            ,
	'getCrystal'                     => &$getCrystal                   ,
	'getBindCrystal'                 => &$getBindCrystal               ,
	'getAllCrystal'                  => &$getAllCrystal                ,
	'circulateConsumeCrystal'        => &$circulateConsumeCrystal      ,
	'circulateConsumeBindCrystal'    => &$circulateConsumeBindCrystal  ,
	'circulateConsumeAllCrystal'     => &$circulateConsumeAllCrystal   ,
	'circulateGetCrystal'            => &$circulateGetCrystal          ,
	'circulateGetBindCrystal'        => &$circulateGetBindCrystal      ,
	'circulateGetAllCrystal'         => &$circulateGetAllCrystal       ,
	'msg'                            => empty( $msg ) ? '' : implode( '<br>', $msg ) ,
);
render('analysis/crystal_use_stat.tpl',&$data);
