<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Dec 09 02:13:52 GMT 2011
 * @desc 目标完成情况统计
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
$dictTarget = array();
include_once SYSDIR_ADMIN_DICT.'/target.php';


$tmpStartTime = strtotime($_POST['startDate']);
$tmpEndTime = strtotime($_POST['endDate']);
$startTime = $tmpStartTime ? $tmpStartTime  : strtotime(date('Y-m-d',strtotime('-6day')));
$endTime = $tmpEndTime ? $tmpEndTime  : strtotime(date('Y-m-d'));
$startDate = date('Y-m-d',$startTime);
$endDate = date('Y-m-d',$endTime);
$prevDate = date('Y-m-d',$startTime-86400);
$nextDate = date('Y-m-d',$startTime+86400);
$startYmd = date('Ymd',$startTime);
$endYmd = date('Ymd',$endTime);

$targetType = 1 ; //targetType=5 表示为类型为目标的。另一个targetType=1的为成就

$result = array();
//初始化数据
foreach ($dictTarget as $id => $target) {
//	if ($id>=500000 && $id<600000) {
	if ($id>=20101 && $id<110001) {
		$result[$id]['targetId'] = $id;
		$result[$id]['targetName'] = $target['name'];
		$result[$id]['total'] = 0;
		$result[$id]['finishCnt'] = 0;
		$result[$id]['finishRate'] = 0;
		$result[$id]['totalFinishRate'] = 0;
		$result[$id]['lostCnt'] = 0;
		$result[$id]['lostRate'] = 0;
	}
}
ksort($result);
/**
$firstTargetId = array_shift(array_keys($result));

$sqlRegister =  " SELECT COUNT(roleId) AS roleCnt FROM `t_log_register` where mDateTime BETWEEN {$startTime} AND {$endTime} ";
$rsRegisterCnt = fetchRowOne($sqlRegister);
$registerCnt = $rsRegisterCnt['roleCnt'];


$sqlTarget =  " SELECT t.targetId, COUNT(t.roleId) AS roleCnt FROM t_log_target t, t_log_register r 
                WHERE r.roleId=t.roleId AND targetType={$targetType}  AND r.mDateTime BETWEEN {$startTime} AND {$endTime}
                GROUP BY t.targetId  order by t.targetId asc ";
$rsTarget = fetchRowSet($sqlTarget);

$prevTotal = $registerCnt;
foreach ($result as $key => &$r) {
	foreach ($rsTarget as $index => $row) {
		if ($key == $row['targetId']) {
			$r['total'] = $prevTotal;
			$r['finishCnt'] = $row['roleCnt'];
			$r['finishRate'] = $prevTotal > 0 ? round( $row['roleCnt']/$prevTotal *100, 2).'%' : 0;
			$r['totalFinishRate'] = $registerCnt > 0 ? round( $row['roleCnt']/$registerCnt *100, 2).'%' : 0;
			$prevTotal = $row['roleCnt'];
			unset($rsTarget[$index]);
			break;
		}
	}
}
**/
$table = 't_log_target';
$where = " where `mDateTime` BETWEEN {$startTime} AND {$endTime} ";
$sqlLog = " SELECT COUNT(*) AS `cnt`, `status`, targetId FROM  (
				SELECT roleId, targetId, `targetType` AS `status` 
				FROM {$table} 
				{$where}
			) AS tmp GROUP BY targetId, `status`  ";
$rsLog = fetchRowSet($sqlLog);
//echo $sqlLog;

$arrResult = array();
foreach ($rsLog as &$row) {
	$id = $row['targetId'];
	if (!$arrResult[$id]) {
		$arrResult[$id]=array(
			'targetId'=>$row['targetId'],
			'accept'=>0,
			'finish'=>0,
			'getPrize'=>0,
			'cancle'=>0,
			'total'=>0,
		);
	}
	$arrResult[$id]['total'] += $row['cnt'];
	//status 枚举 参见dict.php $dictMissionStatus
	switch ($row['status']) {
		case 1:
			$arrResult[$id]['accept'] = $row['cnt']; //接受
			break;
		case 2:
			$arrResult[$id]['finish'] = $row['cnt']; //完成
			break;
		case 3:
			$arrResult[$id]['getPrize'] = $row['cnt']; //领取奖励
			break;
		case 4:
			$arrResult[$id]['cancle'] = $row['cnt'];
			break;
	}
}
$i=0;
foreach ($arrResult as &$row) {
	$row['index'] = $i;
	$row['cancleRate'] = 0;
	if ($row['total']) {
		$row['acceptRate'] = round($row['accept']*100/$row['total'],2);
		$row['finishRate'] = round($row['finish']*100/$row['accept'],2);
		$row['getPrizeRate'] = round($row['getPrize']*100/$row['accept'],2);
		$row['cancleRate'] = round($row['cancle']*100/$row['accept'],2);
	}else {
		$row['acceptRate'] = 0;
		$row['finishRate'] = 0;
		$row['getPrizeRate'] = 0;
		$row['cancleRate'] = 0;
	}
	$i++;
}
foreach ($result as $key => &$r) {
	foreach ($arrResult as $index => $val) {
		if ($key == $val['targetId']) {
			$r['total'] = $val[ 'accept' ]; //无论完成的还是未完成的都算作一次，现在改为接受该任务的人数
			$r['finishCnt'] = $val['finish'];
			$r['finishRate'] = $val[ 'finishRate' ];
			$r['totalFinishRate'] = $val[ 'getPrizeRate' ];
			$prevTotal = $val['roleCnt'];
			unset($arrResult[$index]);
			break;
		}
	}
}
$data = array(
	'result'=>$result,
	'minLevel'=>$minLevel,
	'maxLevel'=>$maxLevel,
	'startDate'=>$startDate,
	'endDate'=>$endDate,
	'prevDate' =>$prevDate,
	'nextDate' =>$nextDate,
	'serverOnlineDate' =>SERVER_ONLINE_DATE,
	'today' =>date('Y-m-d'),
);
render('analysis/target_finish_stat.tpl',$data);

//目标ID，目标名，完成人数，未完成的人数，完成比率，未完成且已流失玩家