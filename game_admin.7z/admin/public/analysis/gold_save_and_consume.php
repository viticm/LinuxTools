<?php
include_once '../../protected/config/config.php';
include_once '../../protected/config/logic_cfg.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';


$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp   = strtotime($_POST['dateEnd']);
$bindType = intval($_POST['bindType']);
$dateStartStamp = $dateStartStamp ? $dateStartStamp : strtotime(date('Y-m-d',strtotime('-6day')));
$dateEndStamp = $dateEndStamp ? $dateEndStamp : strtotime(date('Y-m-d',time()));
$dateStart = date('Y-m-d', $dateStartStamp);
$dateEnd = date('Y-m-d', $dateEndStamp);

$bindType = $bindType ? $bindType  : 1; //默认查不绑定的.

//===============start 初始化数据==========//
$diffDay = ($dateEndStamp - $dateStartStamp ) / 86400 ;
$arrResult = array();
for($d=0; $d <= $diffDay; $d++) {
	$datetime = $dateStartStamp+$d*86400;
	$arrResult[$datetime] = array(
		'save'=>0,
		'new'=>0,
		'consume'=>0,
		'circulateGet'=>0,
		'circulateConsume'=>0,
		'date'=>date('m.d',$datetime),
		'week'=>date('w',$datetime),
	);
}
$maxNew = 0;
$maxConsume =0;
$maxSave = 0;
$maxCirculateGet = 0;
$maxCirculateConsume = 0;
//===========end =================//


$sql = " select * from t_stat_gold  WHERE mDateTime BETWEEN {$dateStartStamp} AND {$dateEndStamp} ";
$rs = fetchRowSet($sql);
foreach ($rs as $row) {
	$datetime = $row['mDateTime'];
	if (1==$bindType) {
		$arrResult[$datetime]['save'] = $row['saveGold'];
		$arrResult[$datetime]['new'] = $row['getGold'];
		$arrResult[$datetime]['consume'] = $row['consumeGold'];
	}elseif (2==$bindType) {
		$arrResult[$datetime]['save'] = $row['saveBindGold'];
		$arrResult[$datetime]['new'] = $row['getBindGold'];
		$arrResult[$datetime]['consume'] = $row['consumeBindGold'];
	}else {
		$arrResult[$datetime]['save'] = $row['saveGold'] + $row['saveBindGold'];
		$arrResult[$datetime]['new'] = $row['getGold'] + $row['getBindGold'];
		$arrResult[$datetime]['consume'] = $row['consumeGold'] + $row['consumeBindGold'];
	}
	$arrResult[$datetime]['circulateGet'] = $row['circulateGetGold'];
	$arrResult[$datetime]['circulateConsume'] = $row['circulateConsumeGold'];
	$maxSave = $arrResult[$datetime]['save'] > $maxSave ? $arrResult[$datetime]['save'] : $maxSave;
	$maxNew  = $arrResult[$datetime]['new']  > $maxNew ?  $arrResult[$datetime]['new']  : $maxNew;
	$maxConsume = $arrResult[$datetime]['consume'] > $maxConsume ? $arrResult[$datetime]['consume'] : $maxConsume;
	$maxCirculateGet = $arrResult[$datetime]['circulateGet'] > $maxCirculateGet ? $arrResult[$datetime]['circulateGet'] : $maxCirculateGet;
	$maxCirculateConsume = $arrResult[$datetime]['circulateConsume'] > $maxCirculateConsume ? $arrResult[$datetime]['circulateConsume'] : $maxCirculateConsume;
}

$sqlSave = " select sum(gold) as totalSaveGold, sum(bind_gold) as totalSaveBindGold from PLAYER_TBL ";
$rsSave = GFetchRowOne($sqlSave);

$sqlLvSave = " select sum(gold) as totalLvSaveGold, sum(bind_gold) as totalLvSaveBindGold from PLAYER_TBL where level>".GOLD_STAT_LEVEL;
$rsLvSave = GFetchRowOne($sqlLvSave);

$arrBindAttr = array(
	1=>'不绑定',
	2=>'绑定',
	3=>'全部',
);
$data = array(
    'arrBindAttr'=>$arrBindAttr,
    'bindType'=>$bindType,
    'dateStart'=>$dateStart,
    'dateEnd'=>$dateEnd,
    'arrResult'=>$arrResult,
	'maxNew'=> $maxNew,
	'maxConsume'=> $maxConsume,
	'maxSave'=> $maxSave,
	'maxCirculateGet' => $maxCirculateGet,
	'maxCirculateConsume' => $maxCirculateConsume,
	'totalSaveGold' => $rsSave['totalSaveGold'],
	'totalSaveBindGold' => $rsSave['totalSaveBindGold'],
	'lvGold' => $rsLvSave['totalLvSaveGold'],
	'lvBindGold' => $rsLvSave['totalLvSaveBindGold'],
	'lvLimit' => GOLD_STAT_LEVEL,
);
render('analysis/gold_save_and_consume.tpl', $data);