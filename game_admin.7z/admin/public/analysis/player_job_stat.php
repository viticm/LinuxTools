<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Dec 06 09:26:09 GMT 2011
 * @desc 创建角色页流失率统计
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_DICT.'/job.php';

$endDateTime = strtotime(date('Y-m-d',time()));
$startDateTime = $endDateTime-6*86400;
$activeTime = 1800; //最近7天在线多少秒算是活跃用户。

$sqlRegister = " select roleJob, count(*) as registerCnt from t_log_register group by roleJob ";
$rsRegister = fetchRowSet($sqlRegister);

$sqlActive   = "SELECT COUNT(r.roleId) AS activeCnt,r.roleJob FROM (
				SELECT roleId, SUM(onlineTime) AS totalOnlineTime FROM t_log_logout 
				WHERE logoutDate BETWEEN {$startDateTime} AND {$endDateTime} 
				GROUP BY roleId HAVING totalOnlineTime >= {$activeTime} ) AS tmp, t_log_register r WHERE r.roleId=tmp.roleId GROUP BY r.roleJob ";
$rsActive = fetchRowSet($sqlActive);

global $dictJobs;
$active = array();
$register = array();
foreach ($dictJobs as $id => $job) {
	$active[$id] = array('job'=>$job);
	$register[$id] = array('job'=>$job);
}

$totalRegister = 0 ;
foreach ($rsRegister as $row) {
	$totalRegister += $row['registerCnt'];
}
foreach ($rsRegister as $row) {
	if ($register[$row['roleJob']]) {
		$register[$row['roleJob']]['registerCnt'] = $row['registerCnt'];
		$register[$row['roleJob']]['registerRate'] = $totalRegister >0 ? round($row['registerCnt'] / $totalRegister * 100,2).'%' : 0;
	}
}

$totalActive = 0;
foreach ($rsActive as $row) {
	$totalActive += $row['activeCnt'];
}
foreach ($rsActive as $row) {
	if ($active[$row['roleJob']]) {
		$active[$row['roleJob']]['activeCnt'] = $row['activeCnt'];
		$active[$row['roleJob']]['activeRate'] = $totalActive >0 ? round($row['activeCnt'] / $totalActive * 100,2).'%' : 0;
	}
}

$data=array(
    'register'=> &$register,
    'active'=> &$active,
    'totalActive' => &$totalActive,
    'totalRegister' => &$totalRegister,
);
render('analysis/player_job_stat.tpl',$data);