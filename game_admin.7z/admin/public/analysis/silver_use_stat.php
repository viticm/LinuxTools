<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Nov 07 07:10:47 GMT 2011
 * @desc 玩家退出日志
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_DICT.'/dict.php';
include_once SYSDIR_ADMIN_DICT.'/silver_type.php';
include_once SYSDIR_ADMIN_DICT.'/goods.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStart = $dateStartStamp ? date('Y-m-d',$dateStartStamp) : date('Y-m-d',strtotime('-6day'));
$dateEnd = $dateEndStamp ? date('Y-m-d',$dateEndStamp) : date('Y-m-d');
$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);

//===============start 查角色==============//
$role = $_POST['role'];
$msg = array();
if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	if (!$role['roleId']) {
		$msg[] = '找不到对应玩家';
	}
}
//===============end 查角色===============//

$where = " where `mDateTime`>={$dateStartStamp} and `mDateTime` <= {$dateEndStamp} ";
$where .= $role['roleId'] ? " and roleId = {$role['roleId']} ":'';

//===========查出符合条件的数据=======
$sql = " select `mType` , sum(`silver`) as silver, sum(`bindSilver`) as bindSilver,  count(*) as cnt, sum(`amount`) as totalAmount
         from t_log_silver {$where}  group by `mType` ";
$rs = fetchRowSet($sql);
//=================================

$consume = array(); //系统获得(玩家失去)
$get = array(); //系统失去(玩家获得)
$circulateConsume = array(); //(玩家交易失去)
$circulateGet = array();//(玩家交易获得)
$consumeSilver = 0;
$consumeBindSilver = 0;
$consumeAllSilver = 0;
$getSilver = 0;
$getBindSilver = 0;
$getAllSilver = 0;
$circulateConsumeSilver = 0;
$circulateConsumeBindSilver = 0;
$circulateConsumeAllSilver = 0;
$circulateGetSilver = 0;
$circulateGetBindSilver = 0;
$circulateGetAllSilver = 0;

foreach ($rs as &$row) {
	if (!$dictSilverType[$row['mType']]) {
		continue;
	}
	$row['sumSilver'] =  $row['silver']+$row['bindSilver'];
	$row['mTypeText'] = $dictSilverType[$row['mType']];
	if ($row['mType']>=50000 && $row['mType']<=59999 ) {
		$get[] = $row;
		$getSilver += $row['silver'];
		$getBindSilver += $row['bindSilver'];
		$getAllSilver += $row['sumSilver'] ;
	}elseif ($row['mType']>=60000 && $row['mType']<=69999 ) {
		$consume[] = $row;
		$consumeSilver += $row['silver'];
		$consumeBindSilver += $row['bindSilver'];
		$consumeAllSilver += $row['sumSilver'] ; 
	}elseif ($row['mType']>=70000 && $row['mType']<=79999 ) {
		$circulateConsume[] = $row;
		$circulateConsumeSilver = +$row['silver'];
		$circulateConsumeBindSilver += $row['bindSilver'];
		$circulateConsumeAllSilver += $row['sumSilver'] ; 
	}elseif ($row['mType']>=80000 && $row['mType']<=89999 ) {
		$circulateGet[] = $row;
		$circulateGetSilver += $row['silver'];
		$circulateGetBindSilver += $row['bindSilver'];
		$circulateGetAllSilver += $row['sumSilver'] ; 
	}
}

foreach ($consume as &$consumeRow) {
	$consumeRow['sumSilverRate'] =  $consumeAllSilver > 0 ? round($consumeRow['sumSilver'] * 100 / $consumeAllSilver,2) :0 ;
	$consumeRow['silverRate']    =  $consumeSilver > 0 ? round($consumeRow['silver'] * 100 / $consumeSilver,2) :0 ;
	$consumeRow['bindSilverRate']  =  $consumeBindSilver > 0 ? round($consumeRow['bindSilver'] * 100 / $consumeBindSilver,2) :0 ;
}

foreach ($get as &$getRow) {
	$getRow['sumSilverRate'] =  $getAllSilver > 0 ? round($getRow['sumSilver'] * 100 / $getAllSilver,2) :0 ;
	$getRow['silverRate']    =  $getSilver > 0 ? round($getRow['silver'] * 100 / $getSilver,2) :0 ;
	$getRow['bindSilverRate']  =  $getBindSilver > 0 ? round($getRow['bindSilver'] * 100 / $getBindSilver,2) :0 ;
}

foreach ($circulateConsume as &$circulateConsumeRow) {
	$circulateConsumeRow['sumSilverRate'] =  $circulateConsumeAllSilver > 0 ? round($circulateConsumeRow['sumSilver'] * 100 / $circulateConsumeAllSilver,2) :0 ;
	$circulateConsumeRow['silverRate']    =  $circulateConsumeSilver > 0 ? round($circulateConsumeRow['silver'] * 100 / $circulateConsumeSilver,2) :0 ;
	$circulateConsumeRow['bindSilverRate']  =  $circulateConsumeBindSilver > 0 ? round($circulateConsumeRow['bindSilver'] * 100 / $circulateConsumeBindSilver,2) :0 ;
}

foreach ($circulateGet as &$circulateGetRow) {
	$circulateGetRow['sumSilverRate'] =  $circulateGetAllSilver > 0 ? round($circulateGetRow['sumSilver'] * 100 / $circulateGetAllSilver,2) :0 ;
	$circulateGetRow['silverRate']    =  $circulateGetSilver > 0 ? round($circulateGetRow['silver'] * 100 / $circulateGetSilver,2) :0 ;
	$circulateGetRow['bindSilverRate']  =  $circulateGetBindSilver > 0 ? round($circulateGetRow['bindSilver'] * 100 / $circulateGetBindSilver,2) :0 ;
}

$data = array(
	'dateStart'=>&$dateStart,
	'dateEnd'=>&$dateEnd,
	'role' => &$role,
	'consume'                     => &$consume                   ,
	'get'                         => &$get                       ,
	'circulateConsume'            => &$circulateConsume          ,
	'circulateGet'                => &$circulateGet              ,
	'consumeSilver'                 => &$consumeSilver               ,
	'consumeBindSilver'             => &$consumeBindSilver           ,
	'consumeAllSilver'              => &$consumeAllSilver            ,
	'getSilver'                     => &$getSilver                   ,
	'getBindSilver'                 => &$getBindSilver               ,
	'getAllSilver'                  => &$getAllSilver                ,
	'circulateConsumeSilver'        => &$circulateConsumeSilver      ,
	'circulateConsumeBindSilver'    => &$circulateConsumeBindSilver  ,
	'circulateConsumeAllSilver'     => &$circulateConsumeAllSilver   ,
	'circulateGetSilver'            => &$circulateGetSilver          ,
	'circulateGetBindSilver'        => &$circulateGetBindSilver      ,
	'circulateGetAllSilver'         => &$circulateGetAllSilver       ,
	'msg' => empty($msg) ? '' : implode('<br>',$msg),
);
render('analysis/silver_use_stat.tpl',&$data);
