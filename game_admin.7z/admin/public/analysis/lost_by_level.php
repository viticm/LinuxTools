<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Dec 09 09:44:11 GMT 2011
 * @desc 等级流失率统计
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$dateStart = SS($_POST['dateStart']);
$dateEnd = SS($_POST['dateEnd']);
$dateStart = $dateStart ? $dateStart : date('Y-m-d',strtotime(SERVER_ONLINE_DATE));
$dateEnd = $dateEnd ? $dateEnd : date("Y-m-d");

$dateStartTamp = strtotime($dateStart);
$dateEndTamp = strtotime($dateEnd)+86399;
$lassLogoutTime = strtotime('-3day');

$sqlLevel = " select count(`id`) as roleCnt , `level` as roleLevel from PLAYER_TBL where create_time BETWEEN {$dateStartTamp} and {$dateEndTamp}  group by `level` ";
$sqlLost =  " SELECT COUNT(`id`) AS roleCnt , `level` AS roleLevel FROM PLAYER_TBL WHERE last_logout_time < {$lassLogoutTime} AND  create_time  BETWEEN {$dateStartTamp} and {$dateEndTamp} GROUP BY `level`  ";
$rsLevel = GFetchRowSet($sqlLevel);
$rsLost  = GFetchRowSet($sqlLost);

$minLevel = $rsLevel[0]['roleLevel'];
$maxLevel = $rsLevel[0]['roleLevel'];
$totalRoleCnt = 0;
$totalLostCnt = 0;
foreach ($rsLevel as $row) {
	if ($row['roleLevel'] < $minLevel) {
		$minLevel = $row['roleLevel'];
	}
	if ($row['roleLevel'] > $maxLevel) {
		$maxLevel = $row['roleLevel'];
	}
	$totalRoleCnt += $row['roleCnt'];
}
foreach ($rsLost as $row) {
	$totalLostCnt += $row['roleCnt'];
}

if ($maxLevel > $minLevel) {
	for ($i=$minLevel; $i<=$maxLevel; $i++){
		$result[$i] = array('levelCnt'=>0,'levelRate'=>0,'lostCnt'=>0,'lostRateLevel'=>0,'lostRateGlobal'=>0,);
	}
}

foreach ($rsLevel as $row) {
	$result[$row['roleLevel']]['levelCnt'] = $row['roleCnt'];
	$result[$row['roleLevel']]['levelRate'] = $totalRoleCnt > 0 ? round($row['roleCnt']/$totalRoleCnt*100, 2) : 0;
}

foreach ($rsLost as $row) {
	$result[$row['roleLevel']]['lostCnt'] = $row['roleCnt'];
	$result[$row['roleLevel']]['lostRateLevel'] = $result[$row['roleLevel']]['levelCnt'] > 0 ? round($row['roleCnt']/$result[$row['roleLevel']]['levelCnt']*100, 2) : 0;
	$result[$row['roleLevel']]['lostRateGlobal'] = $totalLostCnt > 0 ? round($row['roleCnt']/$totalLostCnt*100, 2) : 0;
}

// for chart
$Arr_RoleLevel          = array();
$Arr_RoleLevelRate      = array();
$Arr_RoleLostRateLevel  = array();
$Arr_RoleLostRateGlobal = array();

foreach ( $row as $key => $val )
{
    array_push( $Arr_RoleLevelRate, $key );
    array_push( $Arr_RoleLevelRate, $val[ 'levelRate' ] );
    array_push( $Arr_RoleLostRateLevel, $val[ 'lostRateLevel' ] );
    array_push( $Arr_RoleLostRateGlobal, $val[ 'lostRateGlobal' ] );
}


$data = array(
	'dateStart' => &$dateStart,
	'dateEnd' => &$dateEnd,
	'totalRoleCnt' => &$totalRoleCnt,
	'totalLostCnt' => &$totalLostCnt,
	'result' => &$result,
);
render('analysis/lost_by_level.tpl',$data);