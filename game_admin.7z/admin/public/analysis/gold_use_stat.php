<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Nov 07 07:10:47 GMT 2011
 * @desc 玩家退出日志
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_DICT.'/dict.php';
include_once SYSDIR_ADMIN_DICT.'/gold_type.php';
include_once SYSDIR_ADMIN_DICT.'/goods.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStart = $dateStartStamp ? date('Y-m-d',$dateStartStamp) : date('Y-m-d',strtotime('-6day'));
$dateEnd = $dateEndStamp ? date('Y-m-d',$dateEndStamp) : date('Y-m-d');
$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);

//===============start 查角色==============//
$role = $_POST['role'];
$msg = array();
if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	if (!$role['roleId']) {
		$msg[] = '找不到对应玩家';
	}
}
//===============end 查角色===============//

$where = " where `mDateTime`>={$dateStartStamp} and `mDateTime` <= {$dateEndStamp} ";
$where .= $role['roleId'] ? " and roleId = {$role['roleId']} ":'';

//===========查出符合条件的数据=======
$sql = " select `mType` , sum(`gold`) as gold, sum(`bindGold`) as bindGold,  count(*) as cnt, sum(`amount`) as totalAmount
         from t_log_gold {$where}  group by `mType` ";
$rs = fetchRowSet($sql);
//=================================

$consume = array(); //系统获得(玩家失去)
$get = array(); //系统失去(玩家获得)
$circulateConsume = array(); //(玩家交易失去)
$circulateGet = array();//(玩家交易获得)
$consumeGold = 0;
$consumeBindGold = 0;
$consumeAllGold = 0;
$getGold = 0;
$getBindGold = 0;
$getAllGold = 0;
$circulateConsumeGold = 0;
$circulateConsumeBindGold = 0;
$circulateConsumeAllGold = 0;
$circulateGetGold = 0;
$circulateGetBindGold = 0;
$circulateGetAllGold = 0;

foreach ($rs as &$row) {
	if (!$dictGoldType[$row['mType']]) {
		continue;
	}
	$row['sumGold'] =  $row['gold']+$row['bindGold'];
	$row['mTypeText'] = $dictGoldType[$row['mType']];
	if ($row['mType']>=10000 && $row['mType']<=19999 ) {
		$get[] = $row;
		$getGold += $row['gold'];
		$getBindGold += $row['bindGold'];
		$getAllGold += $row['sumGold'] ;
	}elseif ($row['mType']>=20000 && $row['mType']<=29999 ) {
		$consume[] = $row;
		$consumeGold += $row['gold'];
		$consumeBindGold += $row['bindGold'];
		$consumeAllGold += $row['sumGold'] ; 
	}elseif ($row['mType']>=30000 && $row['mType']<=39999 ) {
		$circulateConsume[] = $row;
		$circulateConsumeGold = +$row['gold'];
		$circulateConsumeBindGold += $row['bindGold'];
		$circulateConsumeAllGold += $row['sumGold'] ; 
	}elseif ($row['mType']>=40000 && $row['mType']<=49999 ) {
		$circulateGet[] = $row;
		$circulateGetGold += $row['gold'];
		$circulateGetBindGold += $row['bindGold'];
		$circulateGetAllGold += $row['sumGold'] ; 
	}
}

foreach ($consume as &$consumeRow) {
	$consumeRow['sumGoldRate'] =  $consumeAllGold > 0 ? round($consumeRow['sumGold'] * 100 / $consumeAllGold,2) :0 ;
	$consumeRow['goldRate']    =  $consumeGold > 0 ? round($consumeRow['gold'] * 100 / $consumeGold,2) :0 ;
	$consumeRow['bindGoldRate']  =  $consumeBindGold > 0 ? round($consumeRow['bindGold'] * 100 / $consumeBindGold,2) :0 ;
}

foreach ($get as &$getRow) {
	$getRow['sumGoldRate'] =  $getAllGold > 0 ? round($getRow['sumGold'] * 100 / $getAllGold,2) :0 ;
	$getRow['goldRate']    =  $getGold > 0 ? round($getRow['gold'] * 100 / $getGold,2) :0 ;
	$getRow['bindGoldRate']  =  $getBindGold > 0 ? round($getRow['bindGold'] * 100 / $getBindGold,2) :0 ;
}

foreach ($circulateConsume as &$circulateConsumeRow) {
	$circulateConsumeRow['sumGoldRate'] =  $circulateConsumeAllGold > 0 ? round($circulateConsumeRow['sumGold'] * 100 / $circulateConsumeAllGold,2) :0 ;
	$circulateConsumeRow['goldRate']    =  $circulateConsumeGold > 0 ? round($circulateConsumeRow['gold'] * 100 / $circulateConsumeGold,2) :0 ;
	$circulateConsumeRow['bindGoldRate']  =  $circulateConsumeBindGold > 0 ? round($circulateConsumeRow['bindGold'] * 100 / $circulateConsumeBindGold,2) :0 ;
}

foreach ($circulateGet as &$circulateGetRow) {
	$circulateGetRow['sumGoldRate'] =  $circulateGetAllGold > 0 ? round($circulateGetRow['sumGold'] * 100 / $circulateGetAllGold,2) :0 ;
	$circulateGetRow['goldRate']    =  $circulateGetGold > 0 ? round($circulateGetRow['gold'] * 100 / $circulateGetGold,2) :0 ;
	$circulateGetRow['bindGoldRate']  =  $circulateGetBindGold > 0 ? round($circulateGetRow['bindGold'] * 100 / $circulateGetBindGold,2) :0 ;
}

$data = array(
	'dateStart'=>&$dateStart,
	'dateEnd'=>&$dateEnd,
	'role' => &$role,
	'consume'                     => &$consume                   ,
	'get'                         => &$get                       ,
	'circulateConsume'            => &$circulateConsume          ,
	'circulateGet'                => &$circulateGet              ,
	'consumeGold'                 => &$consumeGold               ,
	'consumeBindGold'             => &$consumeBindGold           ,
	'consumeAllGold'              => &$consumeAllGold            ,
	'getGold'                     => &$getGold                   ,
	'getBindGold'                 => &$getBindGold               ,
	'getAllGold'                  => &$getAllGold                ,
	'circulateConsumeGold'        => &$circulateConsumeGold      ,
	'circulateConsumeBindGold'    => &$circulateConsumeBindGold  ,
	'circulateConsumeAllGold'     => &$circulateConsumeAllGold   ,
	'circulateGetGold'            => &$circulateGetGold          ,
	'circulateGetBindGold'        => &$circulateGetBindGold      ,
	'circulateGetAllGold'         => &$circulateGetAllGold       ,
	'msg' => empty($msg) ? '' : implode('<br>',$msg),
);
render('analysis/gold_use_stat.tpl',&$data);
