<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Dec 06 07:13:08 GMT 2011
 * @desc 任务流失率统计
 */

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';

$minLevel = intval($_POST['minLevel']);
$maxLevel = intval($_POST['maxLevel']);
$arrMissionType = array('all'=>'全部',0=>'主线',1=>'支线');

//===============start 处理查询条件============//
$dateStartTime = strtotime($_POST['dateStart']) ? strtotime($_POST['dateStart']) : strtotime('-7day');
$dateEndTime = strtotime($_POST['dateEnd']) ? strtotime($_POST['dateEnd']) : strtotime(date('Y-m-d'));
$dateEndTime +=86399;
$dateStart= date('Y-m-d',$dateStartTime);
$dateEnd = date('Y-m-d',$dateEndTime);

$sqlTotal = " select count(roleId) as roleCnt from t_log_register where mTime>={$dateStartTime} AND  mTime<={$dateEndTime}";
$rsTotal = fetchRowOne($sqlTotal);
$totalRole = $rsTotal['roleCnt'];

$missionType = ''===$_POST['missionType'] || null===$_POST['missionType'] || 'all'===$_POST['missionType'] ? 'all' : intval($_POST['missionType']);
$where = 'all' !== $missionType ? " AND m.missionType={$missionType} " : ' AND m.missionType<3 ';

$sql = " SELECT COUNT(DISTINCT m.roleId) AS cnt, m.missionId, m.missionName, m.missionType FROM t_log_mission m, t_log_register r
		 WHERE r.mTime>={$dateStartTime} and r.mTime<={$dateEndTime} {$where} AND m.status=3 AND r.roleId =m.roleId 
		 GROUP BY m.missionId ORDER BY m.missionId ";
//===============end 处理查询条件============//
$rsLog = fetchRowSet($sql);
//echo $sqlLog;

$arrResult = array();
foreach ($rsLog as &$row) {
	$row['missionType'] = $arrMissionType[$row['missionType']];
	$row['getPrize'] = $row['cnt'];
	$row['getPrizeRate'] = $totalRole>0 ? round($row['cnt']*100/$totalRole,2) : 0;
}

$data=array(
	'dateStart'=>$dateStart,
	'dateEnd'=>$dateEnd,
	'arrResult'=>&$rsLog,
	'arrMissionType'=>$arrMissionType,
	'missionType'=>$missionType,
	'totalRole'=>$totalRole,
);
render('analysis/mission_finish_stat.tpl',$data);