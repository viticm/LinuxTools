<?php
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp   = strtotime($_POST['dateEnd']);
$bindType = intval($_POST['bindType']);
$dateStartStamp = $dateStartStamp ? $dateStartStamp : strtotime(date('Y-m-d',strtotime('-6day')));
$dateEndStamp = $dateEndStamp ? $dateEndStamp : strtotime(date('Y-m-d',time()));
$dateStart = date('Y-m-d', $dateStartStamp);
$dateEnd = date('Y-m-d', $dateEndStamp);

$bindType = $bindType ? $bindType  : 1; //默认查不绑定的.

//===============start 初始化数据==========//
$diffDay = ($dateEndStamp - $dateStartStamp ) / 86400 ;
$arrResult = array();
for($d=0; $d <= $diffDay; $d++) {
	$datetime = $dateStartStamp+$d*86400;
	$arrResult[$datetime] = array(
		'save'=>0,
		'new'=>0,
		'consume'=>0,
		'circulateGet'=>0,
		'circulateConsume'=>0,
		'date'=>date('m.d',$datetime),
		'week'=>date('w',$datetime),
	);
}
$maxNew = 0;
$maxConsume =0;
$maxSave = 0;
$maxCirculateGet = 0;
$maxCirculateConsume = 0;
//===========end =================//


$sql = " select * from t_stat_silver  WHERE mDateTime BETWEEN {$dateStartStamp} AND {$dateEndStamp} ";
$rs = fetchRowSet($sql);
foreach ($rs as $row) {
	$datetime = $row['mDateTime'];
	if (1==$bindType) {
		$arrResult[$datetime]['save'] = $row['saveSilver'];
		$arrResult[$datetime]['new'] = $row['getSilver'];
		$arrResult[$datetime]['consume'] = $row['consumeSilver'];
	}elseif (2==$bindType) {
		$arrResult[$datetime]['save'] = $row['saveBindSilver'];
		$arrResult[$datetime]['new'] = $row['getBindSilver'];
		$arrResult[$datetime]['consume'] = $row['consumeBindSilver'];
	}else {
		$arrResult[$datetime]['save'] = $row['saveSilver'] + $row['saveBindSilver'];
		$arrResult[$datetime]['new'] = $row['getSilver'] + $row['getBindSilver'];
		$arrResult[$datetime]['consume'] = $row['consumeSilver'] + $row['consumeBindSilver'];
	}
	$arrResult[$datetime]['circulateGet'] = $row['circulateGetSilver'];
	$arrResult[$datetime]['circulateConsume'] = $row['circulateConsumeSilver'];
	$maxSave = $arrResult[$datetime]['save'] > $maxSave ? $arrResult[$datetime]['save'] : $maxSave;
	$maxNew  = $arrResult[$datetime]['new']  > $maxNew ?  $arrResult[$datetime]['new']  : $maxNew;
	$maxConsume = $arrResult[$datetime]['consume'] > $maxConsume ? $arrResult[$datetime]['consume'] : $maxConsume;
	$maxCirculateGet = $arrResult[$datetime]['circulateGet'] > $maxCirculateGet ? $arrResult[$datetime]['circulateGet'] : $maxCirculateGet;
	$maxCirculateConsume = $arrResult[$datetime]['circulateConsume'] > $maxCirculateConsume ? $arrResult[$datetime]['circulateConsume'] : $maxCirculateConsume;
}

$sqlSave = " select sum(silver) as totalSaveSilver, sum(bind_silver) as totalSaveBindSilver from PLAYER_TBL ";
$rsSave = GFetchRowOne($sqlSave);

$arrBindAttr = array(
	1=>'不绑定',
	2=>'绑定',
	3=>'全部',
);
$data = array(
    'arrBindAttr'=>$arrBindAttr,
    'bindType'=>$bindType,
    'dateStart'=>$dateStart,
    'dateEnd'=>$dateEnd,
    'arrResult'=>$arrResult,
	'maxNew'=> $maxNew,
	'maxConsume'=> $maxConsume,
	'maxSave'=> $maxSave,
	'maxCirculateGet' => $maxCirculateGet,
	'maxCirculateConsume' => $maxCirculateConsume,
	'totalSaveSilver' => $rsSave['totalSaveSilver'],
	'totalSaveBindSilver' => $rsSave['totalSaveBindSilver'],
);
render('analysis/silver_save_and_consume.tpl', $data);