<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Dec 06 09:26:09 GMT 2011
 * @desc 创建角色页流失率统计
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$searchType = intval($_POST['searchType']);
$searchType = $searchType ? $searchType : 1;
$arrSearchType = array(
    1 => '按天统计',
    2 => '分时统计',
);
if(isPost()){
	$startTime = strtotime($_POST['startTime']);
	$endTime = strtotime($_POST['endTime']);
}
$startTime = $startTime ? $startTime : strtotime('-15day');
$endTime = $endTime ? $endTime : strtotime(date('Y-m-d H:i',time()))-600;

$tblAccess = 't_log_access';
$tblCreatePage = 't_log_create_page';
$tblRegister = 't_log_register';
$tblFirstView = 't_log_first_view';
$tblFirstMission = 't_log_first_mission';

$result = array();
if(1 == $searchType){
    $arrSql = array(
        'Access'     => " SELECT mDateTime, COUNT(DISTINCT accountName) AS cnt FROM {$tblAccess}       WHERE mTime >= {$startTime} AND mTime <= {$endTime} group by mDateTime order by mDateTime",
        'CreatePage' => " SELECT mDateTime, COUNT(DISTINCT accountName) AS cnt FROM {$tblCreatePage}   WHERE mTime >= {$startTime} AND mTime <= {$endTime} group by mDateTime order by mDateTime",
        'Register'   => " SELECT mDateTime, COUNT(DISTINCT roleId)      AS cnt FROM {$tblRegister}     WHERE mTime >= {$startTime} AND mTime <= {$endTime} group by mDateTime order by mDateTime ",
        'FirstView'  => " SELECT mDateTime, COUNT(DISTINCT accountName) AS cnt FROM {$tblFirstView}    WHERE mTime >= {$startTime} AND mTime <= {$endTime} GROUP BY mDateTime order by mDateTime",
        'Mission'    => " SELECT mDateTime, COUNT(DISTINCT roleId)      AS cnt FROM {$tblFirstMission} WHERE mTime >= {$startTime} AND mTime <= {$endTime} group by mDateTime order by mDateTime",
    );
}elseif(2 == $searchType){
	$arrSql = array(
        'Access'     => " SELECT mHour, COUNT(DISTINCT accountName) AS cnt FROM {$tblAccess}       WHERE mTime >= {$startTime} AND mTime <= {$endTime} group by mHour",
        'CreatePage' => " SELECT mHour, COUNT(DISTINCT accountName) AS cnt FROM {$tblCreatePage}   WHERE mTime >= {$startTime} AND mTime <= {$endTime} group by mHour",
        'Register'   => " SELECT mHour, COUNT(DISTINCT roleId)      AS cnt FROM {$tblRegister}     WHERE mTime >= {$startTime} AND mTime <= {$endTime} group by mHour ",
        'FirstView'  => " SELECT mHour, COUNT(DISTINCT accountName) AS cnt FROM {$tblFirstView}    WHERE mTime >= {$startTime} AND mTime <= {$endTime} GROUP BY mHour",
        'Mission'    => " SELECT mHour, COUNT(DISTINCT roleId)      AS cnt FROM {$tblFirstMission} WHERE mTime >= {$startTime} AND mTime <= {$endTime} group by mHour",
    );
}
$result = array();

foreach ($arrSql as $key => $sql) {
	$rs = fetchRowSet($sql);
	foreach($rs as $row){
	    if(1 == $searchType){
	        $time = $row['mDateTime'] ;
	    }elseif(2 == $searchType){
	        $time = intval(trim($row['mHour']));
	    }
	    $result[$time][$key] = intval($row['cnt']);
	}
}

$allSum = array();
foreach($result  as &$r){
	$allSum['Access'] += $r['Access'];
	$allSum['CreatePage'] += $r['CreatePage'];
	$allSum['Register'] += $r['Register'];
	$allSum['FirstView'] += $r['FirstView'];
	$allSum['Mission'] += $r['Mission'];
	
    $r['LoadToCreateLose'] = $r['Access'] - $r['CreatePage'];     //加载创建角色页面时流失人数 = 平台注册数 - 进入到创建页人数
    $r['CreateLose'] = $r['CreatePage'] - $r['Register'];         //创建角色页流失人数 = 进入到创建页人数 - 创建角色的人数
    $r['LoadToGameLose'] = $r['Register'] - $r['FirstView'];      //加载游戏资源流失人数 = 创建角色的人数 - 进入到欢迎窗口人数
    $r['NotFinishMission'] = $r['FirstView'] - $r['Mission'];     //第一个任务流失人数 = 进入到欢迎窗口人数 - 完成首个任务的人数
    $r['NewUserLose'] = $r['Access'] - $r['Mission'];           //新手流失人数 = 平台注册数 - 完成第一个任务的人数

    $r['LoadToCreateLoseRate'] = $r['Access'] != 0 ? $r['LoadToCreateLose'] / $r['Access'] : 0 ; //加载创建角色页面流失率
    $r['CreateLoseRate'] = $r['CreatePage'] != 0 ? $r['CreateLose']/$r['CreatePage'] : 0; //创建角色页流率
    $r['LoadToGameLoseRate'] = $r['Register'] != 0 ? $r['LoadToGameLose']/$r['Register'] : 0; //加载游戏资源流失率
    $r['NotFinishMissionRate'] = $r['FirstView'] != 0 ? $r['NotFinishMission']/$r['FirstView'] : 0; //首个任务流失率
    $r['NewUserLoseRate'] = $r['Access'] != 0 ? $r['NewUserLose']/$r['Access'] : 0;       //新手流失率

    $r['LoadToCreateLoseRate'] = round($r['LoadToCreateLoseRate']*100 , 2);
    $r['CreateLoseRate'] = round($r['CreateLoseRate']*100 , 2);
    $r['LoadToGameLoseRate'] = round($r['LoadToGameLoseRate']*100 , 2);
    $r['NotFinishMissionRate'] = round($r['NotFinishMissionRate']*100 , 2);
    $r['NewUserLoseRate'] = round($r['NewUserLoseRate']*100 , 2);
}
	
$allSum['LoadToCreateLose'] = $allSum['Access'] - $allSum['CreatePage'];     //加载创建角色页面时流失人数 = 平台注册数 - 进入到创建页人数
$allSum['CreateLose'] = $allSum['CreatePage'] - $allSum['Register'];         //创建角色页流失人数 = 进入到创建页人数 - 创建角色的人数
$allSum['LoadToGameLose'] = $allSum['Register'] - $allSum['FirstView'];      //加载游戏资源流失人数 = 创建角色的人数 - 进入到欢迎窗口人数
$allSum['NotFinishMission'] = $allSum['FirstView'] - $allSum['Mission'];     //第一个任务流失人数 = 进入到欢迎窗口人数 - 完成首个任务的人数
$allSum['NewUserLose'] = $allSum['Access'] - $allSum['Mission'];           //新手流失人数 = 平台注册数 - 完成第一个任务的人数

$allSum['LoadToCreateLoseRate'] = $allSum['Access'] != 0 ? $allSum['LoadToCreateLose'] / $allSum['Access'] : 0 ; //加载创建角色页面流失率
$allSum['CreateLoseRate'] = $allSum['CreatePage'] != 0 ? $allSum['CreateLose']/$allSum['CreatePage'] : 0; //创建角色页流率
$allSum['LoadToGameLoseRate'] = $allSum['Register'] != 0 ? $allSum['LoadToGameLose']/$allSum['Register'] : 0; //加载游戏资源流失率
$allSum['NotFinishMissionRate'] = $allSum['FirstView'] != 0 ? $allSum['NotFinishMission']/$allSum['FirstView'] : 0; //首个任务流失率
$allSum['NewUserLoseRate'] = $allSum['Access'] != 0 ? $allSum['NewUserLose']/$allSum['Access'] : 0;       //新手流失率

$allSum['LoadToCreateLoseRate'] = round($allSum['LoadToCreateLoseRate']*100 , 2);
$allSum['CreateLoseRate'] = round($allSum['CreateLoseRate']*100 , 2);
$allSum['LoadToGameLoseRate'] = round($allSum['LoadToGameLoseRate']*100 , 2);
$allSum['NotFinishMissionRate'] = round($allSum['NotFinishMissionRate']*100 , 2);
$allSum['NewUserLoseRate'] = round($allSum['NewUserLoseRate']*100 , 2);

$data=array(
    'arrSearchType'=> &$arrSearchType,
    'searchType'=> &$searchType,
    'result' => &$result,
    'allSum' => &$allSum,
    'startTime'=>date('Y-m-d H:i',$startTime),
    'endTime'=>date('Y-m-d H:i',$endTime),
);
render('analysis/create_user_stat.tpl',$data);