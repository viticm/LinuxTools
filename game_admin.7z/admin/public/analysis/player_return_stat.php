<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Dec 30 11:43:17 GMT 2011
 * @desc 玩家回访率统计
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$serverOnlineTime = strtotime(SERVER_ONLINE_DATE);
$yestoday = strtotime(date('Y-m-d',strtotime('-1day')));

$tmpStartTime = strtotime($_POST['startDate']);
$tmpEndTime = strtotime($_POST['endDate']);
$startTime = $tmpStartTime ? $tmpStartTime  : strtotime(date('Y-m-d',strtotime('-7day')));
$startTime = $startTime < $serverOnlineTime ? $serverOnlineTime : $startTime;
$endTime = !$tmpEndTime || $tmpEndTime > $yestoday ? $yestoday : $tmpEndTime;
$startDate = date('Y-m-d',$startTime);
$endDate = date('Y-m-d',$endTime);
$diffDay = ( $endTime - $startTime ) / 86400;

$intvalDay = intval($_POST['intvalDay']);
if( empty($intvalDay) ) { 
    $intvalDay = $diffDay;
}
//$intvalDay = $intvalDay > 1 && $intvalDay < $diffDay ? $intvalDay : $diffDay;

$showType = intval($_POST['showType']);
$arrShowType = array(
	0=>'全部',
	1=>'首次回访',
);

$sqlCnt = " select count(`roleId`) as regCnt from t_stat_return where regDate BETWEEN {$startTime} and {$endTime} ";
$rsCnt = fetchRowOne($sqlCnt);
$regCnt = intval($rsCnt['regCnt']);
if (1==$showType) {
	$sql = " SELECT COUNT(roleId) as roleCnt, firstReturnDiffDay as returnDiffDay FROM t_stat_return 
			where firstReturnDiffDay>1 and firstReturnDiffDay <= {$intvalDay} and 
			regDate BETWEEN {$startTime} and {$endTime} 
			group by firstReturnDiffDay
			order by firstReturnDiffDay";
}else {
	$sql = " SELECT COUNT(roleId) as roleCnt, returnDiffDay FROM t_stat_return 
			where returnDiffDay>1 and returnDiffDay <= {$intvalDay} and 
			regDate BETWEEN {$startTime} and {$endTime}
			group by returnDiffDay
			order by returnDiffDay";
}
$rs = fetchRowSet($sql);
$arr = array();
foreach ($rs as $row) {
	$arr[$row['returnDiffDay']] = $row['roleCnt'];
}
$result = array();
$totalRet = 0;
for ($i=2; $i<=$intvalDay; $i++){
	$totalRet += $arr[$i];
	$result[$i]['roleCnt'] = $totalRet;
	$result[$i]['returnDiffDay'] = $i;
	$result[$i]['returnRate'] = $regCnt > 0 ? round($totalRet*100/$regCnt,2) : 0 ;
}
$totalRetRate = $regCnt > 0 ? round($totalRet*100/$regCnt,2) : 0 ; 

$data = array(
	'result'=>&$result,
	'intvalDay'=>$intvalDay,
	'showType'=>$showType,
	'arrShowType'=>$arrShowType,
	'totalRet'=>$totalRet,
	'regCnt'=>$regCnt,
	'totalRetRate'=>$totalRetRate,
	'startDate'=>$startDate,
	'endDate'=>$endDate,
);
render('analysis/player_return_stat.tpl',$data);
