<?php
/**
 * $Id item_use_stat.php
 * @uses to view the item use status
 * @author viticm<dhuchuanpd@gmail.com>
 * @date 2013-6-25
 */
// this anslysis does not make sense
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
include_once SYSDIR_ADMIN_CLASS.'/player.php';
include_once SYSDIR_ADMIN_DICT.'/dict.php';
include_once SYSDIR_ADMIN_DICT.'/item_type.php';
include_once SYSDIR_ADMIN_DICT.'/goods.php';

$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp = strtotime($_POST['dateEnd']);
$dateStart = $dateStartStamp ? date('Y-m-d',$dateStartStamp) : date('Y-m-d',strtotime('-6day'));
$dateEnd = $dateEndStamp ? date('Y-m-d',$dateEndStamp) : date('Y-m-d');
$dateStartStamp = strtotime($dateStart);
$dateEndStamp = strtotime($dateEnd);

//===============start 查角色==============//
$role = $_POST['role'];
$msg = array();
if ($role['roleId'] || $role['roleName'] || $role['accountName'] ) {
	$role = Player::getUser($role['roleName'], $role['accountName'], $role['roleId']);
	if (!$role['roleId']) {
		$msg[] = '找不到对应玩家';
	}
}
//===============end 查角色===============//

$where  = " where `mDateTime`>={$dateStartStamp} and `mDateTime` <= {$dateEndStamp} ";
$where .= $role['roleId'] ? " and roleId = {$role['roleId']} ":'';

//===========查出符合条件的数据=======
$sql = " select `mType` , sum(`amount`) as item, 0 as bindItem,  count(*) as cnt, sum(`amount`) as totalAmount
         from t_log_item {$where}  group by `mType` ";
$rs = fetchRowSet($sql);
//=================================

$consume = array(); //系统获得(玩家失去)
$get = array(); //系统失去(玩家获得)
$circulateConsume = array(); //(玩家交易失去)
$circulateGet = array();//(玩家交易获得)
$consumeItem = 0;
$consumeBindItem = 0;
$consumeAllItem = 0;
$getItem = 0;
$getBindItem = 0;
$getAllItem = 0;
$circulateConsumeItem = 0;
$circulateConsumeBindItem = 0;
$circulateConsumeAllItem = 0;
$circulateGetItem = 0;
$circulateGetBindItem = 0;
$circulateGetAllItem = 0;

foreach ( $rs as &$row )
{
	if (!$dictItemType[$row['mType']]) {
		continue;
	}
	$row['sumItem'] =  $row['item']+$row['bindItem'];
	$row['mTypeText'] = $dictItemType[$row['mType']];
	if ($row['mType']>=10000 && $row['mType']<=19999 ) {
		$get[] = $row;
		$getItem += $row['item'];
		$getBindItem += $row['bindItem'];
		$getAllItem += $row['sumItem'] ;
	}elseif ($row['mType']>=20000 && $row['mType']<=29999 ) {
		$consume[] = $row;
		$consumeItem += $row['item'];
		$consumeBindItem += $row['bindItem'];
		$consumeAllItem += $row['sumItem'] ;
	}elseif ($row['mType']>=70000 && $row['mType']<=79999 ) {
		$circulateConsume[] = $row;
		$circulateConsumeItem = +$row['item'];
		$circulateConsumeBindItem += $row['bindItem'];
		$circulateConsumeAllItem += $row['sumItem'] ;
	}elseif ($row['mType']>=80000 && $row['mType']<=89999 ) {
		$circulateGet[] = $row;
		$circulateGetItem += $row['item'];
		$circulateGetBindItem += $row['bindItem'];
		$circulateGetAllItem += $row['sumItem'] ;
	}
}

foreach ( $consume as &$consumeRow )
{
	$consumeRow['sumItemRate'] =  $consumeAllItem > 0 ? round($consumeRow['sumItem'] * 100 / $consumeAllItem,2) :0 ;
	$consumeRow['itemRate']    =  $consumeItem > 0 ? round($consumeRow['item'] * 100 / $consumeItem,2) :0 ;
	$consumeRow['bindItemRate']  =  $consumeBindItem > 0 ? round($consumeRow['bindItem'] * 100 / $consumeBindItem,2) :0 ;
}

foreach ( $get as &$getRow )
{
	$getRow['sumItemRate'] =  $getAllItem > 0 ? round($getRow['sumItem'] * 100 / $getAllItem,2) :0 ;
	$getRow['itemRate']    =  $getItem > 0 ? round($getRow['item'] * 100 / $getItem,2) :0 ;
	$getRow['bindItemRate']  =  $getBindItem > 0 ? round($getRow['bindItem'] * 100 / $getBindItem,2) :0 ;
}

foreach ( $circulateConsume as &$circulateConsumeRow )
{
	$circulateConsumeRow['sumItemRate'] =  $circulateConsumeAllItem > 0 ? round($circulateConsumeRow['sumItem'] * 100 / $circulateConsumeAllItem,2) :0 ;
	$circulateConsumeRow['itemRate']    =  $circulateConsumeItem > 0 ? round($circulateConsumeRow['item'] * 100 / $circulateConsumeItem,2) :0 ;
	$circulateConsumeRow['bindItemRate']  =  $circulateConsumeBindItem > 0 ? round($circulateConsumeRow['bindItem'] * 100 / $circulateConsumeBindItem,2) :0 ;
}

foreach ($circulateGet as &$circulateGetRow)
{
	$circulateGetRow['sumItemRate'] =  $circulateGetAllItem > 0 ? round($circulateGetRow['sumItem'] * 100 / $circulateGetAllItem,2) :0 ;
	$circulateGetRow['itemRate']    =  $circulateGetItem > 0 ? round($circulateGetRow['item'] * 100 / $circulateGetItem,2) :0 ;
	$circulateGetRow['bindItemRate']  =  $circulateGetBindItem > 0 ? round($circulateGetRow['bindItem'] * 100 / $circulateGetBindItem,2) :0 ;
}

$data = array(
	'dateStart'                      => &$dateStart                    ,
	'dateEnd'                        => &$dateEnd                      ,
	'role'                           => &$role                         ,
	'consume'                        => &$consume                      ,
	'get'                            => &$get                          ,
	'circulateConsume'               => &$circulateConsume             ,
	'circulateGet'                   => &$circulateGet                 ,
	'consumeItem'                    => &$consumeItem                  ,
	'consumeBindItem'                => &$consumeBindItem              ,
	'consumeAllItem'                 => &$consumeAllItem               ,
	'getItem'                        => &$getItem                      ,
	'getBindItem'                    => &$getBindItem                  ,
	'getAllItem'                     => &$getAllItem                   ,
	'circulateConsumeItem'           => &$circulateConsumeItem         ,
	'circulateConsumeBindItem'       => &$circulateConsumeBindItem     ,
	'circulateConsumeAllItem'        => &$circulateConsumeAllItem      ,
	'circulateGetItem'               => &$circulateGetItem             ,
	'circulateGetBindItem'           => &$circulateGetBindItem         ,
	'circulateGetAllItem'            => &$circulateGetAllItem          ,
	'msg'                            => empty( $msg ) ? '' : implode( '<br>', $msg ) ,
);
render('analysis/item_use_stat.tpl',&$data);
