<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Dec 16 08:08:25 GMT 2011
 * @desc ip 统计
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
$status = intval($_POST['status']);
$status = $status ? $status : 1; //默认只取在线的
if (1 == $status) {
	$where = " and last_login_time>last_logout_time ";
}
$sqlIp = "SELECT COUNT(*) AS roleCnt, last_logout_ip AS lastLoginIp, MIN(last_login_time) AS minLoginTime, 
				MAX(last_login_time) AS maxLoginTime 
			FROM PLAYER_TBL WHERE last_logout_ip !='' {$where}  GROUP BY last_logout_ip LIMIT 100 ";
$ipArr = GFetchRowSet($sqlIp);

$data = array(
	'ipArr'=>&$ipArr,
	'status'=>&$status,
);
render('analysis/ip.tpl',&$data);