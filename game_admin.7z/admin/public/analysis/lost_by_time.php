<?php
/**
 * @author linruirong@4399.com
 * @Created  Thu Dec 08 12:39:03 GMT 2011
 * @desc 时间流失率统计
 */

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$dateStart = SS($_POST['dateStart']);
$dateEnd = SS($_POST['dateEnd']);

if(isPost()){
     $dateStartStamp = strtotime($dateStart);
     $dateEndStamp   = strtotime($dateEnd);
    if(!$dateStartStamp){
       $dateStart= date('Y-m-d',strtotime('-6day'));
    }
    if(!$dateEndStamp){
        $dateEnd = date('Y-m-d');
    }
}
$dateStart = $dateStart ? $dateStart : date('Y-m-d',strtotime(SERVER_ONLINE_DATE));
$dateEnd = $dateEnd ? $dateEnd : strftime("%Y-%m-%d",time());
$dateStartTamp = strtotime($dateStart.'0:0:0');
$dateEndTamp = strtotime($dateEnd.'23:59:59');

$arrDays = array(
	array( 'min'=>0 , 'max'=>1  ,    'desc'=>'不足1天', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>1 , 'max'=>2  ,    'desc'=>'1天',     'num'=>0, 'percent'=>0 ),
	array( 'min'=>2 , 'max'=>3  ,    'desc'=>'2天',     'num'=>0, 'percent'=>0 ),
	array( 'min'=>3 , 'max'=>4  ,    'desc'=>'3天',     'num'=>0, 'percent'=>0 ),
	array( 'min'=>4 , 'max'=>5  ,    'desc'=>'4天',     'num'=>0, 'percent'=>0 ),
	array( 'min'=>5 , 'max'=>6  ,    'desc'=>'5天',     'num'=>0, 'percent'=>0 ),
	array( 'min'=>6 , 'max'=>7  ,    'desc'=>'6天',     'num'=>0, 'percent'=>0 ),
	array( 'min'=>7 , 'max'=>8  ,    'desc'=>'7天',     'num'=>0, 'percent'=>0 ),
	array( 'min'=>8 , 'max'=>9  ,    'desc'=>'8天',     'num'=>0, 'percent'=>0 ),
	array( 'min'=>9 , 'max'=>10 ,    'desc'=>'9天',     'num'=>0, 'percent'=>0 ),
	array( 'min'=>10, 'max'=>11 ,    'desc'=>'10天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>11, 'max'=>12 ,    'desc'=>'11天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>12, 'max'=>13 ,    'desc'=>'12天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>13, 'max'=>14 ,    'desc'=>'13天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>14, 'max'=>15 ,    'desc'=>'14天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>15, 'max'=>16 ,    'desc'=>'15天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>16, 'max'=>17 ,    'desc'=>'16天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>17, 'max'=>18 ,    'desc'=>'17天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>18, 'max'=>19 ,    'desc'=>'18天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>19, 'max'=>20 ,    'desc'=>'19天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>20, 'max'=>21 ,    'desc'=>'20天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>21, 'max'=>22 ,    'desc'=>'21天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>22, 'max'=>23 ,    'desc'=>'22天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>23, 'max'=>24 ,    'desc'=>'23天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>24, 'max'=>25 ,    'desc'=>'24天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>25, 'max'=>26 ,    'desc'=>'25天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>26, 'max'=>27 ,    'desc'=>'26天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>27, 'max'=>28 ,    'desc'=>'27天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>28, 'max'=>29 ,    'desc'=>'28天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>29, 'max'=>30 ,    'desc'=>'29天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>30, 'max'=>31 ,    'desc'=>'30天',    'num'=>0, 'percent'=>0 ),
	array( 'min'=>31, 'max'=>9999999, 'desc'=>'30天以上', 'num'=>0, 'percent'=>0 ),
);

$arrMinutes = array(
	array( 'min'=>0   , 'max'=>1   , 'desc'=>'不足1分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>1   , 'max'=>2   , 'desc'=>'1-2分钟',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>2   , 'max'=>3   , 'desc'=>'2-3分钟',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>3   , 'max'=>4   , 'desc'=>'3-4分钟',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>4   , 'max'=>5   , 'desc'=>'4-5分钟',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>5   , 'max'=>6   , 'desc'=>'5-6分钟',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>6   , 'max'=>7   , 'desc'=>'6-7分钟',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>7   , 'max'=>8   , 'desc'=>'7-8分钟',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>8   , 'max'=>9   , 'desc'=>'8-9分钟',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>9   , 'max'=>10  , 'desc'=>'9-10分钟',  'num'=>0, 'percent'=>0 ),
	array( 'min'=>10  , 'max'=>11  , 'desc'=>'10-11分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>11  , 'max'=>12  , 'desc'=>'11-12分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>12  , 'max'=>13  , 'desc'=>'12-13分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>13  , 'max'=>14  , 'desc'=>'13-14分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>14  , 'max'=>15  , 'desc'=>'14-15分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>15  , 'max'=>16  , 'desc'=>'15-16分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>16  , 'max'=>17  , 'desc'=>'16-17分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>17  , 'max'=>18  , 'desc'=>'17-18分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>18  , 'max'=>19  , 'desc'=>'18-19分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>19  , 'max'=>20  , 'desc'=>'19-20分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>20  , 'max'=>25  , 'desc'=>'20-25分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>25  , 'max'=>30  , 'desc'=>'25-30分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>30  , 'max'=>35  , 'desc'=>'30-35分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>35  , 'max'=>40  , 'desc'=>'35-40分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>40  , 'max'=>45  , 'desc'=>'40-45分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>45  , 'max'=>50  , 'desc'=>'45-50分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>50  , 'max'=>55  , 'desc'=>'50-55分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>55  , 'max'=>60  , 'desc'=>'55-60分钟', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>60  , 'max'=>120 , 'desc'=>'1-2小时',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>120 , 'max'=>180 , 'desc'=>'2-3小时',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>180 , 'max'=>240 , 'desc'=>'3-4小时',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>240 , 'max'=>300 , 'desc'=>'4-5小时',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>300 , 'max'=>360 , 'desc'=>'5-6小时',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>360 , 'max'=>420 , 'desc'=>'6-7小时',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>420 , 'max'=>480 , 'desc'=>'7-8小时',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>480 , 'max'=>540 , 'desc'=>'8-9小时',   'num'=>0, 'percent'=>0 ),
	array( 'min'=>540 , 'max'=>600 , 'desc'=>'9-10小时',  'num'=>0, 'percent'=>0 ),
	array( 'min'=>600 , 'max'=>900 , 'desc'=>'10-15小时', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>900 , 'max'=>1200, 'desc'=>'15-20小时', 'num'=>0, 'percent'=>0 ),
	array( 'min'=>1200, 'max'=>1440, 'desc'=>'20-24小时', 'num'=>0, 'percent'=>0 ),
);

$sqlDays = "SELECT FLOOR((tmp.logoutTime - re.mTime)/86400) AS days, COUNT(re.roleId) AS num
            FROM `t_log_register` re, (SELECT MAX(logoutTime) AS logoutTime, roleId FROM `t_log_logout` GROUP BY roleId) AS tmp
            WHERE re.roleId=tmp.roleId AND  re.mTime between {$dateStartTamp} and {$dateEndTamp}
            GROUP BY days ORDER BY days ASC ";
$rsDays = fetchRowSet($sqlDays);

$sqlMinutes = "SELECT FLOOR((tmp.logoutTime - re.mTime)/60) AS minutes, COUNT(re.roleId) AS num
            FROM `t_log_register` re, (SELECT MAX(logoutTime) AS logoutTime, roleId FROM `t_log_logout` GROUP BY roleId) AS tmp
            WHERE re.roleId=tmp.roleId AND re.mTime between {$dateStartTamp} and {$dateEndTamp}
            GROUP BY minutes ORDER BY minutes ASC ";
$rsMinutes = fetchRowSet($sqlMinutes);

$totalDayNum = 0;
foreach ($rsDays as $row) {
	foreach ($arrDays as &$day) {
		if ($row['days'] >= $day['min'] && $row['days'] < $day['max'] ) {
			$day['num'] += $row['num'];
			$totalDayNum += $row['num'];
			break;
		}
	}
}

$totalMinuteNum = 0;
foreach ($rsMinutes as $row) {
	foreach ($arrMinutes as &$minute) {
		if ($row['minutes'] >= $minute['min'] && $row['minutes'] < $minute['max'] ) {
			$minute['num'] += $row['num'];
			$totalMinuteNum += $row['num'];
			break;
		}
	}
}
if ($totalMinuteNum > 0) {
	foreach ($arrMinutes as &$m) {
		if ($m['num'] > 0) {
			$m['percent'] = round($m['num']*100/$totalMinuteNum,2).'%';
		}else {
			$m['percent'] = '';
		}
	}
}

if ($totalDayNum > 0) {
	foreach ($arrDays as &$d) {
		if ($d['num'] > 0) {
			$d['percent'] = round($d['num']*100/$totalDayNum,2).'%';
		}else {
			$d['percent'] = '';
		}
	}
}

$Arr_MinuteDesc = array();
$Arr_MinuteLost = array();

foreach ( $arrMinutes as $key => $val )
{
    array_push( $Arr_MinuteDesc, $val[ 'desc' ] );
    array_push( $Arr_MinuteLost, $val[ 'num' ] );
}
$data = array(
	'arrDays' => &$arrDays,
	'arrMinutes' => &$arrMinutes,
	'dateStart'  => $dateStart,
	'dateEnd'  => $dateEnd,
	'totalDayNum'=>$totalDayNum,
	'totalMinuteNum'=>$totalMinuteNum,
    'cMinuteDescStr' => '"' .implode( '","', $Arr_MinuteDesc ). '"',
    'cMinuteLostStr' => implode( ',', $Arr_MinuteLost )
);

render('analysis/lost_by_time.tpl',$data);