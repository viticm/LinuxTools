<?php

include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';

$dateStart = SS($_POST['dateStart']);
$dateEnd = SS($_POST['dateEnd']);
if(isPost()){
     $dateStartStamp = strtotime($dateStart);
     $dateEndStamp   = strtotime($dateEnd);
    if(!$dateStartStamp){
       $dateStart= date('Y-m-d');
    }
    if(!$dateEndStamp){
        $dateEnd = date('Y-m-d');
    }
}
$dateStart = $dateStart ? $dateStart : strftime("%Y-%m-%d",time());
$dateEnd = $dateEnd ? $dateEnd : strftime("%Y-%m-%d",time());
$dateStartTamp = strtotime($dateStart.'0:0:0');
$dateEndTamp = strtotime($dateEnd.'23:59:59');

$logTimesArr = array();
$logTimesArr = array(
		array('start'=>'1','end'=>'2'),
		array('start'=>'2','end'=>'3'),
		array('start'=>'3','end'=>'4'),
		array('start'=>'4','end'=>'5'),
		array('start'=>'5','end'=>'6'),
		array('start'=>'6','end'=>'8'),
		array('start'=>'8','end'=>'10'),
		array('start'=>'10','end'=>'15'),
		array('start'=>'15','end'=>'20'),
		array('start'=>'20','end'=>'25'),
		array('start'=>'25','end'=>'30'),
		array('start'=>'30','end'=>'50'),
		array('start'=>'50','end'=>'80'),
		array('start'=>'80','end'=>'100'),
		array('start'=>'100','end'=>'MAX'),
);
$sql = "select count(roleId) as num  from `t_log_logout` where loginTime >= {$dateStartTamp} and loginTime <= {$dateEndTamp}
					group by roleId";
$res = fetchRowSet($sql);
$i=0;
$allData = 0;
foreach($logTimesArr as $log_times){
		$count_num = 0;
		if($log_times[end]=='MAX'){
			foreach($res as $num){
				if($num['num']>=$log_times[start]){
					$count_num++;
				}
			}
		}
		else{
			foreach($res as $num){
				if($num['num']>=$log_times[start] and $num['num']<$log_times[end]){
					$count_num++;
				}
			}
		}
		$logTimesArr[$i]['data'] = $count_num;
		$allData +=  $logTimesArr[$i]['data'];
		$i++;
}


$data = array(
	'dateStart'=>$dateStart,
	'dateEnd'=>$dateEnd,
	'logTimesArr' => $logTimesArr,
	'allData' => $allData,
);

render('analysis/login_data_stat.tpl', $data);

