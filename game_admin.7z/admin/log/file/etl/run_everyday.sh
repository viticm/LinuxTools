#!/bin/bash

#############################################
## 此脚本于crontab中每凌晨运行一次.
## 注意 以本配置中 除了 logBaseDir 其他最好不要乱改
#############################################
export LANG="en_US.UTF-8"
curDir=`dirname ${0}`
cd ${curDir}

logBaseDir='/data/logs/yjxy/'
serverConf='../server.conf'
phpPath='/usr/local/php/bin/php'

if [ ! -f ${serverConf} ] ; then
	echo "server config file not exists"
	exit 1
fi
name=([0]="stat_gold.php"
      [1]="stat_silver.php"
      [2]="stat_return.php")

serverItems=`cat ${serverConf}| grep -v "#"`
for server in ${serverItems} 
do
	for program in ${name[*]}
	do
		${phpPath} ${program} ${server}  >> "${logBaseDir}${server}/crontab.log" 2>&1 &
	done
done
