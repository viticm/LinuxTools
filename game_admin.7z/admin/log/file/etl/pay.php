<?php
/**
 * @author linruirong@4399.com
 * @Created  Thu Dec 08 08:52:11 GMT 2011
 * @desc 用于处理充值日志
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');
include_once('../log_config.php');
include_once('../log_template.php');
include_once SYSDIR_ADMIN_CLASS.'/player.php';

class Pay extends LogTemplate {
	private $arrPayTimes = array();
	public function __construct($gameLog)
	{
		parent::__construct('t_log_pay',&$gameLog);
	}
	
	/**
	 * 转换数据
	 *                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
	 * @param array $data
	 * @return array
	 */
	public function fomateData(&$data){
		foreach ($this->fields as &$fieldsName) {
			$lineData[$fieldsName] = &$data[$fieldsName]; //抽取共有的字段
		}
		$role = Player::getUser('',$lineData['accountName']);
		$lineData['roleId'] = $role['roleId'];
		$lineData['roleName'] = $role['roleName'];
		$lineData['roleLevel'] = $role['roleLevel'];
		if (!$this->arrPayTimes[$lineData['roleId']]) {
			$sqlCnt = " select count(*) as totalTimes from t_log_pay where roleId={$lineData['roleId']} ";
			$rsCnt = fetchRowOne($sqlCnt);
			$this->arrPayTimes[$lineData['roleId']] = intval($rsCnt['totalTimes'])+1; //总充值次数加1
		}else {
			$this->arrPayTimes[$lineData['roleId']] += 1;
		}
		
		$lineData['totalTimes'] = $this->arrPayTimes[$lineData['roleId']]; //本次第几次充值
		$lineData['mDateTime'] = strtotime(date('Y-m-d', $lineData['mTime']));
		$lineData['mYear'] = date('Y', $lineData['mTime']);
		$lineData['mMonth'] = date('m', $lineData['mTime']);
		$lineData['mDate'] = date('d', $lineData['mTime']);
		$lineData['mHour'] = date('H', $lineData['mTime']);
		$lineData['mWeek'] = date('w', $lineData['mTime']);
		$lineData['onlineDays'] = intval((strtotime(date('Y-m-d'))-strtotime(SERVER_ONLINE_DATE))/86400)+1;
		
		
		return array( //按实体表的字段顺序整理,以确保load进数据表里后，数据对应正确
			&$lineData['roleId'],
			&$lineData['roleName'],
			&$lineData['accountName'],
			&$lineData['orderId'],
			&$lineData['payMoney'],
			&$lineData['payGold'],
			&$lineData['roleLevel'],
			&$lineData['totalTimes'],
			&$lineData['mTime'],
			&$lineData['mDateTime'],
			&$lineData['mYear'],
			&$lineData['mMonth'],
			&$lineData['mDate'],
			&$lineData['mHour'],
			&$lineData['mWeek'],
			&$lineData['onlineDays'],
		);
	}
}
//================================================
$objPay = new Pay($argv[2]);
$objPay->extractAndTransform();
$objPay->loadIntoDb();
