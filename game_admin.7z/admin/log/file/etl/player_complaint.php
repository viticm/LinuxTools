<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Dec 06 03:24:54 GMT 2011
 * @desc 用于处理玩家投诉日志
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');
include_once('../log_config.php');
include_once('../log_template.php');

class PlayerComplaint extends LogTemplate {
	
	private $arrComplaint = array();
	public function __construct($gameLog)
	{
		parent::__construct('t_player_complaint',&$gameLog);
	}

	/**
	 * 抽取并转换日志
	 *
	 */
	public function extractAndTransform ()
	{
		$logFile = &$this->gameLog;
		if (!file_exists($logFile)) {//如果文件不存在,直接退出
			return false;
		}
		$fplog = fopen($logFile,'r');
		$headerFields = fgetcsv($fplog); //读取第一行,表头定义
		if (1==count($headerFields) && null === $headerFields[0]){
			$this->ok = false;
			$this->mvLog($logFile, SYSDIR_GAME_LOG_ERROR);
			$this->etlLog($logFile,"未定义表头");
			return false;
		}
		//去掉表头字段中的空格
		foreach ($headerFields as $key => &$fieldName) {
			$headerFields[$key] = trim($fieldName);
		}
		$line = 2; //从第二行开始算
		while ($data = fgetcsv($fplog)) {
			if (1==count($data) && null === $data[0]) {
				$line++;
				continue;//忽略空行
			}else {
				if (count($headerFields) != count($data) ) {
					$this->ok = false;
					$this->mvLog($logFile, SYSDIR_GAME_LOG_ERROR);
					$this->etlLog($logFile,"第{$line}行 数据列数与表头列数不相等");
					return false;
				}
				//转换数据
				$this->arrComplaint[] = $this->fomateData(array_combine($headerFields, $data));
			}
			$line++;
		}
		fclose($fplog);
	}
	
	/**
	 * 转换数据
	 *
	 */
	public function fomateData(&$data){
		foreach ($this->fields as &$fieldsName) {
			$lineData[$fieldsName] = &$data[$fieldsName];
			$lineData['agentId'] = AGENT_ID;
			$lineData['serverId'] = SERVER_ID;
		}
		$lineData['roleId'] = intval($lineData['roleId']);
		$sqlPay = " select sum(payMoney) as totalPay from t_log_pay where `roleId`={$lineData['roleId']} ";
		$rsPay = fetchRowOne($sqlPay);
		$lineData['totalPay'] = $rsPay['totalPay'];
		return $lineData;
	}

	
	public function syncComplaint()
	{
		if ($this->ok) {
			$base64Complaint = trim(base64_encode(base64_encode(json_encode($this->arrComplaint))),'=');
			$ticket = md5(GM_SYSTEM_AUTH_KEY.$base64Complaint);
			$result = curlPost(GM_SYNC_COMPLAINT_URL,"ticket={$ticket}&base64Complaint={$base64Complaint}");
			$result = json_decode($result,true);
			if (1==$result['result']) {
				$this->ok = true;
				$this->mvLog($this->gameLog, SYSDIR_GAME_LOG_OK);
			}
		}
	}
}

//================================================
$objPlayerComplaint = new PlayerComplaint($argv[2]);
$objPlayerComplaint->extractAndTransform();
$objPlayerComplaint->syncComplaint();
