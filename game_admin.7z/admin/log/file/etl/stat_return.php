<?php
/**
 * @author linruirong@4399.com
 * @Created  Thu Dec 29 11:02:12 GMT 2011
 * @desc 回访率统计 每天凌晨定时跑前一天数据。算出前一天回访问情况
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');
$yestodayDateTime = strtotime(date('Y-m-d',strtotime('-1day'))); //因为此脚本是放在凌晨跑的，所以时间应该往前推一天。
$dateTime = strtotime( $argv[2] );
$serverOnlineTime = strtotime(SERVER_ONLINE_DATE);
if (!$serverOnlineTime) {
	die('SERVER_ONLINE_DATE not set !');
}
if(isset($argv[2]) && !$dateTime){
	die('date error !');
}else {
	$mDateTime = $dateTime >= $serverOnlineTime && $dateTime <= $yestodayDateTime ? $dateTime : $yestodayDateTime;
}

$sqlInsert = " INSERT IGNORE INTO t_stat_return(`roleId`, `roleName`, `accountName`,`regDate`) SELECT roleId, roleName, accountName, mDateTime FROM t_log_register WHERE mDateTime={$mDateTime}  ";
dbQuery($sqlInsert);

$time = $mDateTime;

$sqlCnt = " select count(distinct roleId) as cnt from t_log_login where mDateTime={$time} ";
$rsCnt = fetchRowOne($sqlCnt);
$rowCount = $rsCnt['cnt'];
$perPage = 500;
$page = 0==$rowCount%$perPage ? $rowCount / $perPage : intval($rowCount/$perPage)+1;
for ($i=1; $i<=$page; $i++){
	$offset = $perPage * ($i-1);
	$sql = " SELECT l.roleId, MAX(l.roleLevel) as roleLevel from t_log_login l where l.mDateTime={$time} group by l.roleId limit {$offset}, {$perPage} ";
	$rs = fetchRowSet($sql);
	foreach ($rs as $r) {
		$sqlUpdate = " update t_stat_return set `roleLevel`='{$r['roleLevel']}', `firstLoginDate`='{$time}',`prevLoginDate`={$time}, `lastLoginDate`={$time} where `roleId`={$r['roleId']}  and  firstLoginDate=0 ";
		dbQuery($sqlUpdate);
		$sqlUpdate = " update t_stat_return set `secondLoginDate`={$time} where `roleId`={$r['roleId']}  and  firstLoginDate>0 and firstLoginDate<{$time} and secondLoginDate=0 ";
		dbQuery($sqlUpdate);
		$sqlUpdate = " update t_stat_return set `roleLevel`='{$r['roleLevel']}', `prevLoginDate`=`lastLoginDate`, `lastLoginDate`={$time} where `roleId`={$r['roleId']} ";
		dbQuery($sqlUpdate);
	}
}

$sqlUpdate = " UPDATE t_stat_return SET firstReturnDiffDay = ((secondLoginDate-firstLoginDate)/86400+1) where secondLoginDate>=firstLoginDate and secondLoginDate>0  and firstLoginDate >0 and lastLoginDate={$time} ";
dbQuery($sqlUpdate);

$sqlUpdate2 = " UPDATE t_stat_return SET  returnDiffDay =((lastLoginDate-prevLoginDate)/86400+1)  where lastLoginDate>=prevLoginDate and lastLoginDate>0  and prevLoginDate >0 and lastLoginDate={$time}";
dbQuery($sqlUpdate2);

$sqlUpdate3 = " UPDATE t_stat_return SET seqLoginDay=seqLoginDay+1 where lastLoginDate=prevLoginDate+86400 and lastLoginDate={$time}";
dbQuery($sqlUpdate3);

$sqlUpdate4 = " UPDATE t_stat_return SET seqLoginDay=1 where lastLoginDate<>prevLoginDate+86400 and lastLoginDate={$time}";
dbQuery($sqlUpdate4);
