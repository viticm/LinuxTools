<?php
/**
 * @author viticm<duchuanpd@gmail.com>
 * @date 2013-8-19 16:09:13
 * @uses 处理统计前一天的服务器概况信息（现在统计放在了授权系统，如果有需要再移到中央后台，现在一直没用）
 */
include_once( '../../../protected/config/config.php' ) ;
include_once( '../log_global.php' ) ;

define( SYNC_SERVER_SUMMARY_API_URL, GATEWAY_SYSTEM_URL.'api/servers_summary_api.php' ) ; // api for servers summary

$iDateTime = strtotime( date( 'Y-m-d', strtotime( '-1day' ) ) ) ; //因为此脚本是放在凌晨跑的，所以时间应该往前推一天。
$iServerOnlineTimeStamp = strtotime( SERVER_ONLINE_DATE ) ;
$iOneDaySeconds = 24 * 60 * 60 ;
$iStartTimeStamp = $iServerOnlineTimeStamp ;
$iEndTimeStamp   = $iDateTime ;

$iAgentId    = intval( AGENT_ID ) ;
$iServerId   = intval( SERVER_ID ) ;
$Arr_Summary[ 'onlineDays' ]    = ( $iEndTimeStamp - $iServerOnlineTimeStamp ) / $iOneDaySeconds + 1 ;

$szSqlStr = '' ;
$szSqlStr .= 'SELECT COUNT( `id` ) as `roleCnt`, max( `level` ) AS `maxLevel` FROM `PLAYER_TBL` WHERE `id` > 0' ;
$mResultRoleInfo = GFetchRowOne( $szSqlStr ) ;
$Arr_Summary[ 'totalRole' ]    = intval( $mResultRoleInfo[ 'roleCnt' ] ) ;
$Arr_Summary[ 'maxRoleLevel' ] = intval( $mResultRoleInfo[ 'maxLevel' ] ) ;

$szSqlStr = '' ;
$szSqlStr .= 'SELECT COUNT( DISTINCT a.`accountName` ) AS `totalAccount`  FROM `t_log_access` `a`' ;
$mResultAccount = fetchRowOne( $szSqlStr ) ;
$Arr_Summary[ 'totalAccount' ] = intval( $mResultAccount[ 'totalAccount' ] ) ;

$szSqlStr = '' ;
$szSqlStr .= 'SELECT COUNT( DISTINCT `roleId` ) AS `totalPayRole`, SUM( `payMoney` ) AS `totalPay`,  MAX( `payMoney` ) AS `maxPay` FROM `t_log_pay`' ;
$mResultPay = fetchRowOne( $szSqlStr ) ;
$Arr_Summary[ 'totalPay' ]        = intval( $mResultPay[ 'totalPay' ] ) ;
$Arr_Summary[ 'totalPayRole' ]    = intval( $mResultPay[ 'totalPayRole' ] ) ;
$Arr_Summary[ 'maxTotalPay' ]     = intval( $mResultPay[ 'maxPay' ] ) ;
$Arr_Summary[ 'totalAvgArpu' ]    = $mResultPay[ 'totalPayRole' ] > 0 ? round( $mResultPay[ 'totalPay' ] / $mResultPay[ 'totalPayRole' ], 2 ) : 0  ;

$szSqlStr = '' ;
$szSqlStr .= 'SELECT MAX( `online` ) AS `maxOnline` FROM `t_log_online`' ;
$mResultMaxOnline = fetchRowOne( $szSqlStr ) ;
$Arr_Summary[ 'totalMaxOnline' ] = intval( $mResultMaxOnline[ 'maxOnline' ] ) ;

$szSqlStr = '' ;
$szSqlStr .= 'SELECT AVG( `online` ) AS `avgOnline` FROM `t_log_online` WHERE `mHour` >= 8 AND `mHour` <= 23' ;
$mResultAvgOnline = fetchRowOne( $szSqlStr );
$Arr_Summary[ 'totalAvgOnline' ] = round( $mResultAvgOnline[ 'avgOnline' ] ) ;

$szSqlStr = '' ;
$szSqlStr .= 'SELECT SUM( `payMoney` ) AS `totalPay`, `mDateTime` FROM `t_log_pay`' ;
$szWhere  = '' ;
$szWhere  .= ' WHERE `mDateTime` BETWEEN ' .$iStartTimeStamp. ' AND ' .$iEndTimeStamp. ' GROUP BY `mDateTime`' ;
$szSqlStr .= $szWhere ;
$mResultDayPay = fetchRowSet( $szSqlStr ) ;
$iMaxDayPay = 0 ;
$iSelfDayPay = 0 ;
foreach ( $mResultDayPay as $row )
{
	if ( $row[ 'totalPay' ] > $iMaxDayPay ) {
		$iMaxDayPay = $row[ 'totalPay' ] ;
	}
	if ( $row[ 'mDateTime' ] == $iDateTime )
	{
	    $iSelfDayPay = $row[ 'totalPay' ] ;
	}
}
$Arr_Summary[ 'maxDayPay' ] = intval( $iMaxDayPay ) ;
$Arr_Summary[ 'selfDayPay' ] = intval( $iSelfDayPay ) ;

$szSqlStr = '' ;
$szSqlStr .= 'SELECT COUNT( DISTINCT `roleId` ) AS `loginCnt` FROM `t_log_logout` WHERE `loginDate` = ' .$iDateTime ;
$mResultLoginCnt = fetchRowOne( $szSqlStr ) ;
$Arr_Summary[ 'loginCnt' ] = intval( $mResultLoginCnt[ 'loginCnt' ] ) ;

$szSqlStr = '' ;
$szSqlStr .= 'SELECT COUNT( DISTINCT `roleId` ) AS `regCnt` FROM `t_log_register` WHERE `mDateTime` = ' .$iDateTime ;
$mResulRegCnt = fetchRowOne( $szSqlStr ) ;
$Arr_Summary[ 'regCnt' ] = intval( $mResulRegCnt[ 'regCnt' ] ) ;

// online day 1 3 7 retained precent
// login and retained count will be expand over one day
$iStartTime = $iServerOnlineTimeStamp ;
$iEndTime   = $iStartTime + 8 * $iOneDaySeconds ;

$Arr_Login = array();
// find all login count user in the interval date
$cSqlStr = '';
$cSqlStr .= "SELECT DISTINCT `roleId`, `loginDate`  from `t_log_logout` where `loginDate` >= {$iStartTime} and `loginDate` <= {$iEndTime}
    GROUP BY `loginDate`,`roleId` ORDER BY `loginDate` ASC";
$Arr_Login = fetchRowSet( $cSqlStr );
//find all new login from the date
$Arr_NewLogin = array();
$cSqlStr = '';
$cSqlStr .= 'SELECT DISTINCT `roleId`, `mDateTime` as `loginDate` from `t_log_register`';
$cSqlStr .= ' where `mDateTime` >= '.$iStartTime.' and `mDateTime` <= '.$iEndTime;
$cSqlStr .= ' GROUP BY `loginDate`,`roleId` ORDER BY `loginDate` ASC';

$Arr_NewLogin = fetchRowSet( $cSqlStr );

//get the all login id list and new login id list
$iLoginTime = $iStartTime;
$Arr_LoginIdList = array();
$Arr_NewLoginIdList = array();

while( $iLoginTime <= $iEndTime )
{
	$Arr_LoginIdList[ $iLoginTime ] = array();
	$Arr_NewLoginIdList[ $iLoginTime ] = array();
	foreach ( $Arr_Login as $key => $value )
	{
		if ( $iLoginTime == $value[ 'loginDate' ] )
		{
			array_push( $Arr_LoginIdList[ $iLoginTime ] , $value[ 'roleId' ] );
		}
	}
	foreach ( $Arr_NewLogin as $key => $value )
	{
		if ( $iLoginTime == $value[ 'loginDate' ] )
		{
			array_push( $Arr_NewLoginIdList[ $iLoginTime ], $value[ 'roleId' ] );
		}
	}
	$iLoginTime += $iOneDaySeconds;
}

//get login and retained array
// the result will reset the time to post
$iEndTime -= $iOneDaySeconds;
$Arr_LoginAndRetained = array();
$iLoginTime = $iStartTime;
while( $iLoginTime <= $iEndTime )
{
	$Arr_LoginAndRetained[ $iLoginTime ] = array();
	$Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ] = count( $Arr_LoginIdList[ $iLoginTime ] );
	$Arr_LoginAndRetained[ $iLoginTime ][ 'newLoginCount' ] = count( $Arr_NewLoginIdList[ $iLoginTime ] ) ;
	$iOneDayNewRetained = 0;
	if ( true === is_array( $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds ] ) )
	    $iOneDayNewRetained = count( array_intersect( $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds ], $Arr_NewLoginIdList[ $iLoginTime  ] ) );
	$Arr_LoginAndRetained[ $iLoginTime ][ 'oneDayNewRetained' ] = $iOneDayNewRetained;
	$fOneDayRetainedProportion = $Arr_LoginAndRetained[ $iLoginTime ][ 'newLoginCount' ] == 0 ? 0 : $iOneDayNewRetained /
	    $Arr_LoginAndRetained[ $iLoginTime ][ 'newLoginCount' ];
	$Arr_LoginAndRetained[ $iLoginTime ][ 'oneDayNewRetainedProportion' ] = $fOneDayRetainedProportion * 100;

	//get the 1、3、7 retained and proportion
	$iOneDayRetained = 0;
	if ( true === is_array( $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds ] ) )
	    $iOneDayRetained = count( array_intersect( $Arr_LoginIdList[ $iLoginTime ], $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds ] ) );
	$Arr_LoginAndRetained[ $iLoginTime ][ 'oneDayRetained' ] = $iOneDayRetained;
	$fOneDayRetainedProportion = 0 == $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ] ?
	    0 : $iOneDayRetained / $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ];
	$Arr_LoginAndRetained[ $iLoginTime ][ 'oneDayRetainedProportion' ] = $fOneDayRetainedProportion * 100;

	$iThreeDayRetained = 0;
	if ( true == is_array( $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds * 3 ] ) )
	    $iThreeDayRetained = count( array_intersect( $Arr_LoginIdList[ $iLoginTime ], $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds * 3 ] ) );
	$Arr_LoginAndRetained[ $iLoginTime ][ 'threeDayRetained' ] = $iThreeDayRetained;
	$fThreeDayRetainedProportion = 0 == $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ] ?
	    0 : $iThreeDayRetained / $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ];
	$Arr_LoginAndRetained[ $iLoginTime ][ 'threeDayRetainedProportion' ] = $fThreeDayRetainedProportion * 100;

	$iSevenDayRetained = 0;
    if ( true == is_array( $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds * 7 ] ) )
	    $iSevenDayRetained = count( array_intersect( $Arr_LoginIdList[ $iLoginTime ], $Arr_LoginIdList[ $iLoginTime + $iOneDaySeconds * 7 ] ) );
	$Arr_LoginAndRetained[ $iLoginTime ][ 'sevenDayRetained' ] = $iSevenDayRetained;
	$fSevenDayRetainedProportion = 0 == $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ] ?
	    0 : $iSevenDayRetained / $Arr_LoginAndRetained[ $iLoginTime ][ 'loginCount' ];
	$Arr_LoginAndRetained[ $iLoginTime ][ 'sevenDayRetainedProportion' ] = $fSevenDayRetainedProportion * 100;

	/*add one day seconds*/
	$iLoginTime += $iOneDaySeconds;
}

$szOnlineDayRetainedInfo = '' ;
$fOneDayRetainedProportionOfOnlineDay = round( $Arr_LoginAndRetained[ $iServerOnlineTimeStamp ][ 'oneDayRetainedProportion' ], 2 ) ;
$szOnlineDayRetainedInfo .= 0 == $fOneDayRetainedProportionOfOnlineDay ? '无、' : $fOneDayRetainedProportionOfOnlineDay.'%、' ;
$fthreeDayRetainedProportionOfOnlineDay = round( $Arr_LoginAndRetained[ $iServerOnlineTimeStamp ][ 'threeDayRetainedProportion' ], 2 ) ;
$szOnlineDayRetainedInfo .= 0 == $fthreeDayRetainedProportionOfOnlineDay ? '无、' : $fthreeDayRetainedProportionOfOnlineDay.'%、' ;
$fSevenDayRetainedProportionOfOnlineDay = round( $Arr_LoginAndRetained[ $iServerOnlineTimeStamp ][ 'sevenDayRetainedProportion' ], 2 ) ;
$szOnlineDayRetainedInfo .= 0 == $fSevenDayRetainedProportionOfOnlineDay ? '无' : $fSevenDayRetainedProportionOfOnlineDay.'%' ;

$Arr_Summary[ 'onlineDayRetainedInfo' ] = urlencode( $szOnlineDayRetainedInfo ) ;
$szSummaryJson = base64_encode( json_encode( $Arr_Summary ) ) ;
$iTimeStamp = time() ;
$szCheckKey = md5( $iTimeStamp.GATEWAY_SYSTEM_AUTH_KEY ) ;
$cMergeServerLog = base64_encode( json_encode( $Arr_Summary ) ) ;
$szAddServerSummaryParams = 'action=addServerSummary&agentId=' .$iAgentId. '&serverId=' .$iServerId.
    '&serverSummaryJson='.$szSummaryJson. '&key=' .$szCheckKey. '&timeStamp=' .$iTimeStamp. '&dateTime=' .$iDateTime ;
$Arr_Result = json_decode( urldecode( curlPost( SYNC_SERVER_SUMMARY_API_URL, $szAddServerSummaryParams ) ), true ) ;
if ( !$Arr_Result || 1 != $Arr_Result['ErrorCode'])
{
	$Arr_Result['ErrorDesc'] = $Arr_Result['ErrorDesc'] ? $Arr_Result['ErrorDesc'] : urlencode( 'API没有返回!' ) ;
	echo '【ERROR】 保存服务器概况信息失败:'. urldecode( $Arr_Result[ 'ErrorDesc' ] ) ;
}