<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Dec 30 16:26:25 GMT 2011
 * @desc 用于处理客户端资源加载进度日志
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');
include_once('../log_config.php');
include_once('../log_template.php');

class ClientLoad extends LogTemplate {
	public function __construct($gameLog)
	{
		parent::__construct('t_log_client_load',&$gameLog);
	}
	
	/**
	 * 转换数据
	 *
	 * @param array $data
	 * @return array
	 */
	public function fomateData(&$data){
		foreach ($this->fields as &$fieldsName) {
			$lineData[$fieldsName] = &$data[$fieldsName]; //抽取共有的字段
		}
		return array( //按实体表的字段顺序整理,以确保load进数据表里后，数据对应正确
			&$lineData['logId']      ,
			&$lineData['roleId']    ,
			&$lineData['roleName']    ,
			&$lineData['accountName'] ,
			&$lineData['roleLevel']   ,
			&$lineData['ip'] ,
			&$lineData['step'] ,
			&$lineData['mTime'],
			&$lineData['mDateTime'],
			&$lineData['mYear'],
			&$lineData['mMonth'],
			&$lineData['mDate'],
			&$lineData['mHour'],
			&$lineData['mWeek'],
		);
	}
}
//================================================
$objClientLoad = new ClientLoad($argv[2]);
$objClientLoad->extractAndTransform();
$objClientLoad->loadIntoDb();
