<?php
/**
 * @author linruirong@4399.com
 * @Created  Wed Dec 14 06:51:00 GMT 2011
 * @desc 用于处理 充值请求详细日志
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');
include_once('../log_config.php');
include_once('../log_template.php');

class PayRequest extends LogTemplate {
	
	private $arrLogs = array();
	
	public function __construct($gameLog)
	{
		parent::__construct('t_log_pay_request',&$gameLog);
	}
	
	/**
	 * 抽取并转换日志
	 *
	 */
	public function extractAndTransform ()
	{
		$logFile = &$this->gameLog;
		if (!file_exists($logFile)) {//如果文件不存在,直接退出
			return false;
		}
		$fplog = fopen($logFile,'r');
		$headerFields = fgetcsv($fplog); //读取第一行,表头定义
		if (1==count($headerFields) && null === $headerFields[0]){
			$this->ok = false;
			$this->mvLog($logFile, SYSDIR_GAME_LOG_ERROR);
			$this->etlLog($logFile,"未定义表头");
			return false;
		}
		//去掉表头字段中的空格
		foreach ($headerFields as $key => &$fieldName) {
			$headerFields[$key] = trim($fieldName);
		}
		$line = 2; //从第二行开始算
		while ($data = fgetcsv($fplog)) {
			if (1==count($data) && null === $data[0]) {
				$line++;
				continue;//忽略空行
			}else {
				if (count($headerFields) != count($data) ) {
					$this->ok = false;
					$this->mvLog($logFile, SYSDIR_GAME_LOG_ERROR);
					$this->etlLog($logFile,"第{$line}行 数据列数与表头列数不相等");
					return false;
				}
				//转换数据
				$this->arrLogs[] = $this->fomateData(array_combine($headerFields, $data));
			}
			$line++;
		}
		fclose($fplog);
	}
	
	/**
	 * 转换数据
	 *
	 * @param array $data
	 * @return array
	 */
	public function fomateData(&$data){
		foreach ($this->fields as &$fieldsName) {
			$lineData[$fieldsName] = &$data[$fieldsName]; //抽取共有的字段
		}
		return array( //按实体表的字段顺序整理,以确保load进数据表里后，数据对应正确
			&$lineData['logId'],
			&$lineData['payToUser'],
			&$lineData['userIp'],
			&$lineData['detail'],
			&$lineData['desc'],
			&$lineData['mTime'],
			&$lineData['action'],
		);
	}
	
	public function loadIntoDb()
	{
		$logFile = &$this->gameLog;
		$strKeys = '';
		$strValues = '';
		foreach ($this->fields as $k) {
			$strKeys.=" `{$k}`,";
		}
		$strKeys = trim($strKeys,',');
		foreach ($this->arrLogs as &$log ) {
			$strRowVal = '';
			foreach ($log as &$v) {
				$v = SS($v);
				$strRowVal.=" '{$v}',";
			}
			$strRowVal = trim($strRowVal,',');
			$strValues .= "({$strRowVal}),";
		}
		$strValues = trim($strValues,',');
		$sql = " replace into {$this->tableName} ($strKeys) values {$strValues}  ";
		try {
			$result = dbQuery($sql);
			if ($result) {
				$this->ok = true;
				$this->mvLog($logFile, SYSDIR_GAME_LOG_OK);
			}else {
				$this->ok = false;
				$this->etlLog($logFile,"无法载入数据到表{$this->tableName},".$ex->getMessage());
			}
		}catch (Exception $ex){
			$this->etlLog($logFile,"无法载入数据到表{$this->tableName},".$ex->getMessage());
			return false;
		}
		return true;
	}
}
//================================================
$objPayRequest = new PayRequest($argv[2]);
$objPayRequest->extractAndTransform();
$objPayRequest->loadIntoDb();
