<?php
/**
 * @author linruirong@4399.com
 * @Created  Thu Dec 08 08:52:11 GMT 2011
 * @desc 用于处理目标完成日志
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');
include_once('../log_config.php');
include_once('../log_template.php');

class Upgrade extends LogTemplate {
	public function __construct($gameLog)
	{
		parent::__construct('t_log_upgrade',&$gameLog);
	}
	
	/**
	 * 转换数据
	 *
	 * @param array $data
	 * @return array
	 */
	public function fomateData(&$data){
		foreach ($this->fields as &$fieldsName) {
			$lineData[$fieldsName] = &$data[$fieldsName]; //抽取共有的字段
		}
		
		$lineData['mDateTime'] = strtotime(date('Y-m-d', $lineData['mTime']));
		$lineData['mYear'] = date('Y', $lineData['mTime']);
		$lineData['mMonth'] = date('m', $lineData['mTime']);
		$lineData['mDate'] = date('d', $lineData['mTime']);
		$lineData['mHour'] = date('H', $lineData['mTime']);
		$lineData['mWeek'] = date('w', $lineData['mTime']);
		
		return array( //按实体表的字段顺序整理,以确保load进数据表里后，数据对应正确
			&$lineData['roleId'],
			&$lineData['roleName'],
			&$lineData['accountName'],
			&$lineData['currentLevel'],
			&$lineData['mTime'],
			&$lineData['mDateTime'],
			&$lineData['mYear'],
			&$lineData['mMonth'],
			&$lineData['mDate'],
			&$lineData['mHour'],
			&$lineData['mWeek'],
		);
	}
}
//================================================
$objUpgrade = new Upgrade($argv[2]);
$objUpgrade->extractAndTransform();
$objUpgrade->loadIntoDb();
