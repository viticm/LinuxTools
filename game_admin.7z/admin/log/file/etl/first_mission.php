<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Dec 06 03:42:26 GMT 2011
 * @desc 用于处理首场景加载日志
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');
include_once('../log_config.php');
include_once('../log_template.php');

class FirstMission extends LogTemplate {
	public function __construct($gameLog)
	{
		parent::__construct('t_log_first_mission',&$gameLog);
	}
	
	/**
	 * 转换数据
	 *
	 * @param array $data
	 * @return array
	 */
	public function fomateData(&$data){
		foreach ($this->fields as &$fieldsName) {
			$lineData[$fieldsName] = &$data[$fieldsName]; //抽取共有的字段
		}
		$lineData['mDateTime'] = strtotime(date('Y-m-d', $lineData['mTime']));
		$lineData['mYear'] = date('Y', $lineData['mTime']);
		$lineData['mMonth'] = date('m', $lineData['mTime']);
		$lineData['mDate'] = date('d', $lineData['mTime']);
		$lineData['mHour'] = date('H', $lineData['mTime']);
		$lineData['mWeek'] = date('w', $lineData['mTime']);
		
		return array( //按实体表的字段顺序整理,以确保load进数据表里后，数据对应正确
			&$lineData['roleId'],
			&$lineData['roleName'],
			&$lineData['accountName'],
			&$lineData['missionId'],
			&$lineData['mTime'],
			&$lineData['mDateTime'],
			&$lineData['mYear'],
			&$lineData['mMonth'],
			&$lineData['mDate'],
			&$lineData['mHour'],
			&$lineData['mWeek'],
		);
	}
}
//================================================
$objFirstMission = new FirstMission($argv[2]);
$objFirstMission->extractAndTransform();
$objFirstMission->loadIntoDb();
