<?php
/**
 * @author linruirong@4399.com
 * @Created  Wed Dec 28 07:50:03 GMT 2011
 * @desc 处理元宝每日存留与消耗量统计
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');

$mDateTime = strtotime(date('Y-m-d',strtotime('-1day'))); //因为此脚本是放在凌晨跑的，所以时间应该往前推一天。
//系统存留
$sqlSave = " select sum(gold) as saveGold, sum(bind_gold) as saveBindGold from PLAYER_TBL ";
$rsSave = GFetchRowOne($sqlSave);

$sqlGet = " select sum(gold) as getGold, sum(bindGold) as getBindGold from t_log_gold where mType>= 10000 and mType<= 19999 and mDateTime={$mDateTime} ";
$rsGet = fetchRowOne($sqlGet);

$sqlConsume = " select sum(gold) as consumeGold, sum(bindGold) as consumeBindGold from t_log_gold where mType>= 20000 and mType<= 29999  and mDateTime={$mDateTime} ";
$rsConsume = fetchRowOne($sqlConsume);

$sqlCirculateConsume = " select sum(gold) as circulateConsumeGold from t_log_gold where mType>= 30000 and mType<= 39999 and mDateTime={$mDateTime} ";
$rsCirculateConsume = fetchRowOne($sqlCirculateConsume);

$sqlCirculateGet = " select sum(gold) as circulateGetGold from t_log_gold where mType>= 40000 and mType<= 49999  and mDateTime={$mDateTime} ";
$rsCirculateGet = fetchRowOne($sqlCirculateGet);

$saveGold = intval($rsSave['saveGold']);
$saveBindGold = intval($rsSave['saveBindGold']);
$getGold = intval($rsGet['getGold']);
$getBindGold = intval($rsGet['getBindGold']);
$consumeGold = intval($rsConsume['consumeGold']);
$consumeBindGold = intval($rsConsume['consumeBindGold']);
$circulateGetGold = intval($rsCirculateGet['circulateGetGold']);
$circulateConsumeGold = intval($rsCirculateConsume['circulateConsumeGold']);

$sqlInsert = " insert into t_stat_gold 
                    (mDateTime, saveGold, saveBindGold, consumeGold, consumeBindGold, getGold, getBindGold, circulateConsumeGold,  circulateGetGold )
               values ({$mDateTime},{$saveGold},{$saveBindGold}, {$consumeGold},{$consumeBindGold},{$getGold},{$getBindGold},{$circulateConsumeGold},{$circulateGetGold} )";
dbQuery($sqlInsert);

