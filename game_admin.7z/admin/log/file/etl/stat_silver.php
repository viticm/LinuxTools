<?php
/**
 * @author linruirong@4399.com
 * @Created  Wed Dec 28 07:50:03 GMT 2011
 * @desc 处理铜钱每日存留与消耗量统计
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');

$mDateTime = strtotime(date('Y-m-d',strtotime('-1day'))); //因为此脚本是放在凌晨跑的，所以时间应该往前推一天。
//系统存留
$sqlSave = " select sum(silver) as saveSilver, sum(bind_silver) as saveBindSilver from PLAYER_TBL ";
$rsSave = GFetchRowOne($sqlSave);

$sqlGet = " select sum(silver) as getSilver, sum(bindSilver) as getBindSilver from t_log_silver where mType>= 50000 and mType<= 59999 and mDateTime={$mDateTime} ";
$rsGet = fetchRowOne($sqlGet);

$sqlConsume = " select sum(silver) as consumeSilver, sum(bindSilver) as consumeBindSilver from t_log_silver where mType>= 60000 and mType<= 69999  and mDateTime={$mDateTime} ";
$rsConsume = fetchRowOne($sqlConsume);

$sqlCirculateConsume = " select sum(silver) as circulateConsumeSilver from t_log_silver where mType>= 70000 and mType<= 79999 and mDateTime={$mDateTime} ";
$rsCirculateConsume = fetchRowOne($sqlCirculateConsume);

$sqlCirculateGet = " select sum(silver) as circulateGetSilver from t_log_silver where mType>= 80000 and mType<= 89999  and mDateTime={$mDateTime} ";
$rsCirculateGet = fetchRowOne($sqlCirculateGet);

$saveSilver = intval($rsSave['saveSilver']);
$saveBindSilver = intval($rsSave['saveBindSilver']);
$getSilver = intval($rsGet['getSilver']);
$getBindSilver = intval($rsGet['getBindSilver']);
$consumeSilver = intval($rsConsume['consumeSilver']);
$consumeBindSilver = intval($rsConsume['consumeBindSilver']);
$circulateGetSilver = intval($rsCirculateGet['circulateGetSilver']);
$circulateConsumeSilver = intval($rsCirculateConsume['circulateConsumeSilver']);

$sqlInsert = " insert into t_stat_silver 
                    (mDateTime, saveSilver, saveBindSilver, consumeSilver, consumeBindSilver, getSilver, getBindSilver, circulateConsumeSilver,  circulateGetSilver )
               values ({$mDateTime},{$saveSilver},{$saveBindSilver}, {$consumeSilver},{$consumeBindSilver},{$getSilver},{$getBindSilver},{$circulateConsumeSilver},{$circulateGetSilver} )";
dbQuery($sqlInsert);

