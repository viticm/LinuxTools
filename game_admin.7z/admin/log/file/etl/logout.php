<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Nov 04 16:49:43 GMT 2011
 * @desc 用于处理玩家下线日志
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');
include_once('../log_config.php');
include_once('../log_template.php');

class Logout extends LogTemplate {
	public function __construct($gameLog)
	{
		parent::__construct('t_log_logout',&$gameLog);
	}
	
	/**
	 * 转换数据
	 *
	 * @param array $data
	 * @return array
	 */
	public function fomateData(&$data){
		foreach ($this->fields as &$fieldsName) {
			$lineData[$fieldsName] = &$data[$fieldsName]; //抽取共有的字段
		}
		$lineData['onlineTime']   = $lineData['logoutTime'] - $lineData['loginTime'] ;
		$lineData['loginDate']   = strtotime( date('Y-m-d', $lineData['loginTime']));
		$lineData['logoutDate']  = strtotime( date('Y-m-d', $lineData['logoutTime']));
		
		return array( //按实体表的字段顺序整理,以确保load进数据表里后，数据对应正确
			 &$lineData['roleId']      ,
			 &$lineData['roleName']    ,
			 &$lineData['accountName'] ,
			 &$lineData['loginTime']   ,
			 &$lineData['logoutTime']  ,
			 &$lineData['onlineTime']  ,
			 &$lineData['roleLevel']   ,
			 &$lineData['lastLoginIp'] ,
			 &$lineData['logoutReason'],
			 &$lineData['loginDate']  ,
			 &$lineData['logoutDate'] ,
			 &$lineData['logoutMapId'] ,
			 &$lineData['logoutX']     ,
			 &$lineData['logoutY']     ,
		);
	}
}
//================================================
$objLogout = new Logout($argv[2]);
$objLogout->extractAndTransform();
$objLogout->loadIntoDb();
