<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Dec 19 03:34:00 GMT 2011
 * @desc 处理 道具日志
 */
include_once('../../../protected/config/config.php');
include_once('../log_global.php');
include_once('../log_config.php');
include_once('../log_template.php');
include_once SYSDIR_ADMIN_CLASS.'/player.php';

class Act extends LogTemplate {
        public function __construct($gameLog)
        {
                parent::__construct('t_log_act',&$gameLog);
        }

        /**
         * 转换数据
         *
         * @param array $data
         * @return array
         */
        public function fomateData(&$data){
                foreach ($this->fields as &$fieldsName) {
                        $lineData[$fieldsName] = &$data[$fieldsName]; //抽取共有的字段
                }

		        $role = Player::getUser($lineData['roleName'], $lineData['accountName'], $lineData['roleId']);
		        $lineData['roleId'] = $role['roleId'];
		        $lineData['roleName'] = $role['roleName'];
		        $lineData['accountName'] = $role['accountName'];

                $lineData['mDateTime'] = strtotime(date('Y-m-d', $lineData['mTime']));
                $lineData['mYear'] = date('Y', $lineData['mTime']);
                $lineData['mMonth'] = date('m', $lineData['mTime']);
                $lineData['mDate'] = date('d', $lineData['mTime']);
                $lineData['mHour'] = date('H', $lineData['mTime']);
                $lineData['mWeek'] = date('w', $lineData['mTime']);

                return array( //按实体表的字段顺序整理,以确保load进数据表里后，数据对应正确
                        &$lineData['roleId'], 
                        &$lineData['roleName'],
                        &$lineData['accountName'],
                        &$lineData['mType'],
                        &$lineData['mTime'],
                        &$lineData['mDateTime'],
                        &$lineData['mYear'],
                        &$lineData['mMonth'],
                        &$lineData['mDate'],
                        &$lineData['mHour'],
                        &$lineData['mWeek'],
                );
        }
}

//================================================
$objAct = new Act($argv[2]);
$objAct->extractAndTransform();
$objAct->loadIntoDb();