#!/bin/bash

#############################################
## 此脚本于crontab中每分钟运行一次.
## 注意 以本配置中 除了 logBaseDir 其他最好不要乱改
#############################################
export LANG="en_US.UTF-8"
curDir=`dirname ${0}`
cd ${curDir}

 logBaseDir='/data/logs/yjxy/'
logSyncDir='wait/'
serverConf='../server.conf'
logConf='../log.conf'
phpPath='/usr/local/php/bin/php'

if [ ! -f ${serverConf} ] ; then
	echo "server config file not exists"
	exit 1
fi

if [ ! -f ${logConf} ] ; then
	echo "log config file not exists"
	exit 1
fi
serverItems=`cat ${serverConf}| grep -v "#"`
logConfItems=`cat ${logConf} | grep -v "#"`

for server in ${serverItems} 
do
	logDir="${logBaseDir}${server}/${logSyncDir}"
	loglist=`ls -t ${logDir}`
	for item in ${logConfItems} 
	do
		regName=`echo ${item}| cut -d',' -f1`
		program=`echo ${item}| cut -d',' -f2`
		#echo ${regName}
		#echo ${program}
		#echo ${loglist}
		for file in ${loglist}
		do
			if [[ "${file}" =~ ${regName} ]] ; then
				#echo ${file}
				#echo "${phpPath} ${program} ${server} ${logDir}${file}"
				${phpPath} ${program} ${server} "${logDir}${file}" >> "${logBaseDir}${server}/crontab.log" 2>&1 &
				break;
			fi
		done
	done
done
