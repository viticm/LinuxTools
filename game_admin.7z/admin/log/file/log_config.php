<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Nov 07 02:08:29 GMT 2011
 * @desc 注意此配置文件里面，各表字段并不是对应的数据表的真实结构，
 *       只是用来约定要在服务端所给的日志中抽取哪些字段。
 */
$arrLogTplConf = array(
	't_log_login'=>array(//玩家上线日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'roleLevel', 'loginIp', 'mTime', ),
	),
	't_log_logout'=>array(//玩家下线日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'loginTime', 'logoutTime', 'roleLevel', 'lastLoginIp', 'logoutReason', 'logoutMapId', 'logoutX', 'logoutY', ),
	),
	't_log_online'=>array(//在线人数日志
		'fields'=>array('online', 'mTime'),
	),
	't_log_access'=>array(//玩家访问日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'roleLevel', 'ip', 'mTime', 'mDateTime', 'mYear', 'mMonth', 'mDate', 'mHour', 'mWeek' ),
	),
	't_log_create_page'=>array(//创角页访问日志
		'fields'=>array('accountName', 'ip', 'mTime'),
	),
	't_log_register'=>array(//角色创建日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'roleSex', 'roleJob', 'ip', 'mTime'),
	),
	't_log_first_view'=>array(//进入首场景日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'ip', 'useTime', 'mTime'),
	),
	't_log_first_mission'=>array(//完成首个任务日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'missionId', 'mTime'),
	),
	't_log_mission'=>array(//任务日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'groupId', 'groupName', 'missionId', 'missionName', 'missionType', 'status', 'minLevel', 'maxLevel', 'loopTime', 'roleLevel', 'mTime', ),
	),
	't_player_complaint'=>array(//玩家投诉日志
		'fields'=>array('sn', 'accountName', 'roleId', 'roleName', 'level', 'mTime', 'mType', 'title', 'content' ),
	),
	't_log_target'=>array(//目标完成日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'roleLevel', 'targetId', 'mTime', 'status'),
	),
	't_log_upgrade'=>array(//角色升级日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'currentLevel', 'mTime'),
	),
	't_log_pay'=>array(//玩家充值日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'orderId', 'payMoney', 'payGold', 'mTime'),
	),
	't_log_pay_request'=>array(//玩家充值请求日志
		'fields'=>array('logId', 'payToUser', 'userIp', 'detail', 'desc', 'mTime', 'action'),
	),
	't_log_gold'=>array(//元宝日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'roleLevel', 'gold', 'bindGold', 'mType', 'itemId', 'color', 'quality', 'amount', 'mTime'),
	),
	't_log_silver'=>array(//铜钱日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'roleLevel', 'silver', 'bindSilver', 'mType', 'itemId', 'color', 'quality', 'amount', 'mTime'),
	),
	't_log_item'=>array(//道具日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'roleLevel', 'mType', 'itemId', 'color', 'quality', 'amount', 'mTime'),
	),
	't_log_client_load'=>array(//客户端资源加载进度日志
		'fields'=>array('logId', 'roleId', 'roleName', 'accountName', 'roleLevel', 'ip', 'step', 'mTime', 'mDateTime', 'mYear', 'mMonth', 'mDate', 'mHour', 'mWeek' ),
	),
	't_log_auction'=>array(//拍卖日志
		'fields'=>array( 'roleId', 'roleName', 'accountName', 'auctionId', 'mType', 'itemId', 'itemNum', 'price', 'mTime', 'mDateTime', 'mYear', 'mMonth', 'mDate', 'mHour', 'mWeek' ),
	),
	't_log_battle'=>array(//战斗日志
		'fields'=>array( 'roleId', 'roleName', 'accountName', 'defId', 'defName', 'defAccount', 'warType', 'processNum', 'winFlag', 'mTime', 'mDateTime', 'mYear', 'mMonth', 'mDate', 'mHour', 'mWeek' ),
	),
	't_log_repu'=>array(//声望日志
		'fields'=>array( 'roleId', 'roleName', 'accountName', 'roleLevel', 'amount', 'mType', 'mTime', 'mDateTime', 'mYear', 'mMonth', 'mDate', 'mHour', 'mWeek' ),
	),
	't_log_exp'=>array(//经验日志
		'fields'=>array( 'roleId', 'roleName', 'accountName', 'exp', 'mType', 'mTime', 'mDateTime', 'mYear', 'mMonth', 'mDate', 'mHour', 'mWeek' ),
	),
	't_log_act'=>array(//活动日志
		'fields'=>array( 'roleId', 'roleName', 'accountName', 'mType', 'mTime', 'mDateTime', 'mYear', 'mMonth', 'mDate', 'mHour', 'mWeek' ),
	),
	't_log_power'=>array(//精力日志
		'fields'=>array( 'roleId', 'roleName', 'accountName', 'power', 'mType', 'mTime', 'mDateTime', 'mYear', 'mMonth', 'mDate', 'mHour', 'mWeek' ),
	),
	't_log_stage'=>array(//精力日志
		'fields'=>array( 'roleId', 'roleName', 'accountName', 'stageId', 'mTime', 'mDateTime', 'mYear', 'mMonth', 'mDate', 'mHour', 'mWeek' ),
	),
	't_log_mall'=>array(//商城日志
		'fields'=>array( 'roleId', 'roleName', 'accountName', 'category', 'itemId', 'itemNum', 'cost', 'mTime', 'mYear', 'mMonth', 'mDate', 'mHour', 'mWeek' ),
	),
	/** Modify Start By viticm 2012-12-24 **/
	/** add  spirit crystal experience **/
	't_log_spirit'=>array(//战魂日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'roleLevel', 'spirit', 'bindSpirit', 'mType', 'itemId', 'color', 'quality', 'amount', 'mTime'),
	),
	't_log_crystal'=>array(//玄晶日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'roleLevel', 'crystal', 'bindCrystal', 'mType', 'itemId', 'color', 'quality', 'amount', 'mTime'),
	),
	't_log_experience'=>array(//阅历日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'roleLevel', 'experience', 'bindExperience', 'mType', 'itemId', 'color', 'quality', 'amount', 'mTime'),
	),
	't_log_chat'=>array(//聊天日志
		'fields'=>array('roleId', 'roleName', 'accountName', 'roleLevel', 'content', 'dstRoleId', 'dstRoleName', 'dstAccountName', 'dstRoleLevel', 'mTime'),
	),
	't_log_tally'=>array(//玉符日志
			'fields'=>array('roleId', 'roleName', 'accountName', 'roleLevel', 'tally', 'bindTally', 'mType', 'itemId', 'color', 'quality', 'amount', 'mTime'),
	),
	/** Modify End By viticm 2012-12-24 **/
);
