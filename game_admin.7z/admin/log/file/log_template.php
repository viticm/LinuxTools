<?php
/**
 * @author linruirong@4399.com
 * @copyright www.4399.com
 */

class LogTemplate{
	
	public $tableName;  //对应的表名
	public $gameLog; //日志文件全路径
	public $etlCsvPath;  //临时的csv文件存放路径
	public $fields; //要从日志文件中抽取的字段
	public $ok = true; //处理结果状态

	/**
	 * 
	 * @param string $tableName 对应日志表名
	 */
	public function __construct($tableName, $gameLog)
	{
		global  $arrLogTplConf;
		$this->tableName = $tableName;
		$this->gameLog = $gameLog;
		$this->etlCsvPath = SYSDIR_GAME_ETL_CSV.DIRECTORY_SEPARATOR.$tableName.'.csv';
		$this->fields = $arrLogTplConf[$tableName]['fields'];
	}

	/**
	 * 抽取并转换日志
	 *
	 */
	public function extractAndTransform ()
	{
		$logFile = &$this->gameLog;
		if (!file_exists($logFile)) {//如果文件不存在,直接退出
			return false;
		}
		if (file_exists($this->etlCsvPath)) {
			$fpcsv = fopen($this->etlCsvPath,'w');
			if (FALSE===$fpcsv || FALSE === fwrite($fpcsv,'')) {
				$this->ok = false;
				$this->etlLog($logFile,"无法清除临时文件 {$this->etlCsvPath} 的内容");
				return false;
			}
			fclose($fpcsv);
			$fpcsv = fopen($this->etlCsvPath,'a+');
		}else {
			$fpcsv = fopen($this->etlCsvPath,'a+');
			chmod($this->etlCsvPath,0777);
		}
		
		$fplog = fopen($logFile,'r');
		$headerFields = fgetcsv($fplog); //读取第一行,表头定义
		if (1==count($headerFields) && null === $headerFields[0]){
			$this->ok = false;
			$this->mvLog($logFile, SYSDIR_GAME_LOG_ERROR);
			$this->etlLog($logFile,"未定义表头");
			return false;
		}
		//去掉表头字段中的空格
		foreach ($headerFields as $key => &$fieldName) {
			$headerFields[$key] = trim($fieldName);
		}
		$line = 2; //从第二行开始算
		while ($data = fgetcsv($fplog)) {
			if (1==count($data) && null === $data[0]) {
				$line++;
				continue;//忽略空行
			}else {
				if (count($headerFields) != count($data) ) {
					$this->ok = false;
					$this->mvLog($logFile, SYSDIR_GAME_LOG_ERROR);
					$this->etlLog($logFile,"第{$line}行 数据列数与表头列数不相等".count($headerFields).":".count($data));
					return false;
				}
				//转换数据
				$lineData = $this->fomateData(array_combine($headerFields, $data));
				if(FALSE === fputcsv($fpcsv,$lineData)){
					$this->ok = false;
					$this->mvLog($logFile, SYSDIR_GAME_LOG_ERROR);
					$this->etlLog($logFile,"第{$line}行的数据无法写入到临时文件 {$this->etlCsvPath}中");
					return false;
				}
			}
			$line++;
		}
		fclose($fplog);
		fclose($fpcsv);
	}

	/**
	 * 转换数据
	 *
	 */
	public function fomateData(&$data){
		foreach ($this->fields as &$fieldsName) {
			$lineData[$fieldsName] = &$data[$fieldsName];
		}
		return $lineData;
	}

	public function loadIntoDb()
	{
		$logFile = &$this->gameLog;
		if ( !$this->ok || !$logFile || !file_exists($this->etlCsvPath) || 0==filesize($this->etlCsvPath)) {//如果没有需要处理的文件,直接退出
			return false;
		}
		$sql = " LOAD DATA INFILE '{$this->etlCsvPath}' INTO TABLE `{$this->tableName}`  FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' ";
		try {
			$result = dbQuery($sql);
			$this->mvLog($logFile, SYSDIR_GAME_LOG_OK);
			//记录本次操作时间到t_load表中
			$this->updateLoadTbl();
		}catch (Exception $ex){
			$this->mvLog($logFile, SYSDIR_GAME_LOG_ERROR);
			$this->etlLog($logFile,"无法载入数据到表{$this->tableName},".$ex->getMessage());
			return false;
		}
		return true;
	}
	
	function updateLoadTbl()
	{
		$sql = "update t_load set lastLoadTime=".time()." limit 1";
		dbQuery( $sql );
	}
	
	function mvLog($logFile, $destDir)
	{
		$baseFileName = basename($logFile);
		$destFileName = $destDir.DIRECTORY_SEPARATOR.$baseFileName;
		if ($logFile != $destFileName) { //若路径一样就无须再移动了.
			$mv = rename($logFile,$destFileName); //先移动到历史日志目录
			if (!$mv) {
				_error("{$logFile} :: 移入目录 {$destDir} 失败!");
				echo "【ERROR】{$logFile} :: 移入目录 {$destDir} 失败! \n";
				return false;
			}
		}
	}
	
	function etlLog($logFile,$errMsg,$seccess=0)
	{
		if (!$seccess) {
			_error("{$logFile} :: 入库出错:".$errMsg);
			echo "【ERROR】{$logFile} :: 入库出错:{$errMsg}\n";
		}
		$baseFileName = basename($logFile);
	}
}