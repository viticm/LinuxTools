<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Nov 04 16:53:29 GMT 2011
 * @desc 此全局引用，只能用于处理日志，即使通过web访问得到，也会直接被die掉。
 */

if( substr(php_sapi_name(),0,3) !== 'cli'){
	die("This Programe can only be run in CLI mode\n");
}
/*
@exec('cat "server.conf"| grep -v "#"',$servers);
if (!is_array($servers) || empty($servers)) {
	die("server.conf not exists or empty\n");
}
if (!in_array($argv[1], $servers)) {
	die("server {$argv[1]} not exists \n");
}*/
if (!file_exists(SYSDIR_ADMIN_CONFIG_SERVERS.DIRECTORY_SEPARATOR.$argv[1].'.php')) {
	die(SYSDIR_ADMIN_CONFIG_SERVERS.DIRECTORY_SEPARATOR.$argv[1].'.php'. " not exists \n");
}
include_once(SYSDIR_ADMIN_CONFIG_SERVERS.DIRECTORY_SEPARATOR.$argv[1].'.php');
date_default_timezone_set(TIME_ZONE);//时间设置
include_once SYSDIR_ADMIN_INCLUDE."/db_defines.php";
include_once SYSDIR_ADMIN_CLASS."/mysql.php";
include_once SYSDIR_ADMIN_INCLUDE."/functions.php";
include_once SYSDIR_ADMIN_INCLUDE."/db_functions.php";

global $db, $dbGame;

//初始化管理后台数据库连接
if(!$db) {
	$config['host'] = DB_HOST;
	$config['user'] = DB_USER;
	$config['passwd'] = DB_PASSWD;
	$config['dbname'] = DB_NAME;
	$db =  new Mysql();
	$db->connect($config);
}
if (!$db) {
	die('无法连接数据库');
}

if(!$dbGame ) {//初始化游戏数据库连接
	$config['host'] = DB_GAME_HOST;
	$config['user'] = DB_GAME_USER;
	$config['passwd'] = DB_GAME_PASSWD;
	$config['dbname'] = DB_GAME_DB_NAME;
	$dbGame =  new Mysql();
	$dbGame->connect($config);
	if (!$dbGame) {
		die('无法连接数据库');
	}
}