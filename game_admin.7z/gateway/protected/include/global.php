<?php
/**
 * @author linruirong@4399.com
 * @copyright www.4399.com
 * @desc 引用此文件，则不验证用户是否登录。用于那些不需要登录可使用的功能
 */
header('Content-Type: text/html; charset=UTF-8');
//时间设置
date_default_timezone_set(TIME_ZONE);
include_once SYSDIR_ADMIN_CLASS."/mysql.php";
include_once SYSDIR_ADMIN_INCLUDE."/functions.php";
include_once SYSDIR_ADMIN_INCLUDE."/db_functions.php";
include_once SYSDIR_ADMIN_LIBRARY."/smarty/Smarty.class.php";

global $smarty, $db, $auth;

//初始化smarty
$smarty = new Smarty();
$smarty->compile_check = SMARTY_COMPILE_CHECK;
$smarty->force_compile = SMARTY_FORCE_COMPILE;
$smarty->template_dir = SYSDIR_ADMIN_SMARTY_TEMPLATE;
$smarty->compile_dir = SYSDIR_ADMIN_SMARTY_TEMPLATE_C;
$smarty->left_delimiter = SMARTY_LEFT_DELIMITER;
$smarty->right_delimiter = SMARTY_RIGHT_DELIMITER;

//初始化管理后台数据库连接
if(!$db) {
	$db =  new Mysql();
	$db->connect($dbConfig);
	if (!$db) {
		die('无法连接数据库');
	}
}
if (!$auth) {
	require_once(SYSDIR_ADMIN_CLASS.'/user_auth.php');
	$auth = new UserAuth();
}
if ( UserAuth::AUTH_RESULT_OK === $auth->auth() ) {
	//如果验证通过，则不做处理，放行...
}elseif ( UserAuth::AUTH_RESULT_NOT_LOGIN === $auth->auth() ){
	$url = getRelativePath(realpath($_SERVER['SCRIPT_FILENAME']),SYSDIR_ADMIN_PUBLIC.'/login.php');
	die('<script language="javascript">window.top.location.href="'.$url.'";</script>');
}elseif ( UserAuth::AUTH_RESULT_NO_PERMITION === $auth->auth() ) {
	die('没权限');
}else {
	die('没权限');
}