<?php
/**
 *ip字符串转为数字类型
 *
 * @param string $ipStr 如：192.168.0.1
 *
 */
 function myip2long($ipStr){
 	$ipStr = empty($ipStr)?0:$ipStr;
	$ipNum = ip2long($ipStr);
	$ipNum = sprintf("%u",$ipNum);
	return $ipNum;
 }

/**
 * @desc 退出并打印json by viticm
 * @param unknown_type $resultCode
 * @param unknown_type $errorMsg
 */
function dieJsonMsg($resultCode, $errorMsg)
{
	$result = array(
		'ErrorCode' => $resultCode,
		'ErrorDesc' => urlencode( $errorMsg ),
	);
	echo json_encode($result);
	die();
}

/**
 * 渲染smarty模版
 *
 * @param string $templatePath
 * @param array $data
 */
function render($templatePath, $data=array())
{
	global $smarty;
	global $navPosition;
	$data['navPosition'] = $navPosition;
	$smarty->assign($data);
	$smarty->display($templatePath);
	exit();
}

function validChinese($str) {
	$str = trim($str);
	if (preg_match("/^[\x{4e00}-\x{9fa5}]+$/u", $str) == 0) {
		return false;
	}
	return true;
}

/**
 * SQL的参数值的安全过滤
 * 所有SQL语句的参数，都必须用这个函数处理一下。目的：防SQL注入攻击!!
 * @param $name
 */
function SS($name) {
	return mysql_real_escape_string(trim($name));
}

function getIP(){
	if(!empty($_SERVER["HTTP_CLIENT_IP"])) $cip = $_SERVER["HTTP_CLIENT_IP"];
	else if(!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) $cip = $_SERVER["HTTP_X_FORWARDED_FOR"];
	else if(!empty($_SERVER["REMOTE_ADDR"])) $cip = $_SERVER["REMOTE_ADDR"];
	else $cip = "";
	return $cip;
}

/**
 * curl方式 post数据
 *
 * @param mix $data
 * @param string $url 全路径,如: http://127.0.0.1:8000/test
 */
function curlPost($url,$params)
{
	if (!trim($params)) {
		return false;
	}
	$ch=curl_init();
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch,CURLOPT_POST,1);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$params);
	$result = curl_exec($ch);
	curl_close($ch);
	//	file_put_contents('/tmp/curl.log','params='.$params."\n url=".$url."\n result=".print_r($result,true)."\n",FILE_APPEND);
	return $result;
}

function isPost() {
	return (strtolower($_SERVER['REQUEST_METHOD']) == 'post');
}

function getSession($subKey)
{
	return $_SESSION[SESSION_KEY][$subKey];
}

function setSession($subKey, $val)
{
	return $_SESSION[SESSION_KEY][$subKey] = $val;
}

/**
 * 获取当前文件到目标文件的相对路径
 *
 * @param string $cur 当前文件
 * @param string $absp 目标路径
 * @return string
 */
function getRelativePath($cur,$absp)
{
	$cur = str_replace('\\','/',$cur);
	$absp = str_replace('\\','/',$absp);
	$sabsp=explode('/',$absp);
	$scur=explode('/',$cur);
	$la=count($sabsp)-1;
	$lc=count($scur)-1;
	$l=max($la,$lb);

	for ($i=0;$i<=$l;$i++)
	{
		if ($sabsp[$i]!=$scur[$i])
		break;
	}
	$k=$i-1;
	$path="";
	for ($i=1;$i<=($lc-$k-1);$i++)
	$path.="../";
	for ($i=$k+1;$i<=($la-1);$i++)
	$path.=$sabsp[$i]."/";
	$path.=$sabsp[$la];
	return $path;
}

/**
 * 用于调式
 *
 * @param mix $mix
 * @param bool $dumpAll 是否打印出变量类型
 */
function _debug($mix)
{
	if (LOG_LEVEL <= 1) {
		$header = 'DEBUG';
		_dumpLogMsg($header,$mix);
	}
}

/**
 * 用于记录正常运行日志
 *
 * @param mix $mix
 * @param bool $dumpAll 是否打印出变量类型
 */
function _info($mix)
{
	if (LOG_LEVEL <= 2) {
		$header = 'INFO';
		_dumpLogMsg($header,$mix);
	}
}

/**
 * 用于记录错误日志
 *
 * @param mix $mix
 * @param bool $dumpAll 是否打印出变量类型
 */
function _error($mix)
{
	if (LOG_LEVEL <= 3) {
		$header = 'ERROR';
		_dumpLogMsg($header,$mix);
	}
}

/**
 * 将日志写入到文件中
 *
 * @param minx $mix
 * @param string $logFile
 * @param bool $dumpAll
 */
function _dumpLogMsg($header,$mix)
{
	$log = print_r($mix,true);
	$trace = array_pop( debug_backtrace() );
//	$file = trim($trace['file'],SYSDIR_ADMIN);
	$file = &$trace['file'];
	$time = date('Y-m-d H:i:s');
	$str = "【{$header}】 | {$time} | {$file} | {$trace['line']} :\r\n{$log}\r\n";
	file_put_contents(SYSFILE_LOG_FILE,$str,FILE_APPEND);
}

/**
 * @desc 获得页面请求参数
 * @param string $cParamName
 * @return string
 */
function GetUrlParam( $cParamName )
{
	$cResult = '';
    $cRequestMethod = '';
    $cRequestMethod = $_SERVER[ 'REQUEST_METHOD' ];
    switch ( $cRequestMethod )
    {
    	case 'GET':
    		$cResult = $_GET[ "$cParamName" ];
    		break;
    	case 'POST':
    		$cResult = $_POST[ "$cParamName" ];
    		break;
    	default:
    		$cResult = '';
    }
    return $cResult;
}

/**
 *
 * @desc 根据需要更新的数据数组，以及表名和where条件获得更新sql字符串（同上，都是模仿zendframework）
 * @param string $cTableName 表名
 * @param array $Arr_Update 更新数组
 * @param string $cWhere 条件，如id=1( and name='aaa')
 * @return string
 */
function GetUpdateSqlStr( $cTableName, $Arr_Update, $cWhere )
{
	$cSqlStr = 'UPDATE `'.$cTableName.'` SET';
	$cSetStr = '';
	foreach ( $Arr_Update as $key => $val )
	{
		$cSetStr .= ' '.$key.'='.'"'.GetDoubleQuotesFormatStr( $val ).'",';
	}
	$cSetStr = substr( $cSetStr, 0, -1 );
	$cSqlStr .= $cSetStr;
	$cSqlStr .= ' WHERE '.$cWhere;
	return $cSqlStr;
}

/**
 *
 * @desc 转义字符串中的双引号,例如：{"err":"bbbb"}会转换为{\"err\":\"bbbb\"}一般用于数据库sql
 * @param string $cStr
 * @return string
 */
function GetDoubleQuotesFormatStr( $cStr )
{
	$cStr = stripslashes( $cStr );
	$cStr = str_replace( '"', '\"', $cStr );
	return $cStr;
}