<?php
/**
 * @author linruirong@4399.com
 * @copyright www.4399.com
 * @desc 引用此文件，则不验证用户是否登录。用于那些不需要登录可使用的功能
 */
header('Content-Type: text/html; charset=UTF-8');
//时间设置
date_default_timezone_set(TIME_ZONE);
include_once SYSDIR_ADMIN_CLASS."/mysql.php";
include_once SYSDIR_ADMIN_INCLUDE."/functions.php";
include_once SYSDIR_ADMIN_INCLUDE."/db_functions.php";

global $db;

//初始化管理后台数据库连接
if(!$db) {
	$db =  new Mysql();
	$db->connect($dbConfig);
	if (!$db) {
		die('无法连接数据库');
	}
}