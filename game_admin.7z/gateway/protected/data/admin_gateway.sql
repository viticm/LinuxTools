-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2013 年 05 月 02 日 18:01
-- 服务器版本: 5.1.62-log
-- PHP 版本: 5.3.14

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `admin_gateway`
--

-- --------------------------------------------------------

--
-- 表的结构 `t_admin_group`
--

CREATE TABLE IF NOT EXISTS `t_admin_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupName` varchar(64) NOT NULL COMMENT '组名',
  `rules` text NOT NULL COMMENT '权限ID列表',
  `remarks` varchar(200) NOT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groupName` (`groupName`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- 表的结构 `t_admin_user`
--

CREATE TABLE IF NOT EXISTS `t_admin_user` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `passwd` varchar(50) NOT NULL,
  `deny` text,
  `allow` text,
  `lastLoginTime` int(11) NOT NULL,
  `groupId` int(10) unsigned NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `lastChangePasswd` int(11) NOT NULL,
  `userStatus` int(11) NOT NULL DEFAULT '1',
  `gmAgentId` int(11) NOT NULL COMMENT 'GM后台权限范围',
  `centralAgentId` int(11) NOT NULL COMMENT '中央后台权限范围',
  `gameAdminAgentId` int(11) NOT NULL COMMENT '游戏管理后台权限范围',
  `gameAdminServer` text NOT NULL COMMENT '游戏管理后台权限范围',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- 表的结构 `t_agent`
--

CREATE TABLE IF NOT EXISTS `t_agent` (
  `agentId` int(11) NOT NULL COMMENT '代理商编号',
  `agentName` varchar(32) NOT NULL COMMENT '代理商名',
  `caption` varchar(32) NOT NULL COMMENT '说明',
  PRIMARY KEY (`agentId`),
  UNIQUE KEY `agentName` (`agentName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `t_game_server`
--

CREATE TABLE IF NOT EXISTS `t_game_server` (
  `serverName` varchar(32) NOT NULL COMMENT '服务器编号',
  `serverId` int(11) NOT NULL COMMENT '服务器索引号',
  `agentName` varchar(32) NOT NULL COMMENT '代理名称',
  `agentId` int(11) NOT NULL COMMENT '代理编号',
  `dbHost` varchar(64) NOT NULL COMMENT '游戏管理后台数据库所在机地址',
  `dbUser` varchar(32) NOT NULL COMMENT '管理后台数据库用户名',
  `dbPasswd` varchar(32) NOT NULL COMMENT '管理后台数据库用户密码',
  `dbName` varchar(32) NOT NULL COMMENT '管理后台数据库',
  `gatewaySystemUrl` varchar(128) NOT NULL COMMENT '登录授权系统地址',
  `gameAdminUrl` varchar(128) NOT NULL COMMENT '游戏管理后台URL',
  `game3wUrl` varchar(128) NOT NULL COMMENT '游戏入口地址',
  `game3wAuthKey` varchar(32) NOT NULL COMMENT '游戏管理后台与游戏前端入口校验的key',
  `platformLoginKey` varchar(128) NOT NULL COMMENT '平台登录key',
  `serverSocketHost` varchar(64) NOT NULL COMMENT '服务端所在机地址',
  `serverSocketPort` int(11) NOT NULL COMMENT '服务端端口',
  `serverAuthKey` varchar(32) NOT NULL COMMENT '管理后台与服务端校验key',
  `serverApiUrl` varchar(128) NOT NULL COMMENT '服务端接口地址',
  `sysDirGameEtlCsv` varchar(128) NOT NULL COMMENT '格式化后的csv文件存放路径',
  `sysDirGameLog` varchar(128) NOT NULL COMMENT '日志总目录',
  `sysDirGameLogWait` varchar(128) NOT NULL COMMENT '等待处理的日志存放路径',
  `sysDirGameLogError` varchar(128) NOT NULL COMMENT '错误日志存放路径',
  `sysDirGameLogOk` varchar(128) NOT NULL COMMENT '已经入库日志存放路径',
  `gmSystemAuthKey` varchar(32) NOT NULL COMMENT '游戏管理后台与GM后台验证的key',
  `gmSyncComplaintUrl` varchar(128) NOT NULL COMMENT 'GM后台接收投诉的api地址',
  `gameAdminAuthKey` varchar(32) NOT NULL COMMENT '游戏管理后台与中央后台验证key',
  `serverOnlineDate` date NOT NULL COMMENT '开服日期',
  `dbGameHost` varchar(32) NOT NULL COMMENT '游戏库所在机地址',
  `dbGameUser` varchar(32) NOT NULL COMMENT '游戏库用户名',
  `dbGamePasswd` varchar(32) NOT NULL COMMENT '游戏库密码',
  `dbGameDbName` varchar(32) NOT NULL COMMENT '游戏库名',
  PRIMARY KEY (`serverName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `t_log_admin`
--

CREATE TABLE IF NOT EXISTS `t_log_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `username` varchar(64) NOT NULL DEFAULT '' COMMENT '管理员帐号名',
  `ip` varchar(32) NOT NULL DEFAULT '' COMMENT '管理员IP',
  `playerAccount` varchar(64) NOT NULL COMMENT '受影响的玩家帐号',
  `mTime` int(11) NOT NULL DEFAULT '0' COMMENT '操作时间',
  `mType` int(11) NOT NULL DEFAULT '0' COMMENT '操作类型',
  `detail` text NOT NULL COMMENT '操作内容',
  `num` int(11) NOT NULL COMMENT '涉及数量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='管理后台的日志表' AUTO_INCREMENT=267 ;

-- --------------------------------------------------------

--
-- 表的结构 `t_log_mergeservers`
--

CREATE TABLE IF NOT EXISTS `t_log_mergeservers` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `agentId` int(11) NOT NULL COMMENT '代理商id',
  `serverId` int(11) NOT NULL COMMENT '服务器索引号',
  `mergeTo` int(11) NOT NULL DEFAULT '0' COMMENT '合区到的目标服务器，比如合区到2区，此处为2，默认0',
  `mergeTime` int(10) NOT NULL COMMENT '合区时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- 表的结构 `t_menu`
--

CREATE TABLE IF NOT EXISTS `t_menu` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `class` varchar(32) NOT NULL COMMENT '父级菜单分类',
  `name` varchar(32) NOT NULL COMMENT '菜单名',
  `url` varchar(128) NOT NULL COMMENT '相对地址',
  `belongTo` tinyint(4) NOT NULL COMMENT '所属系统',
  `visible` tinyint(4) NOT NULL COMMENT '显示方式：1=显示，2=隐藏',
  `orderNum` int(11) NOT NULL COMMENT '排序号',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=79 ;

-- --------------------------------------------------------

--
-- 表的结构 `t_menu_counter`
--

CREATE TABLE IF NOT EXISTS `t_menu_counter` (
  `uid` int(11) NOT NULL COMMENT '用户ID',
  `menuId` int(11) NOT NULL COMMENT '菜单ID',
  `counter` int(11) NOT NULL COMMENT '历史点击次数',
  `lastClickTime` int(11) NOT NULL COMMENT '最后一次点击的时间',
  PRIMARY KEY (`uid`,`menuId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户菜单点击计数';

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
