<?php
/*
 * @desc game admin website
 * $id mergeservers_log.php
 * @author viticm<duchuanpd@gmal.com>
 * @date 2013-8-19 10:46:41
 */

class ServerSummary
{
	private $szTableName ;
	/**
	 * @desc construct function for this class
	 * @param void
	 * @return void
	 */
	public function __construct()
	{
		$this->szTableName = 't_servers_summary';
	}

	/**
	 * get all servers summary
	 * @param int $iDateTime
	 * @param int $iAgentId
	 * @param int $iServerId
	 * @return array
	 */
	public function getServersSummary( $iDateTime, $iAgentId = '', $iServerId = '' )
	{
		$szSqlStr = '' ;
		$szWhere = ' WHERE 1 = 1' ;
		$szSqlStr .= 'SELECT * FROM `'.$this->szTableName.'`' ;
		$szWhere .= ' AND `mDateTime` = ' .$iDateTime ;
		if ( '' != $iAgentId ) $szWhere .= ' AND `agentId` = '.$iAgentId ;
		if ( '' != $iServerId ) $szWhere .= ' AND `serverId` = '.$iServerId ;
		$szWhere .= ' ORDER BY `agentId`,`serverId` ASC' ;
		$szSqlStr .= $szWhere ;
		return fetchRowSet( $szSqlStr ) ;
	}

	/**
	 * add server summary to db
	 * @param array $Arr_ServerSummary
	 * @return mixed
	 */
    public function addServerSummary( $Arr_ServerSummary )
    {
    	$szSqlStr    = '';
    	$iAgentId    = $Arr_ServerSummary[ 'agentId' ] ;
    	$iServerId   = $Arr_ServerSummary[ 'serverId' ] ;
    	$iDateTime   = $Arr_ServerSummary[ 'mDateTime' ] ;
        if ( false == $this->isHasSummary( $iAgentId, $iServerId, $iDateTime ) )
        {
    	    $szSqlStr .= makeInsertSql( $this->szTableName, $Arr_ServerSummary );
        }
        else
        {
            $szSqlStr .= 'UPDATE `' .$this->szTableName. '` SET `summaryJson` = "'
                .GetDoubleQuotesFormatStr( $Arr_ServerSummary[ 'summaryJson' ] ). '"' ;
            $szSqlStr .= ' WHERE `agentId` = ' .$iAgentId ;
            $szSqlStr .= ' AND `serverId` = ' .$iServerId ;
            $szSqlStr .= ' AND `mDateTime` = ' .$iDateTime ;
        }
    	return dbQuery( $szSqlStr ) ;
    }

    /**
     * check the server if has summary of time
     * @param int $iAgnetId
     * @param int $iServerId
     * @param int $iDateTime
     */
    public function isHasSummary( $iAgentId, $iServerId, $iDateTime )
    {
    	$bReturn    = false ;
        $szSqlStr   = '' ;
        $szSqlStr   .= 'SELECT `id` FROM `' .$this->szTableName. '`' ;
        $szWhere    = '' ;
        $szWhere    .= ' WHERE `agentId` = ' .$iAgentId ;
        $szWhere    .= ' AND `serverId` = ' .$iServerId ;
        $szWhere    .= ' AND `mDateTime` = ' .$iDateTime ;
        $szSqlStr   .= $szWhere ;
        $Result = fetchRowOne( $szSqlStr ) ;
        if ( $Result ) $bReturn = 0 < count( $Result ) ? true : false ;
        return $bReturn ;
    }

    /**
     * this is destruct function of this class
     * @param void
     * @return void
     */
    public function __destruct()
    {

    }

}