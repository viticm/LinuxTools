<?php
/*
 * @desc game admin website
 * $id mergeservers_log.php
 * @author viticm<duchuanpd@gmal.com>
 * @date 2013-4-24
 */

class MergeServersLog
{
	private $cTableName;
	/**
	 * @desc construct function for this class
	 * @param void
	 * @return void
	 */
	public function __construct()
	{
		$this->cTableName = 't_log_mergeservers';
	}
	
	/**
	 * @desc get all mergeservers log info by agent id
	 * @param int $iAgentId
	 * @param int $iServerId
	 * @return array
	 */
	public function getMergeServersLogByAgentId( $iAgentId, $iServerId = '' )
	{
		$cSqlStr = '';
		$cWhere = ' WHERE 1 = 1';
		$cSqlStr .= 'SELECT * FROM `'.$this->cTableName.'`';
		$cWhere .= ' AND `agentId` = '.$iAgentId;
		if( '' != $iServerId ) $cWhere .= ' AND `serverId` = '.$iServerId;
		$cWhere .= ' ORDER BY `serverId` ASC';
		$cSqlStr .= $cWhere;
		return fetchRowSet( $cSqlStr );
	}

	/**
	 * @desc get Server mergeserver log info by agent id
	 * @param int $iAgentId
	 * @param int $iServerId
	 * @return array
	 */
	public function getMergeServersLogByAgentIdAndServerId( $iAgentId, $iServerId )
	{
		$cSqlStr = '';
		$cWhere = ' WHERE 1 = 1';
		$cSqlStr .= 'SELECT * FROM `'.$this->cTableName.'`';
		$cWhere .= ' AND `agentId` = '.$iAgentId;
		$cWhere .= ' AND `serverId` = '.$iServerId;
		$cWhere .= ' ORDER BY `serverId` ASC';
		$cSqlStr .= $cWhere;
		return fetchRowOne( $cSqlStr );
	}
	/**
	 * @desc add one merge servers log
	 * @param array $Arr_MergeServerLog
	 * @return mixed
	 */
    public function addMergeServerLog( $Arr_MergeServerLog )
    {
    	$cSqlStr = '';
    	$cSqlStr .= makeInsertSql( $this->cTableName, $Arr_MergeServerLog );
    	return dbQuery( $cSqlStr );
    }
    
    
    /**
     * @desc this is destruct function of this class
     * @param void
     * @return void
     */
    public function __destruct()
    {
    	
    }
    
}