<?php
/**
 * @author linruirong@4399.com
 * @Created  Tue Oct 25 06:59:19 GMT 2011
 * @desc 系统权限项管理
 */
include_once(SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'admin_group.php');
class Menu {
	
	const GATEWAY_SYSTEM =1; //网关系统
	const GAME_ADMIN_SYSTEM =2; //游戏管理后台
	const GM_ADMIN_SYSTEM =3; //GM管理后台
	const CENTRAL_ADMIN_SYSTEM =4; //中央后台
	
	//系统类别：
	public $arrSystemType = array(
		self::GATEWAY_SYSTEM => '登录授权系统',
		self::GAME_ADMIN_SYSTEM => '游戏管理后台',
		self::GM_ADMIN_SYSTEM => 'GM管理后台',
		self::CENTRAL_ADMIN_SYSTEM => '中央后台',
	);
	
	
	const VISIBLE_SHOW =1; //菜单栏中显示
	const VISIBLE_HIDE =2; //不在菜单栏中显示
	//可见性
	public $arrVisibleType = array(
		self::VISIBLE_SHOW  => '菜单栏中显示',
		self::VISIBLE_HIDE  => '不在菜单栏中显示',
	);
		
	public function getAllClass()
	{
		$sql = " select distinct `class` from t_menu  order by `belongTo`, `orderNum` ";
		$rsClass = fetchRowSet($sql);
		$arrClass = array();
		foreach ($rsClass as $row) {
			array_push($arrClass, $row['class']);
		}
		return $arrClass;
	}
	
	
	public function getAllMenu($withText=true)
	{
		$sql = " select * from t_menu order by belongTo, orderNum ";
		$rsMenu = fetchRowSet($sql);
		if ($withText && is_array($rsMenu)) {
			foreach ($rsMenu as &$row) {
				$row['belongToText'] = $this->arrSystemType[$row['belongTo']];
				$row['visibleText'] = $this->arrVisibleType[$row['visible']];
			}
		}
		return $rsMenu;
	}
	
	function getMenuById($id)
	{
		$id = intval($id);
		$sql = " select * from t_menu where `id`='{$id}' ";
		return  fetchRowOne($sql);
	}
		
	function deleteMenu($id)
	{
		$id = intval($id);
		$sql = "delete from t_menu where `id`={$id} ";
		return dbQuery($sql);
	}
	
	
	function addMenu($class, $name, $url, $belongTo, $visible, $orderNum=100)
	{
		$class = SS($class);
		$name = SS($name);
		$url = SS($url);
		$belongTo = intval($belongTo);
		$visible = intval($visible);
		$orderNum = intval($orderNum);
		$id = md5($belongTo.$url);
		
		$sql = " insert into t_menu (`class`, `name`, `url`, `belongTo`, `visible`, `orderNum`) 
				 values ('{$class}', '{$name}', '{$url}', '{$belongTo}', '{$visible}', '{$orderNum}') ";
		return dbQuery($sql);
	}
	
	function updateMenu($id, $class, $name, $url, $belongTo, $visible, $orderNum=100)
	{
		$id = intval($id);
		$class = SS($class);
		$name = SS($name);
		$url = SS($url);
		$belongTo = intval($belongTo);
		$visible = intval($visible);
		$orderNum = intval($orderNum);
		
		$sql = "  update t_menu set `class`='{$class}', `name`='{$name}', `url`='{$url}', `belongTo`='{$belongTo}', `visible`='{$visible}', `orderNum`='{$orderNum}'  where `id` = '{$id}' ";
		return dbQuery($sql);
	}
	
	
	function getAllMenuNames()
	{
		$sql = " select `id`, `name` from t_menu  order by `belongTo`, `orderNum` ";
		$rsMenu = fetchRowSet($sql);
		$arr = array();
		foreach ($rsMenu as $row) {
			$arr[$row['id']] = $row['name'];
		}
		return $arr;
	}
	
	
	function getMenuByUrl($belongTo, $url)
	{
		$belongTo = intval($belongTo);
		$url = SS($url);
		$sql = " select `id`, `name` from t_menu  where `belongTo`='{$belongTo}' and `url`='{$url}' ";
		return fetchRowOne($sql);
	}
	
	/**
	 * 根据系统取得显示在左边的菜单
	 *
	 * @param string $belongTo 所属系统
	 * @return array
	 */
	function getMyMenu($belongTo)
	{
		$user = getSession('user');
		$rules = $user['rules'];
		$menu = array();
		$userId = intval($user['uid']);
		if ($userId && self::GATEWAY_SYSTEM != $belongTo ) {
			$sql = " select mc.* from t_menu_counter mc, t_menu m where mc.menuId=m.id and m.belongTo={$belongTo} and mc.uid={$userId} order by mc.counter desc limit ".STAPLE_MENU_LIMIT;
			$rs = fetchRowSet($sql);
			if (is_array($rules) && is_array($rs)) {
				foreach ($rs as $row) {
					foreach ($rules as $rule) {
						if ($rule['id'] == $row['menuId']) {
							$menu['常用菜单'][] = array(
								'id'=>$rule['id'],
								'class'=>$rule['class'],
								'name'=>$rule['name'],
								'url'=>$rule['url'],
							);
							break;
						}
					}
				}
			}
		}
		
		if (is_array($rules) && !empty($rules)) {
			foreach ($rules as $rule) {
				if ($belongTo == $rule['belongTo'] && $rule['visible'] == self::VISIBLE_SHOW ) {
					$menu[$rule['class']][] = array(
						'id'=>$rule['id'],
						'class'=>$rule['class'],
						'name'=>$rule['name'],
						'url'=>$rule['url'],
					);
				}
			}
		}
		return $menu;
	}
	
	/**
	 * 根据系统取得显示在左边的菜单
	 *
	 * @param string $belongTo 所属系统
	 * @return array
	 */
	function getMyRulesBySystem($belongTo)
	{
		$user = getSession('user');
		$rules = $user['rules'];
		$arrRule = array();
		
		$userId = intval($user['uid']);
		if ($userId) {
			$sql = " select mc.* from t_menu_counter mc, t_menu m where mc.menuId=m.id and m.belongTo={$belongTo} and mc.uid={$userId} order by mc.counter desc limit ".STAPLE_MENU_LIMIT;
			$rs = fetchRowSet($sql);
			if (is_array($rules) && is_array($rs)) {
				foreach ($rs as $row) {
					foreach ($rules as $rule) {
						if ($rule['id'] == $row['menuId']) {
							$rule['class'] = '常用菜单';
							array_push($arrRule, $rule);
							break;
						}
					}
				}
			}
		}
		
		if (is_array($rules) && !empty($rules)) {
			foreach ($rules as $rule) {
				if ($belongTo == $rule['belongTo']) {
					array_push($arrRule, $rule);
				}
			}
		}
		return $arrRule;
	}
}