<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Oct 21 03:31:16 GMT 2011
 * @desc 管理后台用户
 */
class AdminUser {

	const STATUS_ENABLE = 1;
	const STATUS_DISABLE = 2;
	const STATUS_PAST_DUE = 3;

	public static $arrStatus =array(
		self::STATUS_ENABLE => '启用中',
		self::STATUS_DISABLE => '禁用中',
		self::STATUS_PAST_DUE => '被系统冻结',
	);


	public function updateLastLoginTime($uid)
	{
		$now = time();
		$sql = " update `t_admin_user` set `lastLoginTime`={$now} where `uid`={$uid} ";
		return dbQuery($sql);
	}

	public function setUserEnable($uid)
	{
		$now = time();
		$status = self::STATUS_ENABLE;
		$sql = " update `t_admin_user` set `userStatus`={$status}, `lastLoginTime`={$now} where `uid`={$uid} ";
		return dbQuery($sql);
	}

	public function setUserDisable($uid)
	{
		$status = self::STATUS_DISABLE;
		$sql = " update `t_admin_user` set `userStatus`={$status}  where `uid`={$uid} ";
		return dbQuery($sql);
	}

	function getStatus($status, $lastLoginTime)
	{
		if (self::STATUS_ENABLE == $status && ($lastLoginTime + PAST_DUE_DAYS*86400) < time() ) {
			return self::STATUS_PAST_DUE;
		}elseif (self::STATUS_ENABLE == $status && ($lastLoginTime + PAST_DUE_DAYS*86400) >= time()) {
			return self::STATUS_ENABLE;
		}elseif (self::STATUS_DISABLE == $status) {
			return self::STATUS_DISABLE;
		}
		return false;
	}

	public function getAllUser()
	{
		$sql = " select u.gmAgentId, u.centralAgentId, u.gameAdminAgentId, u.uid, u.username, u.passwd, u.deny, u.allow, u.lastLoginTime, u.groupId,g.groupName,
				        u.remarks, u.lastChangePasswd, u.userStatus
		 		 from t_admin_user u left join t_admin_group g on u.groupId=g.id ";
		$rsUsers = fetchRowSet($sql);
		
		$objAent = new Agent();
		$agents = $objAent->getAgents();
		foreach ($rsUsers as &$row) {
			$row['userStatus'] = $this->getStatus($row['userStatus'],$row['lastLoginTime']);
			$row['userStatusText'] = self::$arrStatus[$row['userStatus']];
			$row['gmAgentName'] = $agents[$row['gmAgentId']];
			$row['gameAdminAgentName'] = $agents[$row['gameAdminAgentId']];
		}
		return $rsUsers;
	}

	function getUserById($userId)
	{
		$sql = " select * from t_admin_user where `uid`={$userId} ";
		$rs = fetchRowOne($sql);
		$rs['userStatus'] = $this->getStatus($rs['userStatus'],$rs['lastLoginTime']);
		$rs['userStatusText'] = self::$arrStatus[$rs['userStatus']];
		return $rs;
	}

	function getUserByName($username)
	{
		$sql = " select * from t_admin_user where `username`='{$username}' ";
		$rs = fetchRowOne($sql);
		$rs['userStatus'] = $this->getStatus($rs['userStatus'],$rs['lastLoginTime']);
		$rs['userStatusText'] = self::$arrStatus[$rs['userStatus']];
		return $rs;
	}


	function deleteUser($id)
	{
		$id = intval($id);
		$sql = "delete from t_admin_user where `uid`={$id} ";
		return dbQuery($sql);
	}

	function addUser($username, $passwd, $groupId, $gmAgentId, $centralAgentId, $gameAdminAgentId, $gameAdminServer, $remarks='')
	{
		$username = SS($username);
		$passwd = md5($passwd);
		$groupId = intval($groupId);
		$gmAgentId = intval($gmAgentId);
		$centralAgentId = intval($centralAgentId);
		$gameAdminAgentId = intval($gameAdminAgentId);
		$gameAdminServer = SS($gameAdminServer);
		
		$remarks = SS($remarks);
		$now = time();
		$status = self::STATUS_ENABLE ;
		$sql = " insert into t_admin_user (`username`, `passwd`, `groupId`, `remarks`, `lastChangePasswd`, `lastLoginTime`, `userStatus`, `gmAgentId`, `centralAgentId`, `gameAdminAgentId`, `gameAdminServer`) 
				 values ('{$username}', '{$passwd}', '{$groupId}', '{$remarks}', '0', '{$now}','{$status}','{$gmAgentId}','{$centralAgentId}', '{$gameAdminAgentId}', '{$gameAdminServer}') ";
		return dbQuery($sql);
	}

	function updateUser($userId, $groupId, $gmAgentId, $centralAgentId, $gameAdminAgentId, $gameAdminServer, $remarks='', $passwd='')
	{
		$userId = intval($userId);
		$groupId = intval($groupId);
		$gmAgentId = intval($gmAgentId);
		$centralAgentId = intval($centralAgentId);
		$gameAdminAgentId = intval($gameAdminAgentId);
		$gameAdminServer = SS($gameAdminServer);
		$remarks = SS($remarks);
		if ($passwd) {
			$passwd = md5($passwd);
			$sqlPasswd = ", `passwd`='{$passwd}' ";
		}
		$sql = " update t_admin_user set `groupId`= '{$groupId}', `gmAgentId`= '{$gmAgentId}', `centralAgentId`='{$centralAgentId}', 
			    `gameAdminAgentId`='{$gameAdminAgentId}', `gameAdminServer`='{$gameAdminServer}', `remarks`='{$remarks}' {$sqlPasswd} where `uid`={$userId} ";
		return dbQuery($sql);
	}

	function updateUserPasswd($userId, $newPasswd)
	{
		$userId = intval($userId);
		$passwd = md5($newPasswd);
		$now = time();
		$sql = " update t_admin_user set `passwd`='{$passwd}', `lastChangePasswd`={$now}  where `uid`={$userId} ";
		return dbQuery($sql);
	}




	//测试某个字符是属于哪一类.
	private function charMode($ch){
		$asii = ord($ch);
		if ($asii>=48 && $asii <=57) //数字
		return 1;
		if ($asii>=65 && $asii <=90) //大写字母
		return 2;
		if ($asii>=97 && $asii <=122) //小写
		return 4;
		else
		return 8; //特殊字符
	}

	//计算出当前密码当中一共有多少种模式
	private function bitTotal($num){
		$modes=0;
		for ($i=0; $i<4; $i++){
			if ($num & 1){
				$modes++;
			}
			$num >>=1;
		}
		return $modes;
	}

	//返回密码的强度级别 0=太短 ,1=弱 , 2=一般, 3=很好,4=极佳
	function checkPasswdRate($passwd){
		$len = strlen($passwd);
		if ( $len <  8) {
			return 0; //密码太短
		}
		$modes=0;
		for ($i=0; $i<$len; $i++){
			//测试每一个字符的类别并统计一共有多少种模式.
			$modes |= $this->charMode($passwd{$i});
		}
		return $this->bitTotal($modes);
	}

}