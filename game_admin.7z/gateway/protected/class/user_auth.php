<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Oct 28 12:22:12 GMT 2011
 * @desc 用于用户权限验证
 */
include_once(SYSDIR_ADMIN_CONFIG.'/allow.php');

include_once(SYSDIR_ADMIN_CLASS.'/admin_group.php');
include_once(SYSDIR_ADMIN_CLASS.'/admin_user.php');
include_once(SYSDIR_ADMIN_CLASS.'/menu.php');
include_once(SYSDIR_ADMIN_CLASS.'/agent.php');
include_once(SYSDIR_ADMIN_CLASS.'/server.php');

class UserAuth
{
	const AUTH_RESULT_OK = 1;
	const AUTH_RESULT_NOT_LOGIN = 2;
	const AUTH_RESULT_NO_PERMITION = 3;
	
	const LOGINT_RESULT_USER_OK = 1;
	const LOGINT_RESULT_USER_DISABLE = 2;
	const LOGINT_RESULT_USER_PAST_DUE = 3;
	const LOGINT_RESULT_USER_PASS_ERR = 4;
	
	public function getUserName()
	{
		$user = getSession('user');
		return $user['username'];
	}
	
	function login($username, $passwd)
	{
		$objGroup = new AdminGroup();
		if (defined('ROOT_USERNAME') && ROOT_USERNAME == $username ) {
			if (!defined('ENABLE_ROOT_USER') || !ENABLE_ROOT_USER ) {
				return self::LOGINT_RESULT_USER_DISABLE;
			}
			if ( ROOT_PASSWORD !== $passwd ) {
				return self::LOGINT_RESULT_USER_PASS_ERR;
			}
			$rules = $objGroup->getUserRules(ROOT_USERNAME);
			$user = array(
				'uid'=>0,
				'username'=>ROOT_USERNAME,
				'passwd'=>ROOT_PASSWORD,
				'groupId'=>0,
				'gmAgentId'=>Agent::ALL_AGENT_KEY,
				'centralAgentId'=>Agent::ALL_AGENT_KEY,
				'gameAdminAgentId'=>Agent::ALL_AGENT_KEY,
				'gameAdminServer'=>Server::ALL_SERVER_KEY ,
				'lastLoginTime'=>time(),
				'lastChangePasswd'=>time(),
				'userStatus'=>AdminUser::STATUS_ENABLE,
				'remarks'=>ROOT_USERNAME,
				'rules'=>$rules,
			);
			setSession('user',$user);
			return self::LOGINT_RESULT_USER_OK ;
		}else {
			$objUser = new AdminUser();
			$userInfo = $objUser->getUserByName($username);
			if ($userInfo['passwd'] === md5($passwd)) {
				if (AdminUser::STATUS_ENABLE == $userInfo['userStatus']) {
					$rules = $objGroup->getUserRules($username);
					if ($userInfo['gameAdminServer']) {
						if (Server::ALL_SERVER_KEY == $userInfo['gameAdminServer']) {
							$gameAdminServer = Server::ALL_SERVER_KEY ;
						}else {
							$gameAdminServer = json_decode($userInfo['gameAdminServer'], true);
						}
					}else {
						$gameAdminServer = array();
					}
					$user = array(
						'uid'=>$userInfo['uid'],
						'username'=>$userInfo['username'],
						'passwd'=>$userInfo['passwd'],
						'groupId'=>$userInfo['groupId'],
						'gmAgentId'=>$userInfo['gmAgentId'],
						'centralAgentId'=>$userInfo['centralAgentId'],
						'gameAdminAgentId'=>$userInfo['gameAdminAgentId'],
						'gameAdminServer'=>&$gameAdminServer,
						'lastLoginTime'=>$userInfo['lastLoginTime'],
						'lastChangePasswd'=>$userInfo['lastChangePasswd'],
						'userStatus'=>$userInfo['userStatus'],
						'remarks'=>$userInfo['remarks'],
						'rules'=>$rules,
					);
					$objUser->updateLastLoginTime($userInfo['uid']);
					setSession('user',$user);
					return self::LOGINT_RESULT_USER_OK;
				}elseif (AdminUser::STATUS_DISABLE == $userInfo['userStatus']) {
					return self::LOGINT_RESULT_USER_DISABLE ;
				}elseif (AdminUser::STATUS_PAST_DUE == $userInfo['userStatus']){
					return self::LOGINT_RESULT_USER_PAST_DUE ;
				}
			}else {
				return self::LOGINT_RESULT_USER_PASS_ERR ;
			}
		}
	}
	
	
	/**
	 * 验证用户是否有权限
	 *
	 * @return bool
	 */
	public function auth()
	{
		$url = trim(str_replace(SYSDIR_ADMIN_PUBLIC, '', realpath($_SERVER['SCRIPT_FILENAME']) ),'/');
		$userInfo = getSession('user');
		
		global $ALLOW_ACCESS_PAGE;
		global $LOGIN_ALLOW_ACCESS_PAGE;
		if (in_array($url,$ALLOW_ACCESS_PAGE)) { //如果不需要验证即可访问的
			return self::AUTH_RESULT_OK;
		}
		if ('' != $userInfo['username'] && in_array($url, $LOGIN_ALLOW_ACCESS_PAGE) ) { //对于所有已经登录用户都可以访问的
			return self::AUTH_RESULT_OK;
		}
		$exist = false;
		if ( is_array($userInfo['rules']) && !empty($userInfo) ) {
			foreach ($userInfo['rules'] as $rule) {
				if ( $url == $rule['url'] && Menu::GATEWAY_SYSTEM == $rule['belongTo']) {
					global $navPosition;
					$navPosition=$rule['class'].' &gt;&gt; '.$rule['name'];
					$exist = true;
					break;
				}
			}
		}else {
			return self::AUTH_RESULT_NOT_LOGIN ;
		}
		if ('' != $userInfo['username'] && $exist ) { //如果用户已经登录，且其权限列表里面有本系统此url的访问权
			return self::AUTH_RESULT_OK;
		}
		return self::AUTH_RESULT_NO_PERMITION ;
	}
}