<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Oct 21 03:31:16 GMT 2011
 * @desc 管理后台用户组，现只支持一个用户拥有一个组的权限。
 *       暂不支持一个用户属于多个组的情况。
 */
class AdminGroup {
	
	
	public function getAllGroupsKeyName()
	{
		$sql = " select `id`, `groupName` from t_admin_group ";
		$rsGroups = fetchRowSet($sql);
		$arrGroup = array();
		foreach ($rsGroups as $row) {
			$arrGroup[$row['id']] = $row['groupName'] ;
		}
		return $arrGroup;
	}
	
	public function getAllGroups()
	{
		$sql = " select * from t_admin_group ";
		$rsGroups = fetchRowSet($sql);
		foreach ($rsGroups as &$row) {
			$row['strRules'] = $this->getRulesText( $row['rules'] );
		}
		return $rsGroups;
	}
	
	function getGroupById($groupId)
	{
		$sql = " select * from t_admin_group where `id`={$groupId} ";
		$rs =  fetchRowOne($sql);
		$rs['rules'] = $rs['rules'] ? explode(',',$rs['rules']) : array();
		return $rs;
	}
	
	function getRulesText($ruleIds)
	{
		global $ADMIN_PAGE_CONFIG;
		$rules = explode(',',$ruleIds);
		$strRules = '';
		if (is_array($rules)) {
			foreach ($rules as $ruleItem) {
				 $strRules .= $ADMIN_PAGE_CONFIG[$ruleItem]['name'].', ';
			}
		}
		return $strRules;
	}
	
	function deleteGroup($id)
	{
		$id = intval($id);
		$sql = "delete from t_admin_group where `id`={$id} ";
		return dbQuery($sql);
	}
	
	function addGroup($groupName, $strRules, $remarks='')
	{
		$groupName = SS($groupName);
		$strRules = SS($strRules);
		$remarks = SS($remarks);
		$sql = " insert into t_admin_group (`groupName`, `rules`, `remarks`) values ('{$groupName}', '{$strRules}', '{$remarks}') ";
		return dbQuery($sql);
	}
	
	function updateGroup($groupId, $strRules, $remarks='')
	{
		$groupId = intval($groupId);
		$strRules = SS($strRules);
		$remarks = SS($remarks);
		$sql = " update t_admin_group set `rules`= '{$strRules}', `remarks`='{$remarks}' where `id`={$groupId} ";
		return dbQuery($sql);
	}
	
	
	/**
	 * 取得用户有权限访问的菜单
	 * @return array
	 */
	function getUserRules($username)
	{
		if (ENABLE_ROOT_USER && ROOT_USERNAME == $username) {
			$sql = " select * from t_menu order by `belongTo`, `orderNum` ";
		}else {
			$sql = " select groupId from t_admin_user where `username`='{$username}' ";
			$rs = fetchRowOne($sql);
			$groupId = intval($rs['groupId']);
			$rsGroup = $this->getGroupById($groupId);
			$arrMenuIdList = $rsGroup['rules'];
			$strIds = '';
			foreach ($arrMenuIdList as $menuId) {
				if ($menuId) {
					$strIds .= "'{$menuId}',";
				}
			}
			$strIds = trim($strIds,',');
			if (!$strIds) {
				return array();
			}
			$sql = " select * from t_menu where `id` in( {$strIds} )  order by `belongTo`, `orderNum` ";
		}
		$rsMenu = fetchRowSet($sql);

		return $rsMenu;
	}
}