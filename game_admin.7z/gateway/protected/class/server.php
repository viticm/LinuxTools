<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Jan 06 04:39:11 GMT 2012
 * @desc 服务器管理
 */
class Server {
	
	const ALL_SERVER_KEY = 9999; //所有服务器
	
	//取得某个代理下所有的服务器
	function getServersByAgentId($agentId, $fomateAgent=true)
	{
		$agentId = intval($agentId);
		$where = '';
		if ( Agent::ALL_AGENT_KEY != $agentId) {
			$where = " where agentId={$agentId} ";
		}
		$sql = " select * from t_game_server {$where} order by agentId, serverId ";
		$rs = fetchRowSet($sql);
		if ($fomateAgent) {
			$arrServers = array();
			foreach ($rs as $row) {
				if ( !is_array($arrServers[$row['agentId']]) ) {
					$arrServers[$row['agentId']] = array(
						'agentId'=>$row['agentId'],
						'agentName'=>$row['agentName'],
						'servers'=>array(),
					);
				}
				$arrServers[$row['agentId']]['servers'][] = $row;
			}
			return $arrServers;
		}else {
			return $rs;
		}
	}	

	//取得某个代理下所有未合并的服务器（api使用）
	function getNotMergeServersIdByAgentId($agentId)
	{
		$agentId = intval($agentId);
		$where = '';
		if ( Agent::ALL_AGENT_KEY != $agentId) {
			$where = " where agentId={$agentId} ";
		}
		$where .= 'AND serverId NOT IN ( SELECT serverId FROM `t_log_mergeservers` WHERE agentId='.$agentId.' )';
		$sql = " select serverId from t_game_server {$where} order by serverId ";
		$rs = fetchRowSet($sql);
		$Arr_NotMergeServerId = array();
		foreach ( $rs as $row ) array_push( $Arr_NotMergeServerId, $row['serverId'] );
        return $Arr_NotMergeServerId;
	}

	/**
	 * @desc 获取单个服务器的配置信息
	 * @param int $iAgentId
	 * @param int $iServerId
	 * @return mixed
	 */
	function getOneServerConfByAgentIdAndServerId( $iAgentId, $iServerId )
	{
		$cSqlStr = '';
		$cWhere = ' WHERE 1 = 1';
		$cSqlStr .= ' SELECT dbHost,dbUser,dbPasswd,dbName,dbGameHost,dbGameUser,dbGamePasswd,dbGameDbName FROM `t_game_server`';
		$cWhere .= ' AND agentId = '.$iAgentId;
		$cWhere .= ' AND serverId = '.$iServerId;
		$cSqlStr .= $cWhere;
		return fetchRowOne( $cSqlStr );
	}
	
	//取得当前登录用户有权限控制的所有的服务器
	function getMyAgentServers($fomateAgent=true)
	{
		$user = getSession('user');
//		echo '<pre>';print_r($user);echo '</pre>';die();
		$where = '';
		if (!$user['gameAdminAgentId']) {
			return array();
		}elseif ( Agent::ALL_AGENT_KEY != $user['gameAdminAgentId']) {
			$where = " where agentId={$user['gameAdminAgentId']} ";
		}
		$sql = " select * from t_game_server {$where} order by agentId, serverId ";
		$rs = fetchRowSet($sql);
//		echo '<pre>';print_r($rs);echo '</pre>';die();
		$rsTmp = array();
		if (is_array($user['gameAdminServer'])) {
			if ( !empty($user['gameAdminServer']) ) {
				foreach ($user['gameAdminServer'] as $agentId => $serverIds) {
					if (is_array($serverIds)) {
						foreach ($serverIds as $skey => $sid) {
							foreach ($rs as $r) {
								if ($r['agentId']==$agentId && $r['serverId'] == $sid) {
									array_push($rsTmp , $r);
									unset($user['gameAdminServer'][$agentId][$skey]);
									break;
								}
							}
						}
					}
				}
			}else {
				return array();
			}
		}elseif (Server::ALL_SERVER_KEY == $user['gameAdminServer']){
			$rsTmp = &$rs;
		}
		if ($fomateAgent) {
			$arrServers = array();
			foreach ($rsTmp as $row) {
				if ( !is_array($arrServers[$row['agentId']]) ) {
					$arrServers[$row['agentId']] = array(
						'agentId'=>$row['agentId'],
						'agentName'=>$row['agentName'],
						'servers'=>array(),
					);
				}
				$arrServers[$row['agentId']]['servers'][] = $row;
			}
			return $arrServers;
		}else {
			return $rsTmp;
		}
	}	
	
	//取得某个服务器
	function getServerById($agentId, $serverId)
	{
		$agentId = intval($agentId);
		$serverId = intval($serverId);
		$sql = " select * from t_game_server where `agentId`={$agentId} and serverId={$serverId} ";
		$rs = fetchRowOne($sql);
		return $rs;
	}
	
	//取得某个服务器
	function getServerByServerName($serverName)
	{
		$serverName = SS($serverName);
		$sql = " select * from t_game_server where `serverName`='{$serverName}'";
		$rs = fetchRowOne($sql);
		return $rs;
	}
	
}