<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Jan 06 04:39:11 GMT 2012
 * @desc 代理商管理
 */
class Agent {
	
	const ALL_AGENT_KEY = 9999; //所有代理
	
	/**
	 * @param bool $withAll
	 * @return array
	 */
	public function getAgents($withAll=true)
	{
		$sql = " select * from t_agent ";
		$rs = fetchRowSet($sql);
		$arr = array();
		foreach ($rs as $r) {
			$arr[$r['agentId']] = $r['agentName'];
		}
		if (!$withAll) {
			unset($arr[self::ALL_AGENT_KEY]);
		}
		return $arr;
	}
}