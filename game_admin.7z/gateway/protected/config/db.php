<?php
global $dbConfig;
$dbConfig = array(
        'host' => 'localhost',
        'user' => 'root_gm',
        'passwd' => 'mysql',
	'dbname' => 'admin_gateway',
);
