<?php
//=============定义各目录常量=========//
define('SYSDIR_ADMIN', realpath(dirname(__FILE__).'/../../')); //根目录
define('SYSDIR_ADMIN_PROTECTED', SYSDIR_ADMIN.'/protected'); //受保护(拒绝WEB访问)目录
define('SYSDIR_ADMIN_PUBLIC', SYSDIR_ADMIN.'/public'); //公共(允许WEB访问)目录
define('SYSDIR_ADMIN_CONFIG', SYSDIR_ADMIN_PROTECTED.'/config'); //类目录
define('SYSDIR_ADMIN_CLASS', SYSDIR_ADMIN_PROTECTED.'/class'); //类目录
define('SYSDIR_ADMIN_INCLUDE', SYSDIR_ADMIN_PROTECTED.'/include'); //引用
define('SYSDIR_ADMIN_LIBRARY', SYSDIR_ADMIN_PROTECTED.'/library'); //第三方库
//=====================================//

//=========smarty相关配置==============//
define('SYSDIR_ADMIN_SMARTY_TEMPLATE', SYSDIR_ADMIN_PROTECTED.'/template'); //smarty模版目录
define('SYSDIR_ADMIN_SMARTY_TEMPLATE_C', SYSDIR_ADMIN_PROTECTED.'/template_c'); //smarty编译目录
define('SMARTY_COMPILE_CHECK', true);
define('SMARTY_FORCE_COMPILE', true);
define('SMARTY_LEFT_DELIMITER', '<{');
define('SMARTY_RIGHT_DELIMITER', '}>');
//===================================//

//===============================//
define('TIME_ZONE', 'PRC');  //时区设置
define('SESSION_KEY', 'sessAdminGateway'); //系统session key
define('PAST_DUE_DAYS', 20 ); //超过X天未登录，自动冻结帐号
define('CHANGE_PASSWORD_DAYS', 60 ); //超过X天未改密码，登录时提示
define('STAPLE_MENU_LIMIT', 10 ); //常用菜单最多显示多少个
//===============================//

//==========页面显示的定义=========//
define('LIST_PER_PAGE_RECORDS', 20); //Search page show ... records per page
define('LIST_SHOW_PREV_NEXT_PAGES', 10); //First Prev 1 2 3 4 5 6 7 8 9 10... Next Last
//===============================//

//==============日志相关设置==========//
define('SYSDIR_LOG','/data/logs/yjxy'); //存放路径
define('SYSFILE_LOG_FILE',SYSDIR_LOG.'/admin_gateway.log'); //系统运行日志
define('LOG_LEVEL',1); //日志级别 1:debug,info,error都会记录, 2: info,error , 3: error
//==================================//

//==============服务器常量==========//
define('GAME_NO', 'xafs'); //游戏代号(一般用拼音缩写)
define('GAME_NAME', '笑傲封神'); //游戏名称
//==================================//

//==============验证码开关================//
define('CHECK_CODE_SWITCH',false); //true=开，false=关
define('CHECK_CODE_TYPE','int');  //验证码展示的类型default:大写字母及数字,string:小写字母,int:数字); 
//==========end 验证码开关================//

//=======登录验证==================//
define('GATEWAY_SYSTEM_AUTH_KEY', 'b97c92ab1c955551d12aa135f7270e5c');//与各服管理后台跳转验证的key
define('ROOT_USERNAME', 'root');//管理后台的ROOT用户名
define('ROOT_PASSWORD', 'roothaha');//管理后台的ROOT用户密码
define('ENABLE_ROOT_USER', true);//是否启用超级帐号 true=启用 false=禁用
//================================//

//=======中央后台、GM系统地址==================//
define('GM_ADMIN_URL', 'http://gm.yjxy.local.com/');//GM系统地址
define('CENTRAL_ADMIN_URL', 'http://central.yjxy.local.com/');//中央后台
//================================//

//包含配置文件
include_once 'db.php';
session_start();
