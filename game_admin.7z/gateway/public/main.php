<?php
include_once '../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE."/global.php";

render("main.tpl");