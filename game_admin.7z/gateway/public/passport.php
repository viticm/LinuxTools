<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Oct 31 02:48:29 GMT 2011
 * @desc 此用于对接各子系统
 */

include_once '../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE."/global.php";
include_once SYSDIR_ADMIN_CLASS."/menu.php";
include_once SYSDIR_ADMIN_CLASS."/agent.php";
include_once SYSDIR_ADMIN_CLASS."/server.php";

$action = trim($_GET['action']);
$userInfo = getSession('user');
$time=time();
if ('gotoGameAdmin' == $action) { //转到游戏管理后台
	$objServer = new Server();
	$userAgentId = $userInfo['agentId']; //取得管理员有权限控制的代理商ID
	$arrAgentServer = $objServer->getMyAgentServers(false); //取得有权限的服务器列表
	$toServerName = trim($_GET['serverName']); //要跳转的服务器
	$result = 2; //若无权限
	$errorMsg = "无权限访问{$toServerName}";
	foreach ($arrAgentServer as $server) {
		if ($server['serverName'] == $toServerName) {
			$result = 1; 
			$errorMsg = '';
			$url = $server['gameAdminUrl'];
			$serverName = $server['serverName'];
			break;
		}
	}
	if (1==$result) {
		$objMenu = new Menu();
		$rules = $objMenu->getMyRulesBySystem(Menu::GAME_ADMIN_SYSTEM);
		unset($userInfo['passwd']);
		$userInfo['rules'] = $rules;
	}else {
		echo '<script language="javascript">alert("'.$errorMsg.'"); window.location.href="login.php";</script>';
		die();
	}

	$userInfo = json_encode($userInfo);
	$userInfo = trim(base64_encode(base64_encode($userInfo)),'=');
	$ticket = md5(GATEWAY_SYSTEM_AUTH_KEY.$time.$serverName.$userInfo);
	
	$data = array(
		'url' => $url.'passport.php',
		'time' => $time,
		'serverName' => $serverName,
		'ticket' => $ticket,
		'userInfo' =>&$userInfo,
	);
	render('passport.tpl',$data);
	
}elseif ('gotoGmAdmin'==$action){ //切换GM后台
	$objMenu = new Menu();
	$rules = $objMenu->getMyRulesBySystem(Menu::GM_ADMIN_SYSTEM);
	unset($userInfo['passwd']);
	$userInfo['rules'] = $rules;
	$userInfo = json_encode($userInfo);
	$userInfo = trim(base64_encode(base64_encode($userInfo)),'=');
	$ticket = md5(GATEWAY_SYSTEM_AUTH_KEY.$time.$userInfo);
	
	$data = array(
		'url' => GM_ADMIN_URL.'passport.php',
		'time' => $time,
		'ticket' => $ticket,
		'userInfo' =>&$userInfo,
	);
	render('passport.tpl',$data);
	
}elseif ('gotoCentralAdmin'==$action){ //切换中央后台
	$objMenu = new Menu();
	$rules = $objMenu->getMyRulesBySystem(Menu::CENTRAL_ADMIN_SYSTEM);
	unset($userInfo['passwd']);
	$userInfo['rules'] = $rules;
	$userInfo = json_encode($userInfo);
	$userInfo = trim(base64_encode(base64_encode($userInfo)),'=');
	$ticket = md5(GATEWAY_SYSTEM_AUTH_KEY.$time.$userInfo);
	
	$data = array(
		'url' => CENTRAL_ADMIN_URL.'passport.php',
		'time' => $time,
		'ticket' => $ticket,
		'userInfo' =>&$userInfo,
	);
	render('passport.tpl',$data);
	
}elseif ('changeToGameAdmin'==$action){
	$time = $_GET['time'];
	$serverName = $_GET['serverName'];
	$result = $_GET['result'];
	$ticket = $_GET['ticket'];
	$key = md5(GATEWAY_SYSTEM_AUTH_KEY.$action.$time.$serverName.$result);
	
	// 登录授权结果 1=成功, 2=超时, 3=参数不全 , 4=ticket错误 
	if ( abs(time()-$time) > 60 ) { //切换超时
		die( '<script language="javascript">alert("切换超时!"); window.location.href="index.php";</script>');
	}elseif (!$ticket||!$time||!$serverName||!$result){
		die( '<script language="javascript">alert("参数不全，切换失败!"); window.location.href="index.php";</script>');
	}elseif($ticket != $key) {
		die( '<script language="javascript">alert("ticket错误，切换失败!"); window.location.href="index.php";</script>');
	}else {
		if (1==$result) {
			$objServer = new Server();
			$server = $objServer->getServerByServerName($serverName);
			if (!$server['serverName']) {
				die( '<script language="javascript">alert("不存在此服务器!"); window.location.href="index.php";</script>');
			}
			$leftSrc = "{$server['gameAdminUrl']}left.php?currentServerName={$serverName}&rand=".rand(1,99999);//加随机数，解决浏览器缓存问题
			$mainSrc = "{$server['gameAdminUrl']}main.php?currentServerName={$serverName}&rand=".rand(1,99999);
			setSession('leftSrc',$leftSrc);
			setSession('mainSrc',$mainSrc);
			header('Location:index.php');
		}elseif (2==$result){
			die( '<script language="javascript">alert("切换超时!"); window.location.href="index.php";</script>');
		}elseif (3==$result){
			die( '<script language="javascript">alert("参数不全，切换失败!"); window.location.href="index.php";</script>');
		}elseif (4==$result){
			die( '<script language="javascript">alert("ticket错误，切换失败!"); window.location.href="index.php";</script>');
		}else {
			die( '<script language="javascript">alert("未知错误，切换失败!"); window.location.href="index.php";</script>');
		}
	}
}elseif ('changeToGateway'==$action){
	$leftSrc = "left.php?rand=".rand(1,99999);
	$mainSrc = "main.php?rand=".rand(1,99999);
	setSession('leftSrc',$leftSrc);
	setSession('mainSrc',$mainSrc);
	header('Location:index.php');
	
}elseif ('changeToGmAdmin'==$action){
	$time = $_GET['time'];
	$result = $_GET['result'];
	$ticket = $_GET['ticket'];
	$key = md5(GATEWAY_SYSTEM_AUTH_KEY.$action.$time.$result);
	
	// 登录授权结果 1=成功, 2=超时, 3=参数不全 , 4=ticket错误 
	if ( abs(time()-$time) > 60 ) { //切换超时
		die( '<script language="javascript">alert("切换超时!"); window.location.href="index.php";</script>');
	}elseif (!$ticket||!$time||!$result){
		die( '<script language="javascript">alert("1参数不全，切换失败!"); window.location.href="index.php";</script>');
	}elseif($ticket != $key) {
		die( '<script language="javascript">alert("ticket错误，切换失败!"); window.location.href="index.php";</script>');
	}else {
		if (1==$result) {
			$leftSrc = GM_ADMIN_URL."left.php?rand=".rand(1,99999);
			$mainSrc = GM_ADMIN_URL."main.php?rand=".rand(1,99999);
			setSession('leftSrc',$leftSrc);
			setSession('mainSrc',$mainSrc);
			header('Location:index.php');
		}elseif (2==$result){
			die( '<script language="javascript">alert("切换超时!"); window.location.href="index.php";</script>');
		}elseif (3==$result){
			die( '<script language="javascript">alert("2参数不全，切换失败!"); window.location.href="index.php";</script>');
		}elseif (4==$result){
			die( '<script language="javascript">alert("ticket错误，切换失败!"); window.location.href="index.php";</script>');
		}else {
			die( '<script language="javascript">alert("未知错误，切换失败!"); window.location.href="index.php";</script>');
		}
	}
}elseif ('changeToCentralAdmin'==$action){
	$time = $_GET['time'];
	$result = $_GET['result'];
	$ticket = $_GET['ticket'];
	$key = md5(GATEWAY_SYSTEM_AUTH_KEY.$action.$time.$result);
	
	// 登录授权结果 1=成功, 2=超时, 3=参数不全 , 4=ticket错误 
	if ( abs(time()-$time) > 60 ) { //切换超时
		die( '<script language="javascript">alert("切换超时!"); window.location.href="index.php";</script>');
	}elseif (!$ticket||!$time||!$result){
		die( '<script language="javascript">alert("1参数不全，切换失败!"); window.location.href="index.php";</script>');
	}elseif($ticket != $key) {
		die( '<script language="javascript">alert("ticket错误，切换失败!"); window.location.href="index.php";</script>');
	}else {
		if (1==$result) {
			$leftSrc = CENTRAL_ADMIN_URL."left.php?rand=".rand(1,99999);
			$mainSrc = CENTRAL_ADMIN_URL."main.php?rand=".rand(1,99999);
			setSession('leftSrc',$leftSrc);
			setSession('mainSrc',$mainSrc);
			header('Location:index.php');
		}elseif (2==$result){
			die( '<script language="javascript">alert("切换超时!"); window.location.href="index.php";</script>');
		}elseif (3==$result){
			die( '<script language="javascript">alert("2参数不全，切换失败!"); window.location.href="index.php";</script>');
		}elseif (4==$result){
			die( '<script language="javascript">alert("ticket错误，切换失败!"); window.location.href="index.php";</script>');
		}else {
			die( '<script language="javascript">alert("未知错误，切换失败!"); window.location.href="index.php";</script>');
		}
	}
	header('Location:index.php');
}
