<?php
/**
 * @author viticm(duchuanpd@gmail.com)
 * @Created 2013-8-20
 * @desc 所有区服的服务器概况
 */
require_once ( '../../protected/config/config.php' );
require_once ( SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php' );
require_once ( SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'my_global.php' );
require_once ( SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'agent.php' );

$iDateTime = strtotime( $_POST[ 'date' ] ) ;
$iAgentId  = intval( $_POST[ 'agentId' ] ) ;
// $iServerId = intval( $_POST[ 'serverId' ] ) ;
$iDateTime = $iDateTime ? $iDateTime : strtotime( date( 'Y-m-d', strtotime( '-1day' ) ) ) ;
$iDateTime = $iDateTime > strtotime( date( 'Y-m-d', strtotime( '-1day' ) ) ) ? strtotime( date( 'Y-m-d', strtotime( '-1day' ) ) ) : $iDateTime ;
$szDate    = date( 'Y-m-d', $iDateTime ) ;
$iAgentId = $iAgentId ? $iAgentId  : Agent::ALL_AGENT_KEY ; //默认所有代理
$iAgentId = Agent::ALL_AGENT_KEY == $iAgentId ? '' : $iAgentId ;
$Arr_Agent = Agent::getAgents();
$dateEndStamp += 24 * 60 * 60;
$OBJ_ServerSummary = new ServerSummary() ;

$Arr_ServerSummary = array() ;
$Arr_ServerSummary = $OBJ_ServerSummary->getServersSummary( $iDateTime, $iAgentId ) ;

$Arr_SummaryAmount = array() ;
$Arr_SummaryAmount[ 'totalServer' ]    = 0 ;
$Arr_SummaryAmount[ 'totalRole' ]      = 0 ;
$Arr_SummaryAmount[ 'totalPay' ]       = 0 ;
$Arr_SummaryAmount[ 'totalPayRole' ]   = 0 ;
$Arr_SummaryAmount[ 'totalLogin' ]     = 0 ;
$Arr_SummaryAmount[ 'totalReg' ]       = 0 ;
$Arr_SummaryAmount[ 'totalDayPay' ]    = 0 ;

foreach ( $Arr_ServerSummary as $k => &$val )
{
    $val[ 'arrServerSummary' ] = json_decode( $val[ 'summaryJson' ], true ) ;
    $Arr_SummaryAmount[ 'totalServer' ]    += 1 ;
    $Arr_SummaryAmount[ 'totalRole' ]      += $val[ 'arrServerSummary' ][ 'totalRole' ] ;
    $Arr_SummaryAmount[ 'totalPay' ]       += $val[ 'arrServerSummary' ][ 'totalPay' ] ;
    $Arr_SummaryAmount[ 'totalPayRole' ]   += $val[ 'arrServerSummary' ][ 'totalPayRole' ] ;
    $Arr_SummaryAmount[ 'totalLogin' ]     += $val[ 'arrServerSummary' ][ 'loginCnt' ] ;
    $Arr_SummaryAmount[ 'totalReg' ]       += $val[ 'arrServerSummary' ][ 'regCnt' ] ;
    $Arr_SummaryAmount[ 'totalDayPay' ]    += $val[ 'arrServerSummary' ][ 'selfDayPay' ] ;
    unset( $val[ 'summaryJson' ] ) ;
}

$Arr_Data = array(
    'Arr_Agent'            => $Arr_Agent,
    'iAgentId'             => $iAgentId,
    'date'                 => $szDate,
    'Arr_ServerSummary'    => $Arr_ServerSummary,
    'Arr_SummaryAmount'    => $Arr_SummaryAmount,
);
unset( $OBJ_ServerSummary ) ;
render( 'server/servers_summary.tpl', $Arr_Data );