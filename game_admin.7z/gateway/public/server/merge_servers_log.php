<?php
/**
 * @author viticm(duchuanpd@gmail.com)
 * @Created 2013-4-24
 * @desc 游戏管理后台合区日志
 */
require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');
require_once ( SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'agent.php' );
require_once ( SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'mergeservers_log.php' );


$dateStartStamp = strtotime($_POST['dateStart']);
$dateEndStamp   = strtotime($_POST['dateEnd']);
$iAgentId = intval($_POST['agentId']);
$dateStartStamp = $dateStartStamp ? $dateStartStamp : strtotime(date('Y-m-d',strtotime('-6day')));
$dateEndStamp = $dateEndStamp ? $dateEndStamp : strtotime(date('Y-m-d',time()));
$dateEndStamp = $dateEndStamp < $dateStartStamp ? $dateStartStamp : $dateEndStamp;
$dateStart = date('Y-m-d', $dateStartStamp);
$dateEnd = date('Y-m-d', $dateEndStamp);

$iAgentId = $iAgentId ? $iAgentId  : Agent::ALL_AGENT_KEY; //默认所有代理
$Arr_Agent = Agent::getAgents();
$dateEndStamp += 24 * 60 * 60;
$cSqlStr = '';
$cWhere = ' WHERE 1 = 1';
$cSqlStr .= 'SELECT * FROM `t_log_mergeservers`';
$cWhere .= " AND {$dateStartStamp} <= `mergeTime` AND `mergeTime` <= {$dateEndStamp}";
$cWhere .= $iAgentId == Agent::ALL_AGENT_KEY ? '' : ' AND `agentId` = '.$iAgentId;
$cWhere .= ' ORDER BY `mergeTime` ASC';
$cSqlStr .= $cWhere;
$Arr_MergeServerLogs = array();
$Arr_MergeServerLogs = fetchRowSet( $cSqlStr );

$data = array(
    'Arr_Agent' => $Arr_Agent,
    'iAgentId'=>$iAgentId,
    'dateStart'=>$dateStart,
    'dateEnd' => $dateEnd,
    'Arr_MergeServerLogs' => $Arr_MergeServerLogs,
);
render('server/merge_servers_log.tpl', $data);