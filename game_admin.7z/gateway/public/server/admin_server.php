<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Oct 31 09:17:30 GMT 2011
 * @desc 游戏管理后台服务器管理
 */
require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');
include_once SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'agent.php';

$action = $_GET['action'];
$action = $action ? $action : 'list';
$agents = Agent::getAgents(false);
if ('add' == $action) {
	if (isPost()) {
		$server = checkParams( $_POST['server'], $msg);
		$sql = " select * from t_game_server where `agentName`='{$server['agentName']}' and `serverId`='{$server['serverId']}' ";
		$rs = fetchRowOne($sql);
		if (!empty($rs)) {
			$msg[] = "{$server['agentName']}s{$server['serverId']} 已经存在，添加服务器失败";
		}
		if (empty($msg)) {
			$result = setServerVar($server);
			if (1==$result['result']) {
				$sql = makeInsertSql('t_game_server', $server);
				$rs = dbQuery($sql);
				if (!$rs) {
					$msg[] = '添加服务器配置失败！';
				}
			}else {
				$msg[] = $result['errorMsg'];
			}
		}
		if (empty($msg)) {
			header('Location:?action=list');
		}
	}
	$data = array(
		'action'=>$action,
		'agents'=>&$agents,
		'server'=>&$server,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('server/admin_server_edit.tpl',$data);
	
}elseif ('saveAs' == $action) {
	
	if (!isPost()) {
		$serverName = SS($_GET['serverName']);
		$sql = " select * from t_game_server where `serverName`='{$serverName}' ";
		$server = fetchRowOne($sql);
	}else{
		$server = checkParams( $_POST['server'], $msg);
		$sql = " select * from t_game_server where `agentName`='{$server['agentName']}' and `serverId`='{$server['serverId']}' ";
		$rs = fetchRowOne($sql);
		if (!empty($rs)) {
			$msg[] = "{$server['agentName']}s{$server['serverId']} 已经存在，添加服务器失败";
		}
		if (empty($msg)) {
			$result = setServerVar($server);
			if (1==$result['result']) {
				$sql = makeInsertSql('t_game_server', $server);
				$rs = dbQuery($sql);
				if (!$rs) {
					$msg[] = '添加服务器配置失败！';
				}
			}else {
				$msg[] = $result['errorMsg'];
			}
		}
		if (empty($msg)) {
			header('Location:?action=list');
		}
	}
	
	$data = array(
		'action'=>$action,
		'agents'=>&$agents,
		'server'=>&$server,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('server/admin_server_edit.tpl',$data);
	
}elseif ('update' == $action){
	if (!isPost()) {
		$serverName = SS($_GET['serverName']);
		$sql = " select * from t_game_server where `serverName`='{$serverName}' ";
		$server = fetchRowOne($sql);
	}else {
		$server = checkParams( $_POST['server'], $msg);
		$sql = " select * from t_game_server where `agentName`='{$server['agentName']}' and `serverId`='{$server['serverId']}' ";
		$rs = fetchRowOne($sql);
		if (empty($rs)) {
			$msg[] = "{$server['agentName']}s{$server['serverId']} 不存在，更新服务器失败！";
		}
		if (empty($msg)) {
			$result = setServerVar($server);
			if (1==$result['result']) {
				$sql = makeUpdatetSql('t_game_server', 'serverName', $server);
				$rs = dbQuery($sql);
				if (!$rs) {
					$msg[] = '更新服务器配置失败！';
				}
			}else {
				$msg[] = $result['errorMsg'];
			}
		}
		
		if (empty($msg)) {
			header('Location:?action=list');
		}
	}
	$data = array(
		'action'=>$action,
		'agents'=>&$agents,
		'server'=>&$server,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('server/admin_server_edit.tpl',$data);
	
}elseif ('view' == $action){
	$serverName = SS($_GET['serverName']);
	$sql = " select * from t_game_server where `serverName`='{$serverName}' ";
	$server = fetchRowOne($sql);
	$data = array(
		'action'=>$action,
		'server'=>&$server,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('server/admin_server_view.tpl',$data);
	
}elseif ('list'==$action){
	
	$sql = "select * from t_game_server";
	$server = fetchRowSet($sql);
	$data = array(
		'server'=>&$server,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	
	render('server/admin_server_list.tpl',$data);
	
}elseif ('delete'==$action){
	$serverName = trim($_GET['serverName']);
	$sql = " delete from t_game_server where `serverName`='{$serverName}' ";
	dbQuery($sql);
	header('Location:?action=list');
	exit();
}

//============

function checkParams($server, &$msg)
{
	global $agents;
	if (is_array($server)) {
		foreach ($server as &$p) {
			$p = SS($p);
		}
	}
	$server['serverId'] = intval($server['serverId']);
	if ($server['serverId'] < 0 ) {
		$msg[] = '服务器编号必须填写正整数';
	}
	$agentIds = array_keys($agents);
	if ( !in_array($server['agentId'],$agentIds) ) {
		$msg[] = '请选择代理商';
	}
	$server['serverName'] = $agents[$server['agentId']].'s'.$server['serverId'];
	$server['agentName']  = $agents[$server['agentId']];
	if (!$server['dbHost']) {
		$msg[] = '数据库所在机的ip必须填写';
	}
	if (!$server['dbUser']) {
		$msg[] = '数据库用户名必须填写';
	}
	if (!$server['dbPasswd']) {
		$msg[] = '数据库密码必须填写';
	}
	if (!$server['dbName']) {
		$msg[] = '数据库名必须填写';
	}
	if (!$server['gameAdminUrl']) {
		$msg[] = '本服游戏管理后台地址必须填写';
	}
	if (!strtotime($server['serverOnlineDate'])) {
		$msg[] = '开服日期必须填写';
	}
	return $server;
}

function setServerVar($serverParams)
{
	$arrParams = array(
		'SERVER_NAME' => $serverParams['serverName'],
		'SERVER_ID' => $serverParams['serverId'],
		'AGENT_NAME' => $serverParams['agentName'],
		'AGENT_ID' => $serverParams['agentId'],
		'DB_HOST' => $serverParams['dbHost'],
		'DB_USER' => $serverParams['dbUser'],
		'DB_PASSWD' => $serverParams['dbPasswd'],
		'DB_NAME' => $serverParams['dbName'],
		'GAME_ADMIN_URL' => $serverParams['gameAdminUrl'],
		'GAME3W_URL' => $serverParams['game3wUrl'],
		'GAME3W_AUTH_KEY' => $serverParams['game3wAuthKey'],
		'PLATFORM_LOGIN_KEY' => $serverParams['platformLoginKey'],
		'SERVER_SOCKET_HOST' => $serverParams['serverSocketHost'],
		'SERVER_SOCKET_PORT' => $serverParams['serverSocketPort'],
		'SERVER_AUTH_KEY' => $serverParams['serverAuthKey'],
		'SERVER_API_URL' => $serverParams['serverApiUrl'],
		'SYSDIR_GAME_ETL_CSV' => $serverParams['sysDirGameEtlCsv'],
		'SYSDIR_GAME_LOG' => $serverParams['sysDirGameLog'],
		'SYSDIR_GAME_LOG_WAIT' => $serverParams['sysDirGameLog'] ? $serverParams['sysDirGameLog'].'/wait' : '',
		'SYSDIR_GAME_LOG_ERROR' => $serverParams['sysDirGameLog'] ? $serverParams['sysDirGameLog'].'/error' : '',
		'SYSDIR_GAME_LOG_OK' =>  $serverParams['sysDirGameLog'] ? $serverParams['sysDirGameLog'].'/ok' : '',
		'GM_SYSTEM_AUTH_KEY' =>  $serverParams['gmSystemAuthKey'],
		'GM_SYNC_COMPLAINT_URL' =>  $serverParams['gmSyncComplaintUrl'],
		'GAME_ADMIN_AUTH_KEY' =>  $serverParams['gameAdminAuthKey'],
		'SERVER_ONLINE_DATE' =>  $serverParams['serverOnlineDate'],
		'DB_GAME_HOST' =>  $serverParams['dbGameHost'],
		'DB_GAME_USER' =>  $serverParams['dbGameUser'],
		'DB_GAME_PASSWD' =>  $serverParams['dbGamePasswd'],
		'DB_GAME_DB_NAME' =>  $serverParams['dbGameDbName'],
	);
	$base64Params = trim(base64_encode(base64_encode(json_encode($arrParams))), '=');
	$ticket = md5(GATEWAY_SYSTEM_AUTH_KEY.$base64Params); 
	$url = $serverParams['gameAdminUrl'].'api/set_server_vars.php';
	$result = curlPost($url,"ticket={$ticket}&base64Params={$base64Params}");
	$result = json_decode($result,true);
	return $result;
}