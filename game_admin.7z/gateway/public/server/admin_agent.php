<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Oct 31 09:17:30 GMT 2011
 * @desc 游戏管理后台代理管理
 */
require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');
include_once(SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'agent.php');

$action = $_GET['action'];
$action = $action ? $action : 'list';

if ('list'==$action){
	$allAgentKey = Agent::ALL_AGENT_KEY;
	$sql = " select * from t_agent where agentId <> {$allAgentKey}";
	$rs = fetchRowSet($sql);
	render('server/admin_agent_list.tpl',array('agent'=>$rs));
}elseif ('edit' == $action){
	$agentId = intval($_GET['agentId']);
	if ($agentId) {
		$sql = " select * from t_agent where `agentId`='{$agentId}' ";
		$agent = fetchRowOne($sql);
		$agentName = $agent['agentName'];
		$caption = $agent['caption'];
	}
	if (isPost()) {
		$agentName = SS($_POST['agentName']);
		$caption = SS($_POST['caption']);
		if (!$agentName ) {
			$msg[] = "代理商名不能为空！";
		}
		if ($agentId) { //如果有GET的agentId
			$sql = " update t_agent set agentName='{$agentName}', `caption`='{$caption}' where `agentId`={$agentId} ";
		}else {
			$agentId = intval($_POST['agentId']);
			if (!$agentId ) {
				$msg[] = "代理商ID不能为空！";
			}
			$sql = " insert into t_agent (`agentId`, `agentName`, `caption`) values ({$agentId}, '{$agentName}', '{$caption}') ";
		}
		
		if (empty($msg)) {
			$rs = dbQuery($sql);
			if (!$rs) {
				$msg[] = '更新代理配置失败！';
			}
		}
		if (empty($msg)) {
			header('Location:?action=list');
		}
	}
	$data = array(
		'agentId'=>&$agentId,
		'agentName'=>&$agentName,
		'caption'=>&$caption,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('server/admin_agent_edit.tpl',$data);
	
}elseif ('delete'==$action){
	$agentId = trim($_GET['agentId']);
	$sql = " delete from t_agent where `agentId`='{$agentId}' ";
	dbQuery($sql);
	header('Location:?action=list');
}