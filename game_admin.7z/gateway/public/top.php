<?php
/**
 * @author linruirong@4399.com
 * @Created  Thu Nov 03 09:01:16 GMT 2011
 * @desc 页面顶部
 */
include_once '../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE."/global.php";
include_once SYSDIR_ADMIN_CLASS."/admin_group.php";
include_once SYSDIR_ADMIN_CLASS."/agent.php";

$user = getSession('user');
$selectedServer = getSession('selectServer');
if ($user && $user['agentId']) {
	$sql = " select * from t_game_server ";
	$rs= fetchRowSet($sql);
}

$servers = array('--请选择--');
if (is_array($rs)) {
	foreach ($rs as $row) {
		$servers[$row['serverName']] = $row['serverName'];
	}
}
$data = array(
	'selectedServer'=>$selectedServer,
	'servers' =>$servers,
	'GAME_NAME' => GAME_NAME,
	'user' => &$user,
);
render('top.tpl',$data);