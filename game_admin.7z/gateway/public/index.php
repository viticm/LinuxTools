<?php
include_once '../protected/config/config.php';
$action = $_GET['action'];
if (''==$_SESSION[SESSION_KEY]['user']['username']) {//用户未登录
	header("Location:login.php");
	die();
}else {
	include_once SYSDIR_ADMIN_INCLUDE."/global.php";
	include_once SYSDIR_ADMIN_CLASS."/admin_group.php";
	include_once SYSDIR_ADMIN_CLASS."/agent.php";
	include_once SYSDIR_ADMIN_CLASS."/server.php";
	
	$user = getSession('user');
	$agentId = $user['gameAdminAgentId'];
	$objServer = new Server();
	$arrAgentServer = $objServer->getMyAgentServers(); //取得有权限的服务器列表
	
	$leftSrc = getSession('leftSrc',$leftSrc);
	$mainSrc = getSession('mainSrc',$mainSrc);
	$leftSrc = $leftSrc ? $leftSrc : 'left.php';
	$mainSrc = $mainSrc ? $mainSrc : 'main.php';
	$data = array(
		'arrAgentServer'=>&$arrAgentServer,
		'user'=>&$user,
		'GAME_NAME' => GAME_NAME,
		'GM_ADMIN_URL'=>GM_ADMIN_URL,
		'CENTRAL_ADMIN_URL'=>CENTRAL_ADMIN_URL,
		'showCentralAdmin' => Agent::ALL_AGENT_KEY == $user['centralAgentId'],
		'leftSrc'=>&$leftSrc,
		'mainSrc'=>&$mainSrc,
	);
	render('index.tpl', &$data);
}
