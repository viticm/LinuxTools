<?php
include_once '../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php';
include_once(SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'user_auth.php');
include_once SYSDIR_ADMIN_CLASS.'/admin_log.php';

global $auth;
$userInfo = getSession('user');
$username = $userInfo['username'];
if ($username) {
	header("Location:index.php");
}

if (isPost()) {
	$username = SS($_POST['username']);
	$password = stripslashes($_POST['password']);
	$checkCode = trim($_POST['checkCode']);
	$sessCheckCode = getSession('checkCode');
	
	$msg = '';
	if (!$username || !$password) {
		$msg = '用户名、密码不能为空！';
	}
	if ( ''==$msg && CHECK_CODE_SWITCH && strtolower($checkCode) != strtolower($sessCheckCode) ) {
		$msg = '验证码不正确！';
	}
	if (''==$msg && ROOT_USERNAME == $username && ( !defined('ENABLE_ROOT_USER') || !ENABLE_ROOT_USER ) ) {
		$msg = ROOT_USERNAME.' (超级管理员帐号)已经被禁止登录。';
	}
	if (''==$msg) {
		$authResult = $auth->login($username, $password);
		if (UserAuth::LOGINT_RESULT_USER_OK === $authResult) {
			//写日志
			$log = new AdminLog();
			$log->writeLog(AdminLog::LOG_TYPE_LOGIN);
			
			$userInfo = getSession('user');
			if (time() - $userInfo['lastChangePasswd'] > CHANGE_PASSWORD_DAYS * 86400 ) {
				header('Location:system/password.php');//若已经太久没改密码，跳转到修改密码页
			}else {
				header("Location:index.php");
			}
		}elseif (UserAuth::LOGINT_RESULT_USER_DISABLE === $authResult){
			$msg = "您的帐号已经被禁用，请联系管理员！";
		}elseif (UserAuth::LOGINT_RESULT_USER_PAST_DUE === $authResult){
			$msg = "您的帐号已经超过".PAST_DUE_DAYS."天未登录，已经被系统自动冻结，请联系管理员解冻！";
		}elseif (UserAuth::LOGINT_RESULT_USER_PASS_ERR === $authResult){
			$msg = '用户名或者密码错误，请重新输入！';
		}
	}
}

$data = array(
	'msg'=> $msg,
	'CHECK_CODE_SWITCH'=>CHECK_CODE_SWITCH,
);
render('login.tpl', $data);
