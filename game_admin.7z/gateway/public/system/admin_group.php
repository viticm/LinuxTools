<?php
/**
 * @author linruirong@4399.com
 * @Created  Fri Oct 21 03:17:53 GMT 2011
 * @desc 用户组管理。
 */

require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');
require_once(SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'admin_group.php');
require_once(SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'menu.php');

$action = $_GET['action'];
$action = $action ? $action : 'list';
$groupId = intval($_GET['id']);

$objGroup  = new AdminGroup();

$isPost = isPost();
if ('edit'==$action ) {
	$userInfo = getSession('user');
	$username = $userInfo['username'];
	$myRules = $objGroup->getUserRules($username);
	if ($groupId && !$isPost ) {
		$group = $objGroup->getGroupById($groupId);
	}
	if ($isPost) {
		$group = $_POST['group'];
		$groupId = intval( $_POST['id'] );
		$group['groupName'] = SS($group['groupName']);
		$group['remarks'] = SS($group['remarks']);
		if (!$group['groupName']) {
			$msg[] = '组名不能为空!';
		}
		if (empty($group['rules'])) {
			$msg[] = '请选择权限项!';
		}
		if (empty($msg)) {
			$rules = array();
			foreach ($myRules as $row) {
				if (is_array($group['rules'])) {
					foreach ($group['rules'] as $ruleItem) {
						if ($row['id'] == $ruleItem) {
							array_push($rules, $ruleItem);
							break;
						}
					}
				}
			}
			$group['rules'] = $rules;
			$strValidRulesIds = implode(',',$rules);
			if ($groupId) {
				$rs = $objGroup->updateGroup($groupId, $strValidRulesIds, $group['remarks']);
			}else {
				$rs = $objGroup->addGroup($group['groupName'], $strValidRulesIds, $group['remarks']);
			}
			if ($rs) {
				header('Location:admin_group.php');
			}
		}
	}
	
	foreach ($myRules as &$rule) {
		if ( is_array($group['rules']) && !empty($group['rules']) ) {
			foreach ($group['rules'] as $index => $ruleId) {
				if ($rule['id'] == $ruleId) {
					$rule['checked'] = 'checked="checked"';
					unset($group['rules'][$index]);
					break;
				}
			}
		}
	}
	$myRulesList = array();
	$objMenu = new Menu();
	foreach ($myRules as $row) {
		$myRulesList[$objMenu->arrSystemType[$row['belongTo']]][$row['class']][$row['id']] = $row;
	}
	$data = array(
		'myRulesList'=>&$myRulesList,
		'group'=>&$group,
		'groupId'=>&$groupId,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('system/group_edit.tpl',$data);
	
}elseif ('delete' == $action){
	$id = intval($_GET['id']);
	$rs = $objGroup->deleteGroup($id);
	if (!$rs) {
		$msg[] = '删除失败！';
	}
	$arrGroup = $objGroup->getAllGroups();
	$data = array(
		'groups'=>&$arrGroup,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('system/group_list.tpl',$data);
	
}elseif ('list' == $action){
	$arrGroup = $objGroup->getAllGroups();
	$objMenu = new Menu();
	$arrMenu = $objMenu->getAllMenuNames();
	
	foreach ($arrGroup as &$group) {
		$rules = explode(',',$group['rules']);
		$strRules = '';
		foreach ($rules as $ruleItem) {
			$strRules .=  $arrMenu[$ruleItem]. ', ';
		}
		$group['strRules'] = $strRules;
	}
	$data = array(
		'groups'=>&$arrGroup,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('system/group_list.tpl',$data);
}
