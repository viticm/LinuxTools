<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Nov 07 02:21:58 GMT 2011
 * @desc 用户改密码
 *       注意：用保证密码安全，密码强度应该强制 2级（一般） 以上。见checkPasswdRate()
 */
include_once '../../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE.'/global.php';
$userInfo = getSession('user');
if(ROOT_USERNAME == $userInfo['username'] ) {
	die('此用户的密码不允许在此修改！');
}

if ('update'==$_POST['action'])
{
	$objUser = new AdminUser();
	$oldpass = stripslashes($_POST['oldpass']);
	$newpass1 = stripslashes($_POST['newpass1']);
	$newpass2 = stripslashes($_POST['newpass2']);
	$validResult = $objUser->checkPasswdRate($newpass1);
	$md5new = md5($newpass1);
	$md5old = md5($oldpass);
	if (0 == $validResult) {
		$msg[] = '新密码长度太短！';
		display($msg);
	}elseif (1 == $validResult){
		$msg[] = '新密码强度太弱，太容易被破解了！';
		display($msg);
	}
	if ($newpass1 != $newpass2) {
		$msg[] = '两次输入的新密码不一致！';
		display($msg);
	}
	if ($md5old != $userInfo['passwd']) {
		$msg[] = '旧密码错误，不执行修改！';
		display($msg);
	}
	if ($md5new == $userInfo['passwd']) {
		$msg[] = '新密码不能同旧密码一样！';
		display($msg);
	}
	$result = $objUser->updateUserPasswd($userInfo['uid'], $newpass1 );
	if ($result) {
		$msg = array('修改密码成功');
		display($msg,true);
	} else {
		$msg[] = '修改密码出错，请联系管理员解决！';
		display($msg);
	}
}else {
	if( time() - $userInfo['lastChangePasswd'] > CHANGE_PASSWORD_DAYS * 86400){
		$msg[] = '新帐号要求改密码 或 已经超过 '. CHANGE_PASSWORD_DAYS .' 天未更改密码了。请及时更改密码，以确保帐号安全。';
	}
	display($msg);
}
//==============

function display($msg,$changeOk=false)
{
	global $userInfo;
	$data = array(
		'username'=>$userInfo['username'],
		'changeOk'=>$changeOk,
		'errorMsg'=>is_array($msg) ? implode('<br>',$msg) : '' ,
	);
	render('system/password.tpl',$data);
}
