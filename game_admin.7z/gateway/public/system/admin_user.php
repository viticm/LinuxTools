<?php
/**
 * @author linruirong@4399.com
 * @Created  Thu Oct 27 03:18:00 GMT 2011
 * @desc 用户管理
 *       考虑到数据完整性，不提供删除用户的功能，但可以禁用用户。
 */
require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');
require_once(SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'admin_group.php');
include_once SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'admin_user.php';
include_once SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'agent.php';
include_once SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'server.php';

$action = $_GET['action'];
$action = $action ? $action : 'list';

$objUser = new AdminUser();

if ('enabled' == $action) { //启用
	$uid = intval($_GET['uid']);
	$username = SS($_GET['username']);
	$result = $objUser->setUserEnable($uid);
	if ($result) {
		header('Location:admin_user.php');
	}
	
}elseif ('disabled' == $action) { //禁用用户
	$uid = intval($_GET['uid']);
	$username = SS($_GET['username']);
	$result = $objUser->setUserDisable($uid);
	if ($result) {
		header('Location:admin_user.php');
	}
}elseif ('list' == $action){
	$users = $objUser->getAllUser();
	$msg[] = '注： 被系统冻结：用户超过 '.PAST_DUE_DAYS.' 天未登录，系统会自动将其帐号冻结。';	
	$data = array(
		'users'=>&$users,
		'ALL_AGENT_KEY' =>Agent::ALL_AGENT_KEY,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('system/user_list.tpl',$data);
	
}elseif ('update'==$action){
	$objServer = new Server();
	$arrAgentServer = $objServer->getServersByAgentId(Agent::ALL_AGENT_KEY);
	$objGroup = new AdminGroup();
	$arrGroup = $objGroup->getAllGroupsKeyName();
	$arrAgent = Agent::getAgents();
	$isPost = isPost();
	$uid = $isPost ? intval($_POST['uid']) : intval($_GET['uid']);
	$user = $objUser->getUserById($uid);
	$username = $user['username'];
	$remarks = $user['remarks'];
	$groupId = $user['groupId'];
	$gmAgentId = $user['gmAgentId'];
	$centralAgentId = $user['centralAgentId'];
	$gameAdminAgentId = $user['gameAdminAgentId'];
	$gameAdminServerType = $user['gameAdminServer'] == Server::ALL_SERVER_KEY ?  1 : 2;
	
	if (empty($user['uid'])) {
		$msg[] = '没有此用户！';
	}
	if ($isPost) {
		$passwd = stripslashes($_POST['passwd']);
		$remarks = SS($_POST['remarks']);
		$groupId = intval($_POST['groupId']);
		$gmAgentId = intval($_POST['gmAgentId']);
		$centralAgentId = intval($_POST['centralAgentId']);
		$gameAdminAgentId = intval($_POST['gameAdminAgentId']);
		$gameAdminServerType = intval($_POST['gameAdminServerType']);
		$gameAdminServerType = (1 == $gameAdminServerType || 2 == $gameAdminServerType) ? $gameAdminServerType : 2;
		$agentServer = $_POST['agentServer'];
		if(1==$gameAdminServerType){ //所有已开和待开的服
			$gameAdminServer = Server::ALL_SERVER_KEY ;
		}elseif(empty($agentServer)) {
			$gameAdminServer = '';
		}else {
			$gameAdminServer = json_encode($agentServer);
		}
		if ($passwd && $objUser->checkPasswdRate($passwd) < 2) {
			$msg[] = '密码强度不够！';
		}
	}
	
	if (!$isPost && $user['gameAdminServer'] && $user['gameAdminServer'] != Server::ALL_SERVER_KEY ) {
		$agentServer = json_decode($user['gameAdminServer'],true);
	}
	if ( is_array($arrAgentServer) && is_array($agentServer) ) {
		foreach ($arrAgentServer as &$agent) {
			if ( is_array($agent['servers']) ) {
				foreach ($agent['servers'] as &$server) {
					foreach ($agentServer as $agentId =>$serverIds ) {
						if (is_array($serverIds)) {
							foreach ($serverIds as $k => $sid) {
								if ( $agentId == $agent['agentId'] && $sid == $server['serverId'] ) {
									$server['checked'] = true;
									unset($agentServer[$agentId][$k]);
									break;
								}
							}
						}
					}
				}
			}
		}
	} 
	if (empty($msg) && $isPost) {
		$result = $objUser->updateUser($uid, $groupId, $gmAgentId, $centralAgentId, $gameAdminAgentId, $gameAdminServer, $remarks, $passwd);
		if ($result) {
			header('Location:admin_user.php');
		}
	}
	$data = array(
		'action'=>&$action,
		'username'=>&$username,
		'remarks'=>&$remarks,
		'groupId'=>&$groupId,
		'gmAgentId'=>&$gmAgentId,
		'centralAgentId'=>&$centralAgentId,
		'gameAdminAgentId'=>&$gameAdminAgentId,
		'arrGroup'=>&$arrGroup,
		'uid'=>&$uid,
		'arrAgent'=>$arrAgent,
		'arrAgentServer' =>&$arrAgentServer,
		'gameAdminServerType'=>$gameAdminServerType,
		'ALL_AGENT_KEY' =>Agent::ALL_AGENT_KEY,
		'ALL_SERVER_KEY' =>Server::ALL_SERVER_KEY,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('system/user_edit.tpl',$data);
	
}elseif ('add'==$action){
	$gameAdminServerType = 1==$gameAdminServerType || 2==$gameAdminServerType ? $gameAdminServerType : 1;
	$objServer = new Server();
	$arrAgentServer = $objServer->getServersByAgentId(Agent::ALL_AGENT_KEY);
	$isPost = isPost();
	$objGroup = new AdminGroup();
	$arrGroup = $objGroup->getAllGroupsKeyName();
	$arrAgent = Agent::getAgents();

	if ($isPost) {
		$username = SS($_POST['username']);
		$passwd = stripslashes($_POST['passwd']);
		$remarks = SS($_POST['remarks']);
		$groupId = intval($_POST['groupId']);
		$gmAgentId = intval($_POST['gmAgentId']);
		$centralAgentId = intval($_POST['centralAgentId']);
		$gameAdminAgentId = intval($_POST['gameAdminAgentId']);
		$gameAdminServerType = intval($_POST['gameAdminServerType']);
		$gameAdminServerType = (1 == $gameAdminServerType || 2 == $gameAdminServerType) ? $gameAdminServerType : 2;
		$agentServer = $_POST['agentServer'];
		if(1==$gameAdminServerType){ //所有已开和待开的服
			$gameAdminServer = Server::ALL_SERVER_KEY ;
		}elseif(empty($agentServer)) {
			$gameAdminServer = '';
		}else {
			$gameAdminServer = json_encode($agentServer);
		}
		if ($passwd && $objUser->checkPasswdRate($passwd) < 2) {
			$msg[] = '密码强度不够！';
		}
		if (!$username) {
			$msg[] = '请填写用户名！';
		}else {
			$user = $objUser->getUserByName($username);
		}
		if (!empty($user['uid'])) {
			$msg[] = '已经有此用户，添加用户失败！';
		}
		if (!$passwd) {
			$msg[] = '请填写初始密码！';
		}
		if ($objUser->checkPasswdRate($passwd) < 2 ) {
			$msg[] = '初始密码强度不够！';
		}
		if ( !$groupId ) {
			$msg[] = '请选择权限组！';
		}	
	}else {
		$gmAgentId = Agent::ALL_AGENT_KEY ;
		//$centralAgentId = Agent::ALL_AGENT_KEY ;
		$gameAdminAgentId = Agent::ALL_AGENT_KEY ;
		$gameAdminServerType = Server::ALL_SERVER_KEY;
		$gameAdminServerType = $user['gameAdminServer'] == Server::ALL_SERVER_KEY ?  1 : 2;
	
	}
	
	if ($isPost && empty($msg)) {
		$result = $objUser->addUser($username, $passwd, $groupId, $gmAgentId, $centralAgentId, $gameAdminAgentId, $gameAdminServer, $remarks);
		if ($result) {
			//header('Location:admin_user.php');
		}
	}
	
	if ( is_array($arrAgentServer) && is_array($agentServer) ) {
		foreach ($arrAgentServer as &$agent) {
			if ( is_array($agent['servers']) ) {
				foreach ($agent['servers'] as &$server) {
					foreach ($agentServer as $agentId =>$serverIds ) {
						if (is_array($serverIds)) {
							foreach ($serverIds as $k => $sid) {
								if ( $agentId == $agent['agentId'] && $sid == $server['serverId'] ) {
									$server['checked'] = true;
									unset($agentServer[$agentId][$k]);
									break;
								}
							}
						}
					}
				}
			}
		}
	}
	
	$data = array(
		'action'=>&$action,
		'username'=>&$username,
		'remarks'=>&$remarks,
		'groupId'=>&$groupId,
		'gmAgentId'=>&$gmAgentId,
		'centralAgentId'=>&$centralAgentId,
		'gameAdminAgentId'=>&$gameAdminAgentId,
		'arrGroup'=>&$arrGroup,
		'arrAgent'=>$arrAgent,
		'arrAgentServer' =>&$arrAgentServer,
		'gameAdminServerType'=>$gameAdminServerType,
		'ALL_AGENT_KEY' =>Agent::ALL_AGENT_KEY,
		'ALL_SERVER_KEY' =>Server::ALL_SERVER_KEY,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('system/user_edit.tpl',$data);
}