<?php
/**
 * @author linruirong@4399.com
 * @Created  Mon Oct 24 02:29:40 GMT 2011
 * @desc 菜单管理
 */
require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global.php');
require_once (SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'menu.php');

$action = $_GET['action'];
$action = $action ? $action : 'list';

$objMenu = new Menu();
if ('edit'==$action ) {
	$id = trim($_GET['id']);
	if ($id && !isPost()) {
		$menu = $objMenu->getMenuById($id);
		if (empty($menu)) {
			$msg[] = '没有此菜单项';
		}
	}
	if (isPost()) {
		$menu = $_POST['menu'];
		$id = trim($_POST['id']);
		$menu['name'] = trim($menu['name']);
		$menu['url'] = trim(trim($menu['url']),'/');
		$menu['class'] = trim($menu['class']);
		$menu['belongTo'] = intval($menu['belongTo']);
		$menu['visible'] = intval($menu['visible']);
		
		if (!$menu['name']) {
			$msg[] = '菜单名不能为空';
		}
		if (!$menu['url']) {
			$msg[] = '相对地址不能为空';
		}
		if (!$menu['class']) {
			$msg[] = '父级菜单不能为空';
		}
		if (!$menu['belongTo']) {
			$msg[] = '请选择菜单所属于系统必选';
		}
		if (!$menu['visible']) {
			$msg[] = '请选择菜单可见性';
		}
		$oldMenu = $objMenu->getMenuByUrl($menu['belongTo'],$menu['url']);
		if ($id) { //修改
			if ( $oldMenu['id'] != $id ) {
				$msg[] =  "{$objMenu->arrSystemType[$oldMenu['belongTo']]} 已经存在相同 url 的菜单，修改菜单失败！";
			}else{
				$result = $objMenu->updateMenu($id, $menu['class'], $menu['name'], $menu['url'], $menu['belongTo'], $menu['visible'] );
			}
		}else { //新增
			if (empty($oldMenu)) {
				$result = $objMenu->addMenu($menu['class'], $menu['name'], $menu['url'], $menu['belongTo'], $menu['visible'] );
			}else {
				$msg[] = "{$objMenu->arrSystemType[$menu['belongTo']]} 已经存在相同 url 的菜单，添加菜单失败！";
			}
		}
		if (empty($msg)) {
			header('Location:menu.php');
		}
	}
	$arrClass = $objMenu->getAllClass();
	$data = array(
		'oldId'=>&$id,
		'menu'=>&$menu,
		'arrClass'=>&$arrClass,
		'arrSystemType'=>&$objMenu->arrSystemType,
		'arrVisibleType'=>&$objMenu->arrVisibleType,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('system/menu_edit.tpl',$data);
}elseif ('list'==$action){
	$menu = $objMenu->getAllMenu(true);
	$data = array(
		'menu'=>&$menu,
		'msg'=> empty($msg) ? '' : implode('<br />', $msg),
	);
	render('system/menu_list.tpl',$data);
}elseif ('order'==$action){
	$menuOrder = $_POST['menuOrder'];
	foreach ($menuOrder as $id => $orderNum) {
		$id = intval($id);
		$orderNum = intval($orderNum);
		if ($id && $orderNum) {
			$sql = "update t_menu set `orderNum`={$orderNum} where `id`={$id} ";
			dbQuery($sql);
		}
	}
	header('Location:menu.php');
}elseif ('delete'==$action){
	$id = trim($_GET['id']);
	$objMenu->deleteMenu($id);
	header('Location:menu.php');
	exit();
}