<?php
/**
 * @author viticm(duchuanpd@gmail.com)
 * @Created 2013-4-24
 * @desc 游戏管理后台合区日志外部接口
 */
require_once ('../../protected/config/config.php');
require_once (SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR.'global_for_api.php');
require_once ( SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'agent.php' );
require_once ( SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'server.php' );
require_once ( SYSDIR_ADMIN_CLASS.DIRECTORY_SEPARATOR.'mergeservers_log.php' );

$cAction = GetUrlParam( 'action' );

switch ( $cAction )
{
	case 'getlog':
		getLog();
		break;
	case 'addlog':
		addLog();
		break;
	case 'getserversid':
		getServersId();
		break;
	case 'getserver':
		getServer();
		break;
	case 'getserverconf':
		getServerConf();
		break;
	default:
		getLog();
}

/**
 * @desc 根据代理商获取合区日志
 * @param void
 * @return void
 */
function getLog()
{
	checkKey();
	$cAction = 'getlog';
	$Arr_Result = array();
	$Arr_Result[ 'ErrorCode' ] = 1;
	$Arr_Result[ 'ErrorDesc' ] = '';
	$Arr_Result[ 'mergeLog' ] = array();
	$iAgentId = $_GET[ 'agentId' ];
	$iServerId = $_GET[ 'serverId' ];
	if( empty( $iAgentId ) || empty( $iServerId ) )
	{
		$Arr_Result[ 'ErrorCode' ] = 4;
		$Arr_Result[ 'ErrorDesc' ] = urlencode( '获取日志失败：代理id或服务器id为空' );
	}
	else
	{
		$OBJ_MergeServerLog = new MergeServersLog();
		$Arr_Result[ 'mergeLog' ] = $OBJ_MergeServerLog->getMergeServersLogByAgentIdAndServerId( $iAgentId, $iServerId );
		unset( $OBJ_MergeServerLog );
	}
	$Res = json_encode( $Arr_Result );
	print_r( $Res );
}


/**
 * @desc 添加合区日志
 * @param void
 * @return void
 */
function addLog()
{
	checkKey();
	$cAction = 'addlog';
	$Arr_Result[ 'ErrorCode' ] = 1;
	$Arr_Result[ 'ErrorDesc' ] = '';
	$Arr_MergeServerLog = array();
	$Arr_MergeServerLog = json_decode( base64_decode( GetUrlParam( 'mergeLog' ) ), true );
	$OBJ_MergeServerLog = new MergeServersLog();
	$Result = $OBJ_MergeServerLog->addMergeServerLog( $Arr_MergeServerLog );
	if( false == $Result )
	{
		$Arr_Result[ 'ErrorCode' ] = 4;
		$Arr_Result[ 'ErrorDesc' ] = urlencode( '添加日志失败' );
	}
	unset( $OBJ_MergeServerLog );
	$Res = json_encode( $Arr_Result );
	print_r( $Res );
}

/**
 * @desc 获得某个代理下所有的服务器
 * @param void
 * @return void
 */
function getServersId()
{
	checkKey();
	$cAction = 'getserversid';
	$Arr_Result = array();
	$Arr_Result[ 'ErrorCode' ] = 1;
	$Arr_Result[ 'ErrorDesc' ] = '';
	$Arr_Result[ 'servers' ] = array();
	$iAgentId = GetUrlParam( 'agentId' );
	if( empty( $iAgentId ) )
	{
		$Arr_Result[ 'ErrorCode' ] = 4;
		$Arr_Result[ 'ErrorDesc' ] = urlencode( '获取服务器信息失败：代理id为空' );
	}
	else
	{
		$OBJ_Server = new Server();
		$Arr_Result[ 'servers' ] = $OBJ_Server->getNotMergeServersIdByAgentId( $iAgentId );
		unset( $OBJ_Server );
	}
	$Res = json_encode( $Arr_Result );
	print_r( $Res );
}

/**
 * @desc 获得某个服务器的信息（所有配置信息）
 * @param void
 * @return void
 */
function getServer()
{
	checkKey();
	$cAction = 'getserver';
	$Arr_Result = array();
	$Arr_Result[ 'ErrorCode' ] = 1;
	$Arr_Result[ 'ErrorDesc' ] = '';
	$Arr_Result[ 'server' ] = array();
	$iAgentId = GetUrlParam( 'agentId' );
	$iServerId = GetUrlParam( 'serverId' );
	if( empty( $iAgentId ) || empty( $iServerId ) )
	{
		$Arr_Result[ 'ErrorCode' ] = 4;
		$Arr_Result[ 'ErrorDesc' ] = urlencode( '获取服务器信息失败：代理id或服务id为空' );
	}
	else
	{
		$OBJ_Server = new Server();
		$Arr_Result[ 'server' ] = $OBJ_Server->getServerById( $iAgentId, $iServerId );
		unset( $OBJ_Server );
	}
	$Res = json_encode( $Arr_Result );
	print_r( $Res );
}

/**
 * @desc 获得某个服务器的信息（某些配置信息）
 * @param void
 * @return void
 */
function getServerConf()
{
	checkKey();
	$cAction = 'getserverconf';
	$Arr_Result = array();
	$Arr_Result[ 'ErrorCode' ] = 1;
	$Arr_Result[ 'ErrorDesc' ] = '';
	$Arr_Result[ 'server' ] = array();
	$iAgentId = GetUrlParam( 'agentId' );
	$iServerId = GetUrlParam( 'serverId' );
	if( empty( $iAgentId ) || empty( $iServerId ) )
	{
		$Arr_Result[ 'ErrorCode' ] = 4;
		$Arr_Result[ 'ErrorDesc' ] = urlencode( '获取服务器信息失败：代理id或服务id为空' );
	}
	else
	{
		$OBJ_Server = new Server();
		$Arr_Result[ 'server' ] = $OBJ_Server->getOneServerConfByAgentIdAndServerId( $iAgentId, $iServerId );
		unset( $OBJ_Server );
	}
	$Res = json_encode( $Arr_Result );
	print_r( $Res );
}

/**
 * @desc 验证检查
 * @param void
 * @return void
 */
function checkKey()
{
	$iTimeStamp = GetUrlParam( 'timeStamp' );
    $cCheckKey = GetUrlParam( 'key' );
	$cKey = md5( $iTimeStamp.GATEWAY_SYSTEM_AUTH_KEY );
	
    if ($cCheckKey != $cKey) 
    {
	    dieJsonMsg( 2, '获取数据出错:验证不通过!' );
    }
    if ( abs( $iTimeStamp-time() ) > 60*5 ) 
    { 
        //超过5分钟,则超时
	    dieJsonMsg( 3, '获取数据超时!' );
    }
}