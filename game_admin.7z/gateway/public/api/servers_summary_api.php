<?php
/**
 * @author viticm(duchuanpd@gmail.com)
 * @date 2013-8-19 10:14:02
 * @uses 提供给游戏后台记录服务器详细信息的外部接口
 */
require_once ( '../../protected/config/config.php' ) ;
require_once ( SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR. 'global_for_api.php') ;
require_once ( SYSDIR_ADMIN_INCLUDE.DIRECTORY_SEPARATOR. 'my_global.php' ) ;

$szAction = GetUrlParam( 'action' ) ;

switch ( $szAction )
{
	case 'addServerSummary':
		addServerSummary() ;
		break;
	default:
		addServerSummary() ;
}

/**
 * 保存服务器统计信息
 * @param void
 * @return void
 */
function addServerSummary()
{
	checkKey() ;
	$cAction = 'addServerSummary';
	$Arr_Result[ 'ErrorCode' ] = 1 ;
	$Arr_Result[ 'ErrorDesc' ] = '' ;
	$Arr_ServerSummary = array() ;

	$Arr_ServerSummary[ 'agentId' ]        = GetUrlParam( 'agentId' ) ;
	$Arr_ServerSummary[ 'serverId' ]       = GetUrlParam( 'serverId' ) ;
	$Arr_ServerSummary[ 'mDateTime' ]      = GetUrlParam( 'dateTime' ) ;
	$Arr_ServerSummary[ 'summaryJson' ]    = urldecode( base64_decode( GetUrlParam( 'serverSummaryJson' ) ) ) ;
	$OBJ_ServerSummary = new ServerSummary() ;
	$Result = $OBJ_ServerSummary->addServerSummary( $Arr_ServerSummary ) ;
	if( false == $Result )
	{
		$Arr_Result[ 'ErrorCode' ] = 4;
		$Arr_Result[ 'ErrorDesc' ] = urlencode( '保存服务器概况信息失败' ) ;
	}
	unset( $OBJ_ServerSummary ) ;
	$Res = json_encode( $Arr_Result ) ;
	print_r( $Res ) ;
}

/**
 * 验证检查
 * @param void
 * @return void
 */
function checkKey()
{
	$iTimeStamp = GetUrlParam( 'timeStamp' ) ;
    $cCheckKey  = GetUrlParam( 'key' );
	$cKey       = md5( $iTimeStamp.GATEWAY_SYSTEM_AUTH_KEY ) ;
	$Arr_Result = array() ;
	$Arr_Result[ 'ErrorCode' ] = 1 ;
	$Arr_Result[ 'ErrorDesc' ] = '' ;

    if ( $cCheckKey != $cKey )
    {
		$Arr_Result[ 'ErrorCode' ] = 2 ;
		$Arr_Result[ 'ErrorDesc' ] = urlencode( '校验失败' ) ;
    }
    if ( abs( $iTimeStamp - time() ) > 60*5 )
    {
		$Arr_Result[ 'ErrorCode' ] = 3 ;
		$Arr_Result[ 'ErrorDesc' ] = urlencode( '数据超时' ) ;
    }
    if ( 1 != $Arr_Result[ 'ErrorCode' ] )
        SprintJsonStrAndExit( $Arr_Result ) ;
}