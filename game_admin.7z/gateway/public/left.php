<?php
include_once '../protected/config/config.php';
include_once SYSDIR_ADMIN_INCLUDE."/global.php";
include_once SYSDIR_ADMIN_CLASS."/admin_group.php";
include_once SYSDIR_ADMIN_CLASS."/menu.php";

$action = trim($_GET['action']);
if ('count'==$action) {
	$menuId = intval($_GET['menuId']);
	$userInfo = getSession('user');
	$userId = intval($userInfo['uid']);
	$lastClickTime = time();
	if ($menuId && $userId) {
		$sql = " INSERT INTO t_menu_counter (`uid`,`menuId`,`counter`, `lastClickTime`) VALUES ({$userId},{$menuId},1,{$lastClickTime}) ON DUPLICATE KEY UPDATE `counter`=`counter`+1, `lastClickTime`={$lastClickTime} ";
		try {
			$rs = dbQuery($sql);
		}catch (Exception $e){
		}
		if ($rs) {
			echo 'true';
		}else {
			echo 'false';
		}
	}else {
		echo 'false';
	}
	die();
}else {
	$objMenu = new Menu();
	$menu = $objMenu->getMyMenu( Menu::GATEWAY_SYSTEM );
	$data = array(
		'menu' => $menu
	);
	render('left.tpl', $data);
}